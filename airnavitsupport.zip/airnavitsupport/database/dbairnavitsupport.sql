-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 17 Sep 2018 pada 02.39
-- Versi Server: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbairnavitsupport`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_bangunan_dan_ac`
--

CREATE TABLE `tbl_bangunan_dan_ac` (
  `id` int(11) NOT NULL,
  `kode_alat` varchar(10) NOT NULL,
  `username_pemeriksa` varchar(15) NOT NULL,
  `lokasi` varchar(20) NOT NULL,
  `tanggal` date NOT NULL,
  `dinas` enum('Pagi','Malam','','') NOT NULL,
  `kebersihan_ruangan` enum('Bersih','Tidak','','') NOT NULL,
  `kondisi_bangunan` enum('Baik','Tidak','','') NOT NULL,
  `suhu_ruangan` double NOT NULL,
  `periksa_aliran_udara_evapurator` enum('Dingin','Tidak','','') NOT NULL,
  `pastikan_unit_outdoor_kompresor_bekerja` enum('Ya','Tidak','','') NOT NULL,
  `foto` varchar(250) NOT NULL,
  `catatan` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_bangunan_dan_ac`
--

INSERT INTO `tbl_bangunan_dan_ac` (`id`, `kode_alat`, `username_pemeriksa`, `lokasi`, `tanggal`, `dinas`, `kebersihan_ruangan`, `kondisi_bangunan`, `suhu_ruangan`, `periksa_aliran_udara_evapurator`, `pastikan_unit_outdoor_kompresor_bekerja`, `foto`, `catatan`) VALUES
(1, 'BANGUNANAC', '171019970104B', 'Tower', '2018-08-26', 'Pagi', 'Bersih', 'Baik', 21.5, 'Dingin', 'Ya', '27-08-18_Pagi_BANGUNANAC_IMG_20180309_182437.jpg', 'Kondisi Normal'),
(2, 'BANGUNANAC', '171019970104B', 'Tower', '2018-08-31', 'Pagi', 'Bersih', 'Baik', 21.7, 'Dingin', 'Ya', '31-08-18_Pagi_BANGUNANAC_noimage.png', 'Kondisi Normal');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_cctv`
--

CREATE TABLE `tbl_cctv` (
  `id` int(10) NOT NULL,
  `kode_alat` varchar(10) NOT NULL,
  `username_pemeriksa` varchar(15) NOT NULL,
  `lokasi` varchar(20) NOT NULL,
  `tanggal` date NOT NULL,
  `dinas` enum('Pagi','Malam','','') NOT NULL,
  `suhu_ruangan_kontrol` double NOT NULL,
  `kebersihan_ruangan_kontrol` enum('Bersih','Tidak','','') NOT NULL,
  `kebersihan_bagian_luar_ruangan_kontrol` enum('Bersih','Tidak','','') NOT NULL,
  `foto` varchar(250) NOT NULL,
  `catatan` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_cctv`
--

INSERT INTO `tbl_cctv` (`id`, `kode_alat`, `username_pemeriksa`, `lokasi`, `tanggal`, `dinas`, `suhu_ruangan_kontrol`, `kebersihan_ruangan_kontrol`, `kebersihan_bagian_luar_ruangan_kontrol`, `foto`, `catatan`) VALUES
(1, 'CCTV01', '171019970104B', 'Tower', '2018-08-26', 'Pagi', 21.5, 'Bersih', 'Bersih', '26-08-18_Pagi_CCTV01_IMG_20180310_062132.jpg', 'Kondisi Normal'),
(2, 'CCTV01', '171019970104B', 'Tower', '2018-08-31', 'Pagi', 21, 'Bersih', 'Bersih', '31-08-18_Pagi_CCTV01_noimage.png', 'Kondisi Normal');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_detail_pengecekan`
--

CREATE TABLE `tbl_detail_pengecekan` (
  `id_detail_pengecekan` int(10) NOT NULL,
  `username_pemeriksa` varchar(15) NOT NULL,
  `lokasi` varchar(20) NOT NULL,
  `tanggal` date NOT NULL,
  `dinas` enum('Pagi','Malam','','') NOT NULL,
  `paneldistp` varchar(250) NOT NULL,
  `paneldisp1` varchar(250) NOT NULL,
  `paneldisp2` varchar(250) NOT NULL,
  `ups1` varchar(250) NOT NULL,
  `ups2` varchar(250) NOT NULL,
  `bangunac` varchar(250) NOT NULL,
  `ehfan01` varchar(250) NOT NULL,
  `cctv01` varchar(250) NOT NULL,
  `catatan` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_detail_pengecekan`
--

INSERT INTO `tbl_detail_pengecekan` (`id_detail_pengecekan`, `username_pemeriksa`, `lokasi`, `tanggal`, `dinas`, `paneldistp`, `paneldisp1`, `paneldisp2`, `ups1`, `ups2`, `bangunac`, `ehfan01`, `cctv01`, `catatan`) VALUES
(1, '171019970104B', 'Tower', '2018-08-26', 'Pagi', 'Nilai Parameter Normal', 'Nilai Parameter Normal', 'Nilai Parameter Normal', 'Nilai Parameter Normal', 'Nilai Parameter Normal', 'Kondisi Normal', 'Kondisi Hidup dengan Normal', 'Kondisi Normal', 'Keseluruhan keadaan peralatan dalam kondisi normal'),
(2, '171019970104B', 'Tower', '2018-08-31', 'Pagi', 'Nilai Parameter Normal', 'Nilai Parameter Normal', 'Frekuensi Tidak Normal', 'Nilai Parameter Normal', 'Nilai Parameter Normal', 'Kondisi Normal', 'Kondisi Hidup dengan Normal', 'Kondisi Normal', 'Tidak Normal');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_exhaust_fan`
--

CREATE TABLE `tbl_exhaust_fan` (
  `id` int(10) NOT NULL,
  `kode_alat` varchar(10) NOT NULL,
  `username_pemeriksa` varchar(15) NOT NULL,
  `lokasi` varchar(20) NOT NULL,
  `tanggal` date NOT NULL,
  `dinas` enum('Pagi','Malam','','') NOT NULL,
  `status` enum('Ada','Tidak Ada','','') NOT NULL,
  `kondisi` enum('Hidup','Mati','','') NOT NULL,
  `foto` varchar(250) NOT NULL,
  `catatan` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_exhaust_fan`
--

INSERT INTO `tbl_exhaust_fan` (`id`, `kode_alat`, `username_pemeriksa`, `lokasi`, `tanggal`, `dinas`, `status`, `kondisi`, `foto`, `catatan`) VALUES
(1, 'EHFAN01', '171019970104B', 'Tower', '2018-08-26', 'Pagi', 'Ada', 'Hidup', '26-08-18_Pagi_EHFAN01_noimage.png', 'Kondisi Hidup dengan Normal'),
(2, 'EHFAN01', '171019970104B', 'Tower', '2018-08-31', 'Pagi', 'Ada', 'Hidup', '31-08-18_Pagi_EHFAN01_noimage.png', 'Kondisi Hidup dengan Normal');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_logbookkegiatan`
--

CREATE TABLE `tbl_logbookkegiatan` (
  `id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `kegiatan` varchar(250) DEFAULT NULL,
  `keterangan` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_logbookkegiatan`
--

INSERT INTO `tbl_logbookkegiatan` (`id`, `tanggal`, `kegiatan`, `keterangan`) VALUES
(1, '2018-08-31', '1. 08:00 (Masuk)\r\n2. 09:00 (Penginputan parameter)', 'Kondisi Normal');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_paneldis`
--

CREATE TABLE `tbl_paneldis` (
  `id` int(10) NOT NULL,
  `kode_alat` varchar(10) NOT NULL,
  `username_pemeriksa` varchar(15) NOT NULL,
  `lokasi` varchar(20) NOT NULL,
  `tanggal` date NOT NULL,
  `dinas` enum('Pagi','Malam','','') NOT NULL,
  `tegangan_r` double NOT NULL,
  `tegangan_r_s` double NOT NULL,
  `tegangan_s` double NOT NULL,
  `tegangan_r_t` double NOT NULL,
  `tegangan_t` double NOT NULL,
  `tegangan_t_s` double NOT NULL,
  `arus_r` double NOT NULL,
  `arus_s` double NOT NULL,
  `arus_t` double NOT NULL,
  `frekuensi` double NOT NULL,
  `mode_operasi` enum('Auto','Manual','','') NOT NULL,
  `kebersihan_panel` enum('Baik','Tidak','','') NOT NULL,
  `foto` varchar(250) NOT NULL,
  `catatan` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_paneldis`
--

INSERT INTO `tbl_paneldis` (`id`, `kode_alat`, `username_pemeriksa`, `lokasi`, `tanggal`, `dinas`, `tegangan_r`, `tegangan_r_s`, `tegangan_s`, `tegangan_r_t`, `tegangan_t`, `tegangan_t_s`, `arus_r`, `arus_s`, `arus_t`, `frekuensi`, `mode_operasi`, `kebersihan_panel`, `foto`, `catatan`) VALUES
(1, 'PANELDISTP', '171019970104B', 'Tower', '2018-08-26', 'Pagi', 230, 405, 229, 404, 230, 400, 48.2, 49.5, 39.8, 50.05, 'Auto', 'Baik', '26-08-18_Pagi_PANELDISTP_IMG_20180308_084911.jpg', 'Nilai Parameter Normal'),
(2, 'PANELDISP1', '171019970104B', 'Tower', '2018-08-26', 'Pagi', 230, 398, 225, 397, 228, 399, 96.2, 102.4, 10.3, 50.04, 'Auto', 'Baik', '26-08-18_Pagi_PANELDISP1_IMG_20180308_084911.jpg', 'Nilai Parameter Normal'),
(3, 'PANELDISP2', '171019970104B', 'Tower', '2018-08-26', 'Pagi', 227, 391, 224, 395, 224, 397, 83.7, 74.5, 80.3, 50.22, 'Auto', 'Baik', '26-08-18_Pagi_PANELDISP2_IMG_20180308_084911.jpg', 'Nilai Parameter Normal'),
(4, 'PANELDISTP', '171019970104B', 'Tower', '2018-08-31', 'Pagi', 215, 375, 215, 375, 215, 375, 10, 20, 30, 50, 'Auto', 'Baik', '31-08-18_Pagi_PANELDISTP_noimage.png', 'Nilai Parameter Normal'),
(5, 'PANELDISP1', '171019970104B', 'Tower', '2018-08-31', 'Pagi', 215, 375, 215, 375, 215, 375, 10, 20, 30, 50, 'Auto', 'Baik', '31-08-18_Pagi_PANELDISP1_noimage.png', 'Nilai Parameter Normal'),
(6, 'PANELDISP2', '171019970104B', 'Tower', '2018-08-31', 'Pagi', 215, 375, 215, 375, 215, 375, 10, 20, 30, 49, 'Auto', 'Baik', '31-08-18_Pagi_PANELDISP2_noimage.png', 'Frekuensi Tidak Normal');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_pegawai`
--

CREATE TABLE `tbl_pegawai` (
  `id` int(10) NOT NULL,
  `nik` varchar(15) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `status` enum('Pegawai','Magang','','') NOT NULL,
  `email` varchar(50) NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `foto` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_pegawai`
--

INSERT INTO `tbl_pegawai` (`id`, `nik`, `nama`, `tanggal_lahir`, `alamat`, `status`, `email`, `no_hp`, `foto`) VALUES
(1, '171019970104B', 'Muhammad Bobby Syahdan Lubis', '1997-10-17', 'Jl. pukat 4 no.47 Medan', 'Pegawai', 'muhammadbobby182@gmail.com', '081289435583', '26-08-18_171019970104B_SO-105-300718-0055-001.JPG');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_peralatan_dalam_tower`
--

CREATE TABLE `tbl_peralatan_dalam_tower` (
  `id` int(11) NOT NULL,
  `kode_alat` varchar(10) NOT NULL,
  `nama_alat` varchar(50) NOT NULL,
  `jumlah` int(100) NOT NULL,
  `merek` varchar(50) NOT NULL,
  `kondisi` enum('Baik','Perbaikan','Rusak','') NOT NULL,
  `foto` varchar(250) NOT NULL,
  `keterangan` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_peralatan_dalam_tower`
--

INSERT INTO `tbl_peralatan_dalam_tower` (`id`, `kode_alat`, `nama_alat`, `jumlah`, `merek`, `kondisi`, `foto`, `keterangan`) VALUES
(1, 'PANELDISTP', 'Panel Distribusi Teknikal Priority', 1, 'Unknown', 'Baik', '26-08-18_PANELDISTK_IMG_20180308_084858.jpg', 'Normal'),
(2, 'PANELDISP1', 'Panel Distribusi Teknikal Priority', 1, 'Unknown', 'Baik', '26-08-18_PANELDISP1_IMG_20180308_084719.jpg', 'Normal'),
(3, 'PANELDISP2', 'Panel Distribusi Teknikal Priority', 1, 'Unknown', 'Baik', '26-08-18_PANELDISP2_IMG_20180308_084858.jpg', 'Normal'),
(4, 'UPS1', 'Uninterruptable Power Supply', 1, 'Unknown', 'Baik', '26-08-18_UPS1_IMG_20180305_090326.jpg', 'Normal'),
(5, 'UPS2', 'Uninterruptable Power Supply', 1, 'Unknown', 'Baik', '26-08-18_UPS2_IMG_20180305_090326.jpg', 'Normal'),
(6, 'BANGUNANAC', 'Bangunan Dan AC', 1, 'Unknown', 'Baik', '26-08-18_BANGUNANDA_IMG_20180309_182501.jpg', 'Normal'),
(7, 'EHFAN01', 'Exhaust Fan', 1, 'Unknown', 'Baik', '26-08-18_EHFAN01_noimage.png', 'Normal'),
(8, 'CCTV01', 'CCTV', 1, 'Unknown', 'Baik', '26-08-18_CCTV01_IMG_20180310_062132.jpg', 'Normal');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_perbaikan_alat`
--

CREATE TABLE `tbl_perbaikan_alat` (
  `id_perbaikan_alat` int(10) NOT NULL,
  `kode_alat` varchar(10) NOT NULL,
  `nama_alat` varchar(50) NOT NULL,
  `jumlah_alat` int(100) NOT NULL,
  `merek` varchar(50) NOT NULL,
  `kondisi_alat` enum('Baik','Perbaikan','Rusak','') NOT NULL,
  `tanggal_mulai_perbaikan` date NOT NULL,
  `foto` varchar(250) NOT NULL,
  `keterangan` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_ups`
--

CREATE TABLE `tbl_ups` (
  `id` int(10) NOT NULL,
  `kode_alat` varchar(10) NOT NULL,
  `username_pemeriksa` varchar(15) NOT NULL,
  `lokasi` varchar(20) NOT NULL,
  `tanggal` date NOT NULL,
  `dinas` enum('Pagi','Malam','','') NOT NULL,
  `v_main_r` double NOT NULL,
  `v_main_s` double NOT NULL,
  `v_main_t` double NOT NULL,
  `v_output_r` double NOT NULL,
  `v_output_s` double NOT NULL,
  `v_output_t` double NOT NULL,
  `arus_main_r` double NOT NULL,
  `arus_main_s` double NOT NULL,
  `arus_main_t` double NOT NULL,
  `arus_output_r` double NOT NULL,
  `arus_output_s` double NOT NULL,
  `arus_output_t` double NOT NULL,
  `ups_ld_kva` double NOT NULL,
  `ups_ld_kw` double NOT NULL,
  `ups_ld_pf` double NOT NULL,
  `total_ld_kva` double NOT NULL,
  `total_ld_kw` double NOT NULL,
  `total_ld_pf` double NOT NULL,
  `dc_volt_v` double NOT NULL,
  `dc_volt_a` double NOT NULL,
  `status` enum('Charging','Tidak Charging','','') NOT NULL,
  `operasional` enum('Bypass','Normal','','') NOT NULL,
  `kebersihan_ups` enum('Baik','Tidak','','') NOT NULL,
  `ukuran_tegangan_in_breaker_baterai` double NOT NULL,
  `ukuran_tegangan_out_breaker_baterai` double NOT NULL,
  `suhu_ruangan` double NOT NULL,
  `foto` varchar(250) NOT NULL,
  `catatan` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_ups`
--

INSERT INTO `tbl_ups` (`id`, `kode_alat`, `username_pemeriksa`, `lokasi`, `tanggal`, `dinas`, `v_main_r`, `v_main_s`, `v_main_t`, `v_output_r`, `v_output_s`, `v_output_t`, `arus_main_r`, `arus_main_s`, `arus_main_t`, `arus_output_r`, `arus_output_s`, `arus_output_t`, `ups_ld_kva`, `ups_ld_kw`, `ups_ld_pf`, `total_ld_kva`, `total_ld_kw`, `total_ld_pf`, `dc_volt_v`, `dc_volt_a`, `status`, `operasional`, `kebersihan_ups`, `ukuran_tegangan_in_breaker_baterai`, `ukuran_tegangan_out_breaker_baterai`, `suhu_ruangan`, `foto`, `catatan`) VALUES
(3, 'UPS1', '171019970104B', 'Tower', '2018-08-26', 'Pagi', 398, 391, 399, 230, 230, 230, 18, 19, 18, 38, 33, 25, 11.8, 9.9, 0.88, 22.4, 20.7, 0.93, 404, 0, 'Charging', 'Normal', 'Baik', 404, 404, 20, '26-08-18_Pagi_UPS1_IMG_20180305_090331.jpg', 'Nilai Parameter Normal'),
(4, 'UPS2', '171019970104B', 'Tower', '2018-08-26', 'Pagi', 394, 393, 390, 230, 230, 230, 11, 10, 7, 39, 33, 25, 12.5, 11.1, 0.9, 22.4, 20.6, 0.93, 403, 0, 'Charging', 'Normal', 'Baik', 404, 404, 20, '26-08-18_Pagi_UPS2_IMG_20180305_090326.jpg', 'Nilai Parameter Normal'),
(5, 'UPS1', '171019970104B', 'Tower', '2018-08-31', 'Pagi', 375, 375, 375, 215, 215, 215, 10, 20, 20, 10, 20, 10, 10, 10, 20, 10, 10, 10, 404, 0, 'Charging', 'Normal', 'Baik', 404, 0, 21.7, '31-08-18_Pagi_UPS1_noimage.png', 'Nilai Parameter Normal'),
(6, 'UPS2', '171019970104B', 'Tower', '2018-08-31', 'Pagi', 375, 375, 375, 215, 215, 215, 10, 20, 30, 10, 20, 30, 10, 20, 30, 10, 20, 30, 404, 0, 'Charging', 'Normal', 'Baik', 404, 0, 20.5, '31-08-18_Pagi_UPS2_noimage.png', 'Nilai Parameter Normal');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id_user` int(11) NOT NULL,
  `username` varchar(15) NOT NULL,
  `nama_user` varchar(50) NOT NULL,
  `password` varchar(16) NOT NULL,
  `konfirmasi_password` varchar(16) NOT NULL,
  `level` enum('Admin','User','Jr Manager','') NOT NULL,
  `tanggal_terdaftar` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_user`
--

INSERT INTO `tbl_user` (`id_user`, `username`, `nama_user`, `password`, `konfirmasi_password`, `level`, `tanggal_terdaftar`) VALUES
(1, 'admin', 'admin', 'itsupportairnav', 'itsupportairnav', 'Admin', '2018-08-27'),
(2, '171019970104B', 'Muhammad Bobby Syahdan Lubis', '1701', '1701', 'User', '2018-08-27'),
(3, 'jrmanager', 'JR MANAGER', 'itsupport17', 'itsupport17', 'Jr Manager', '2018-08-31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_bangunan_dan_ac`
--
ALTER TABLE `tbl_bangunan_dan_ac`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_cctv`
--
ALTER TABLE `tbl_cctv`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_detail_pengecekan`
--
ALTER TABLE `tbl_detail_pengecekan`
  ADD PRIMARY KEY (`id_detail_pengecekan`);

--
-- Indexes for table `tbl_exhaust_fan`
--
ALTER TABLE `tbl_exhaust_fan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_logbookkegiatan`
--
ALTER TABLE `tbl_logbookkegiatan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_paneldis`
--
ALTER TABLE `tbl_paneldis`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_pegawai`
--
ALTER TABLE `tbl_pegawai`
  ADD PRIMARY KEY (`id`,`nik`);

--
-- Indexes for table `tbl_peralatan_dalam_tower`
--
ALTER TABLE `tbl_peralatan_dalam_tower`
  ADD PRIMARY KEY (`id`,`kode_alat`);

--
-- Indexes for table `tbl_perbaikan_alat`
--
ALTER TABLE `tbl_perbaikan_alat`
  ADD PRIMARY KEY (`id_perbaikan_alat`);

--
-- Indexes for table `tbl_ups`
--
ALTER TABLE `tbl_ups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id_user`,`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_bangunan_dan_ac`
--
ALTER TABLE `tbl_bangunan_dan_ac`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_cctv`
--
ALTER TABLE `tbl_cctv`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_detail_pengecekan`
--
ALTER TABLE `tbl_detail_pengecekan`
  MODIFY `id_detail_pengecekan` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_exhaust_fan`
--
ALTER TABLE `tbl_exhaust_fan`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tbl_logbookkegiatan`
--
ALTER TABLE `tbl_logbookkegiatan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_paneldis`
--
ALTER TABLE `tbl_paneldis`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tbl_pegawai`
--
ALTER TABLE `tbl_pegawai`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_peralatan_dalam_tower`
--
ALTER TABLE `tbl_peralatan_dalam_tower`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tbl_perbaikan_alat`
--
ALTER TABLE `tbl_perbaikan_alat`
  MODIFY `id_perbaikan_alat` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tbl_ups`
--
ALTER TABLE `tbl_ups`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
