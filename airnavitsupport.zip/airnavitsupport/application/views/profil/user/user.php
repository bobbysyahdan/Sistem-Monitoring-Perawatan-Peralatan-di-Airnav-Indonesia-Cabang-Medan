<?php 

// if ($this->session->userdata('level') == "Admin" || $this->session->userdata('level') == "User")  {

$this->load->view('include/header'); 
$this->load->view('include/navbar'); ?>

 <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
     
      <ol class="breadcrumb" style="margin-top: 10px;">
        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>">Halaman Utama</a>
        </li>
  
        <li class="breadcrumb-item active">Profil Saya</li>
      </ol>

       <div class="pesan error" style="color: green; font-size: 18px; font-weight: bold;">
       <?php 
          echo $this->session->flashdata('pesanerror');
           echo $this->session->flashdata('pesanerror2');
            echo $this->session->flashdata('pesanberhasil2');
            echo $this->session->flashdata('pesanberhasilpassword');

        ?> 
    </div>
      <!-- Example DataTables Card-->
      <?php foreach ($content->result() as $data) {
          # code...
        } ?>

      <div class="card mb-3">
      <div class="card-header">
          <i class="fa fa-user"></i> Profil Saya</div>
        <div class="card-body">
          <div class="table-responsive">
             <div class="container">

        <form action="<?php echo config_item('base_url'); ?>profil/updateprofil/<?= $data->nik ?>" method="post" enctype="multipart/form-data">
           <input type="hidden" name="id" value="<?= $data->id?>">
            <input type="hidden" name="fotolama" value="<?= $data->foto?>">

        
         <div class="form-group">
            <div class="form-row">
               <div class="col-md-5">
                 <img src="<?php echo config_item('fotopegawai'); ?><?= $data->foto ?>"  style="width: 300px; height: 400px;" class="img-thumbnail">
                  <div class="form-row">
                    <div class="col-md-8">
                 <label for="foto" style='margin-top: 10px;'>Ubah Foto</label>
                    <input class="form-control" id="foto" type="file" aria-describedby="nameHelp" name="foto">
                    <small class="form-text text-muted">Masukkan foto yang memiliki ukuran maksimal 3MB.</small>
                  </div>
               </div>
             </div>
        
                  <div class="col-md-6">
                    
                    <label for="nip">NIP</label>
                    <input class="form-control" id="nip" type="text" aria-describedby="nameHelp" name="nip" value="<?= $data->nik?>" required readonly/>

                    <label for="nama">Nama</label>
                    <input class="form-control" id="nama" type="text" aria-describedby="nameHelp" name="nama" value="<?= $data->nama?>" required />

                    <label for="tanggal_lahir">Tanggal Lahir</label>
                    <input class="form-control" id="tanggal_lahir" type="date" aria-describedby="nameHelp" name="tanggal_lahir" value="<?= $data->tanggal_lahir?>" required />

                    <label for="alamat">Alamat</label>
                    <input class="form-control" id="alamat" type="text" aria-describedby="nameHelp" name="alamat"  value="<?= $data->alamat?>" required />

                <label for="status">Status</label>
                  <select class="form-control form-control-sm" id="status" name="status" required />
                        <option><?= $data->status?></option>
                        <option>Pegawai</option>
                        <option>Magang</option>
                       </select>

                    <label for="email">Email</label>
                    <input class="form-control" id="email" type="text" aria-describedby="nameHelp" name="email"  value="<?= $data->email?>" required />

                    <label for="no_hp">No Handphone</label>
                    <input class="form-control" id="no_hp" type="number" aria-describedby="nameHelp" name="no_hp" value="<?= $data->no_hp?>" required />
                    <small class="form-text text-muted">Masukkan nomor handphone maksimal 12 angka.</small>

                    <input class="form-control btn btn-primary" type="submit" value="Update Profil" name="btnUpdate" style='margin-top: 10px;' onclick="return confirm('Apakah anda yakin mengupdate profil anda?');" >
                  </form>
                  <form action="<?php echo config_item('base_url'); ?>profil/ubahpassword/<?= $this->session->userdata('username')?>" method="post" enctype="multipart/form-data">
                    <input class="form-control btn btn-primary" type="submit" value="Ubah Password" name="btnUpdatePassword" style='margin-top: 10px;'>
                  </form>
                  </div>
                  </div>
              </div>
            </div>
      </div>
    </div>
  </div>
</div>

<?php $this->load->view('include/footer');
// } else {
//   redirect('login','refresh');
// }
?>