<?php 

// if ($this->session->userdata('level') == "Admin" || $this->session->userdata('level') == "User")  {

$this->load->view('include/header'); 
$this->load->view('include/navbar'); ?>

 <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
        <ol class="breadcrumb" style="margin-top: 10px;">
        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>">Halaman Utama</a>
        </li>
        <?php if ($this->session->userdata('level') == "User") { ?>
         <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>/profil/profilsaya/<?= $this->session->userdata('username');?>">Profil Saya</a>
        </li>  
      <?php } ?>
        <li class="breadcrumb-item active">Ubah Password</li>
      </ol>

           <div class="pesan error" style="color: green; font-size: 18px; font-weight: bold;">
       <?php 
          echo $this->session->flashdata('pesanerror3');
          echo $this->session->flashdata('pesanerror4');
        ?> 
    </div>
      <!-- Area Chart Example-->
      <div class="card mb-3">
          <div class="card-header">
          <i class="fa fa-key"></i> Ubah Password</div>
          <div class="card-body">

          <?php 
            foreach ($content->result() as $data) {
              # code...
            }
           ?>

           <?php 
              if ($this->session->userdata('level') == 'User') {
            ?>
          <form action="<?php echo config_item('base_url'); ?>profil/action_ubahpassword/<?= $this->session->userdata('username')?>" method="post" enctype="multipart/form-data">
          <?php } elseif ($this->session->userdata('level') == 'Jr Manager') { ?>
            <form action="<?php echo config_item('base_url'); ?>jrmanager/action_ubahpassword/<?= $this->session->userdata('username')?>" method="post" enctype="multipart/form-data">
          <?php } ?>
         <div class="form-group">
               <div class="form-row">
                  <div class="col-md-6">
                    <label for="username">Username</label>
                   <input class="form-control" id="username" type="text" aria-describedby="nameHelp" name="username" value="<?= $data->username?>" required readonly />

                    <label for="passwordlama">Password Lama</label>
                    <input class="form-control" id="passwordlama" type="password" aria-describedby="nameHelp" name="passwordlama" required />


                    <label for="passwordbaru">Password Baru</label>
                    <input class="form-control" id="passwordbaru" type="password" aria-describedby="nameHelp" name="passwordbaru" required  />
                    <small class="form-text text-muted">Masukkan password baru maksimal 16 karakter.</small>


                    <label for="alamat">Konfirmasi Password</label>
                    <input class="form-control" id="konfirmasi_password" type="password" aria-describedby="nameHelp" name="konfirmasi_password"  required /><small class="form-text text-muted">Masukkan konfirmasi password sesuai dengan password baru.</small>
                    <input class="form-control btn btn-primary" type="submit" value="Ubah Password" name="btnUpdatePassword" style='margin-top: 10px;'>
                  </div>
            </div>
      </div>
    </div>
  </div>
</div>

<?php $this->load->view('include/footer');
// } else {
//   redirect('login','refresh');
// }
?>