<?php $this->load->view('include/header'); 
$this->load->library('session');?>

<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Airnav Indonesia</title>
  
  <style type="text/css" media="screen">
    body {
      background-image: url("<?php echo config_item('img'); ?>logo/airnavmedan.png");
      background-repeat: no-repeat;
      background-size: cover;
    }

    .judul_login{
   
      color: #fff;
      text-align: center;
      background-color: #333;
      padding: 10px;
      margin-top: 100px;
      border-radius: 10px;
    }

    .form-login {
      background-color: #ddd;
      padding: 20px;
      margin-bottom: 50px;
      border-radius: 10px;
    }

    .btn-login{
      margin-bottom: 10px;
      margin-top: 10px;
      width: 100%;
    }
    footer{
      position: absolute;
      bottom: 0;
      padding: 10px;
      width: 100%;
      background-color: #333;
      color: #fff;
    }
    .judul-login{
     text-align: center;
     margin-top: 100px;
    }
    .judul-login img{
      width: 200px;
      height: 200px;
      margin-bottom: 20px;
    }

    .pesan{
      text-align: center;
      
    }
</style>

</head>
<body>
<section class="login-container">
   <div class="form-group">
       <div class="form-row">
         <div class="col-md-6">
          <div class="judul-login">
            <img src="<?php echo config_item('img'); ?>logo/airnavindonesia.png" alt="">
            <h3>Aplikasi Monitoring Perawatan Peralatan</h3>
            <h3>di Airnav Indonesia Cabang Medan</h3>
          </div>
        </div>
        <div class="col-md-1"></div>
       <div class="col-md-4">
          <h5 class="judul_login">Halaman Login</h5>
          <div class="form-login">
            <form action="<?php echo config_item('base_url'); ?>login/action_login" method="post">
              <div class="pesan">
               <?php 
                echo $this->session->flashdata('gagallogin');
                 ?>
               </div>
              <div class="form-group">
                <label for="exampleInputEmail1"><img src="<?php echo config_item('img'); ?>icon/person.png" alt="icon name" style="width: 16px;height: 16px;"> username</label>
                <input type="text" class="form-control inputan" id="exampleInputEmail1" placeholder="Masukkan Username" name="username">
                <small id="emailHelp" class="form-text text-muted">Masukkan username sesuai NIP yang sudah terdaftar. Jika belum terdaftar, silahkan hubungi admin dibagian IT support Airnav Indonesia Cabang Medan</small>
                <?php echo form_error('username'); ?>
              </div>

              <div class="form-group">                               
                <label for="exampleInputPassword1"><img src="<?php echo config_item('img'); ?>icon/key.png" alt="icon name" style="width: 16px;height: 16px;">password</label>
                <input type="password" class="form-control inputan" id="exampleInputPassword1" placeholder="Masukkan Password" name="password">
                <?php echo form_error('password'); ?>
              </div>

               <!-- <div class="form-check">
                  <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="remember">
                    Remembe me
                  </label>
                </div> -->
                <input type="submit" class="btn btn-primary btn-login" name="login" value="Login">
            </form>
          </div>
        </div>
    </div>
</div>
</section>

  <footer>
        <div class="text-center">
          <small>Copyright © Airnav Indonesia Cabang Medan <?= date("Y");?></small>
        </div>
      </div>
    </footer>
  <script src="<?php echo config_item('jquery'); ?>"></script>
    <script src="<?php echo config_item('bootstrapjs'); ?>"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo config_item('jquery_easing'); ?>"></script>
    <!-- Page level plugin JavaScript-->
    <script src="<?php echo config_item('chart_js'); ?>Chart.min.js"></script>
    <script src="<?php echo config_item('datatables'); ?>jquery.dataTables.js"></script>
    <script src="<?php echo config_item('datatables'); ?>dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="<?php echo config_item('js'); ?>sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="<?php echo config_item('js'); ?>sb-admin-datatables.min.js"></script>
    <script src="<?php echo config_item('js'); ?>sb-admin-charts.min.js"></script>
</body>
</html>