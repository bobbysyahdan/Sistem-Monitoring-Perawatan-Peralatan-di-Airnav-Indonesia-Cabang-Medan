<?php 

// if ($this->session->userdata('level') == "Admin" || $this->session->userdata('level') == "User")  {

$this->load->view('include/header'); 
$this->load->view('include/navbar'); ?>

 <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb" style="margin-top: 10px;">
        <li class="breadcrumb-item">
          <a href="">Halaman Utama</a>
        </li>
      </ol>
       <div class="pesan error" style="color: green; font-size: 18px; font-weight: bold;">
       <?php 
          echo $this->session->flashdata('pesanerror');
           echo $this->session->flashdata('pesanerror2');
            echo $this->session->flashdata('pesanberhasil2');
            echo $this->session->flashdata('pesanberhasilpassword');
        ?> 
    </div>
      <!-- Area Chart Example-->
      <div class="card mb-3">
        <div class="card-header">
          <div class="alert alert-primary alert-dismissible fade show" 
                          role="alert" style="font-size: 20px; text-align: center;">
                          Selamat datang, <?= $this->session->userdata('username')?><br>
                          di Aplikasi monitoring perawatan peralatan Ainav Indonesia Cabang Medan
                        </div>
          <br>
          
          <div class="gambar text-center" ><img src="<?= config_item('img');?>/logo/airnavmedan.png" alt="airnav medan" style="width: 800px;height: 400px;" class="img-thumbnail" ></div>
      </div>
    </div>
  </div>
</div>

<?php $this->load->view('include/footer');
// } else {
//   redirect('login','refresh');
// }
?>