<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
     <?php if ($this->session->userdata('level') == "Admin") { ?>
    <a class="navbar-brand" href="<?php echo config_item('base_url'); ?>admin" style="font-size: 14px;"><img src="<?php echo config_item('img'); ?>logo/judul.png" class="navbar-brand" style="width: 400px;height: 45px;"></a>
  <?php } elseif ($this->session->userdata('level') == "User") { ?>
    <a class="navbar-brand" href="<?php echo config_item('base_url'); ?>"><img src="<?php echo config_item('img'); ?>logo/judul.png" class="navbar-brand" style="width: 400px;height: 45px;"></a>
  <?php } else if ($this->session->userdata('level') == "Jr Manager") { ?>
    <a class="navbar-brand" href="<?php echo config_item('base_url'); ?>jrmanager" style="font-size: 14px;"><img src="<?php echo config_item('img'); ?>logo/judul.png" class="navbar-brand" style="width: 400px;height: 45px;"></a>
  <?php } ?>

    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">

        <?php if ($this->session->userdata('level') == "Admin") { ?>
          <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="<?php echo config_item('base_url'); ?>admin">
            <i class="fa fa-fw fa-home"></i>
            <span class="nav-link-text">Halaman Utama</span>
          </a>
        </li>
      <?php } ?>

        <?php if ($this->session->userdata('level') == "User") { ?>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="<?php echo config_item('base_url'); ?>">
            <i class="fa fa-fw fa-home"></i>
            <span class="nav-link-text">Halaman Utama</span>
          </a>
        </li>
        

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Menu Levels">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseDalam" data-parent="#exampleAccordion">
            <i class="fa fa-fw fa-tasks"></i>
            <span class="nav-link-text">Perawatan Peralatan</span>
          </a>
          <ul class="sidenav-second-level collapse" id="collapseDalam">

            <li>
              <a class="nav-link-collapse collapsed" data-toggle="collapse" href="#collapsePanel">Panel Distribusi</a>
              <ul class="sidenav-third-level collapse" id="collapsePanel">

                <li>
                  <a href="<?php echo config_item('base_url'); ?>PANELDISTP">Teknikal Priority</a>
                </li>
                <li>
                  <a href="<?php echo config_item('base_url'); ?>PANELDISP1">Priority 1</a>
                </li>
                 <li>
                  <a href="<?php echo config_item('base_url'); ?>PANELDISP2">Priority 2</a>
                </li>
              </ul>
            </li>
            <li>
              <a class="nav-link-collapse collapsed" data-toggle="collapse" href="#collapseUps">UPS</a>
              <ul class="sidenav-third-level collapse" id="collapseUps">
                <li>
                  <a href="<?php echo config_item('base_url'); ?>UPS1">UPS 1</a>
                </li>
                <li>
                  <a href="<?php echo config_item('base_url'); ?>UPS2">UPS 2</a>
                </li>
              </ul>
            </li>

             <li>
              <a class="nav-link-collapse collapsed" data-toggle="collapse" href="#itemchecklist">Item Checklist</a>
              <ul class="sidenav-third-level collapse" id="itemchecklist">
                <li>
                  <a href="<?php echo config_item('base_url'); ?>BANGUNANAC">Bangunan dan AC</a>
                </li>
                 <li>
                  <a href="<?php echo config_item('base_url'); ?>EHFAN01">Exhaust Fan</a>
                </li>
                <li>
                  <a href="<?php echo config_item('base_url'); ?>CCTV01">CCTV</a>
                </li>
              </ul>
            </li>
          </ul>
        </li>
         <?php } ?>


         <?php if ($this->session->userdata('level') == "Jr Manager") { ?>

                  <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="<?php echo config_item('base_url'); ?>jrmanager">
            <i class="fa fa-fw fa-home"></i>
            <span class="nav-link-text">Halaman Utama</span>
          </a>
        </li>
        

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Menu Levels">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseDalam" data-parent="#exampleAccordion">
            <i class="fa fa-fw fa-tasks"></i>
            <span class="nav-link-text">Perawatan Peralatan</span>
          </a>
          <ul class="sidenav-second-level collapse" id="collapseDalam">

            <li>
              <a class="nav-link-collapse collapsed" data-toggle="collapse" href="#collapsePanel">Panel Distribusi</a>
              <ul class="sidenav-third-level collapse" id="collapsePanel">

                <li>
                  <a href="<?php echo config_item('base_url'); ?>jrmanager/PANELDISTP">Teknikal Priority</a>
                </li>
                <li>
                  <a href="<?php echo config_item('base_url'); ?>jrmanager/PANELDISP1">Priority 1</a>
                </li>
                 <li>
                  <a href="<?php echo config_item('base_url'); ?>jrmanager/PANELDISP2">Priority 2</a>
                </li>
              </ul>
            </li>
            <li>
              <a class="nav-link-collapse collapsed" data-toggle="collapse" href="#collapseUps">UPS</a>
              <ul class="sidenav-third-level collapse" id="collapseUps">
                <li>
                  <a href="<?php echo config_item('base_url'); ?>jrmanager/UPS1">UPS 1</a>
                </li>
                <li>
                  <a href="<?php echo config_item('base_url'); ?>jrmanager/UPS2">UPS 2</a>
                </li>
              </ul>
            </li>

             <li>
              <a class="nav-link-collapse collapsed" data-toggle="collapse" href="#itemchecklist">Item Checklist</a>
              <ul class="sidenav-third-level collapse" id="itemchecklist">
                <li>
                  <a href="<?php echo config_item('base_url'); ?>jrmanager/BANGUNANAC">Bangunan dan AC</a>
                </li>
                 <li>
                  <a href="<?php echo config_item('base_url'); ?>jrmanager/EHFAN01">Exhaust Fan</a>
                </li>
                <li>
                  <a href="<?php echo config_item('base_url'); ?>jrmanager/CCTV01">CCTV</a>
                </li>
              </ul>
            </li>
          </ul>
        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="<?php echo config_item('base_url'); ?>jrmanager/detailpengecekan">
            <i class="fa fa-fw fa-check"></i>
            <span class="nav-link-text">Detail Pengecekan</span>
          </a>
        </li>

         <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="<?php echo config_item('base_url'); ?>jrmanager/logbookkegiatan">
            <i class="fa fa-fw fa-book"></i>
            <span class="nav-link-text">Log Book Kegiatan</span>
          </a>
        </li>

         <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="<?php echo config_item('base_url'); ?>jrmanager/pegawai">
            <i class="fa fa-fw fa-users"></i>
            <span class="nav-link-text">Pegawai</span>
          </a>
        </li>

          <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="<?php echo config_item('base_url'); ?>jrmanager/peralatan">
            <i class="fa fa-fw fa-gears"></i>
            <span class="nav-link-text">Data Peralatan</span>
          </a>
        </li>

         <?php } ?>

        <!-- tutup peralatan dalam tower -->

        <!-- Peralatan Luar tower -->

         <!--  <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Menu Levels">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseLuar" data-parent="#exampleAccordion">
            <i class="fa fa-fw fa-group"></i>
            <span class="nav-link-text">Manajemen User</span>
          </a>
          <ul class="sidenav-second-level collapse" id="collapseLuar"> -->
            <!-- <li>
              <a class="nav-link-collapse collapsed" data-toggle="collapse" href="#collapsePanel">Panel Distribusi</a>
              <ul class="sidenav-third-level collapse" id="collapsePanel">

                <li>
                  <a href="<?php echo config_item('base_url'); ?>paneldist_teknikalpriority">Teknikal Priority</a>
                </li>
                <li>
                  <a href="<?php echo config_item('base_url'); ?>paneldist_priority1">Priority 1</a>
                </li>
                 <li>
                  <a href="?page=paneldistpriority2">Priority 2</a>
                </li>
              </ul>
            </li>
            <li>
              <a class="nav-link-collapse collapsed" data-toggle="collapse" href="#collapseUps">UPS</a>
              <ul class="sidenav-third-level collapse" id="collapseUps">
                <li>
                  <a href="">UPS 1</a>
                </li>
                <li>
                  <a href="">UPS 2</a>
                </li>
              </ul>
            </li>

             <li>
              <a class="nav-link-collapse collapsed" data-toggle="collapse" href="#itemchecklist">Item Checklist</a>
              <ul class="sidenav-third-level collapse" id="itemchecklist">
                <li>
                  <a href="">Bangunan dan AC</a>
                </li>
                 <li>
                  <a href="">Exhaust Fan</a>
                </li>
                <li>
                  <a href="">CCTV</a>
                </li>
              </ul>
            </li> -->
        <!--   </ul>
        </li> -->
        <?php if ($this->session->userdata('level') == "Admin") { ?>
         <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="<?php echo config_item('base_url'); ?>admin/manajemenperalatandalamtower">
            <i class="fa fa-fw fa-gears"></i>
            <span class="nav-link-text">Manajemen Peralatan</span>
          </a>
        </li>
         
         <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Menu Levels">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseLuar" data-parent="#exampleAccordion">
            <i class="fa fa-fw fa-group"></i>
            <span class="nav-link-text">Manajemen User</span>
          </a>
          <ul class="sidenav-second-level collapse" id="collapseLuar">

                <li>
                  <a href="<?php echo config_item('base_url'); ?>admin/manajemenpegawai">Pegawai</a>
                </li>
                <li>
                  <a href="<?php echo config_item('base_url'); ?>admin/manajemenuser">User</a>
                </li>
                 </ul>
        </li>
        <?php } ?>
         <?php if ($this->session->userdata('level') == "User") { ?>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="<?php echo config_item('base_url'); ?>detailpengecekan">
            <i class="fa fa-fw fa-check"></i>
            <span class="nav-link-text">Detail Pengecekan</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="<?php echo config_item('base_url'); ?>logbookkegiatan">
            <i class="fa fa-fw fa-book"></i>
            <span class="nav-link-text">Log Book Kegiatan</span>
          </a>
        </li>

         <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="<?php echo config_item('base_url'); ?>perbaikanalat">
            <i class="fa fa-fw fa-wrench"></i>
            <span class="nav-link-text">Perbaikan Alat</span>
          </a>
        </li>

        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="<?php echo config_item('base_url'); ?>Cetaklaporan">
            <i class="fa fa-fw fa-print"></i>
            <span class="nav-link-text">Cetak Laporan</span>
          </a>
        </li>
   <?php } ?>
      
      </ul>
 


      <ul class="navbar-nav sidenav-toggler">
        <li class="nav-item">
          <a class="nav-link text-center" id="sidenavToggler">
            <i class="fa fa-fw fa-angle-left"></i>
          </a>
        </li>
      </ul>

      <?php
          $nip = $this->session->userdata('username');
          // $foto = $this->db->query("SELECT foto from tbl_pegawai where nip = '$nip'");
          // $foto->result();

          $this->db->select('foto');
          $this->db->from('tbl_pegawai');
          $this->db->where('nik', $nip);
          $foto = $this->db->get();
      ?>
       <?php foreach ($foto->result() as $data) {
          # code...
        } ?>
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
        <?php if ($this->session->userdata('level') == "Admin" || $this->session->userdata('level') == "Jr Manager"){ ?>
        <img src="<?php echo config_item('fotopegawai'); ?>default.png" alt="" style="width: 45px;height: 45px; border-radius: 100%; border: solid #fff;">
        <?php } elseif ($this->session->userdata('level') == "User") { ?>
          <img src="<?php echo config_item('fotopegawai'); ?><?= $data->foto?>" alt="" style="width: 45px;height: 45px; border-radius: 100%; border: solid #fff;">
        <?php } ?>
      </li>
        <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false"><?= $this->session->userdata('username')?></a>
    <div class="dropdown-menu">
     <?php if ($this->session->userdata('level') == "Admin" ) { ?>
        <a class="dropdown-item" href="<?php echo config_item('base_url'); ?>admin/ubahpassword/<?= $this->session->userdata('username')?>">Ubah Password</a>
      <?php }elseif ($this->session->userdata('level') == "Jr Manager" ) { ?>
        <a class="dropdown-item" href="<?php echo config_item('base_url'); ?>jrmanager/ubahpassword/<?= $this->session->userdata('username')?>">Ubah Password</a>
      <?php } elseif ($this->session->userdata('level') == "User") { ?>

        <a class="dropdown-item" href="<?php echo config_item('base_url'); ?>profil/profilsaya/<?= $this->session->userdata('username')?>"><i class="fa fa-fw fa-user"></i> Profil Saya</a>
      <?php } ?>

     <!--  <?php if ($this->session->userdata('level') == "Admin") { ?>
        <a class="dropdown-item" href="<?php echo config_item('base_url'); ?>admin/profil">Profil</a>
      <?php } elseif ($this->session->userdata('level') == "User") { ?>

        <a class="dropdown-item" href="<?php echo config_item('base_url'); ?>profil">Profil</a>
      <?php } ?> -->
      <div class="dropdown-divider"></div>
      <a class="dropdown-item" data-toggle="modal" data-target="#exampleModal">
            <i class="fa fa-fw fa-sign-out"></i>Logout</a>
    </div>
  </li>
        <li class="nav-item">
          
        </li>

      </ul>
    </div>
  </nav>