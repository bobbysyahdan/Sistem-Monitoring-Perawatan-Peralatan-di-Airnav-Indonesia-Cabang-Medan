<?php $this->load->view('include/header'); ?>
<?php $this->load->view('include/navbar'); ?>


 <div class="content-wrapper">
   <div class="container-fluid">

    <ol class="breadcrumb" style="margin-top: 10px;">
        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>">Halaman Utama</a>
        </li>

            <li class="breadcrumb-item active">Data Perbaikan Peralatan</li>

      </ol>

   <div class="pesan error" style="color: green; font-size: 18px; font-weight: bold;">
       <?php 
          echo $this->session->flashdata('pesanerror');
          echo $this->session->flashdata('pesanerror2');
          echo $this->session->flashdata('pesanberhasil');
          echo $this->session->flashdata('pesanberhasil2');
        ?> 
    </div>

          <a href="<?php echo config_item('base_url'); ?>perbaikanalat/add" class="btn btn-primary" style="margin-bottom: 10px;"><i class="fa fa-plus"> Menambah Data</a></i>


	<div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> Daftar Tabel Data Perbaikan Peralatan</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered"  id="dataTable"  width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Kode Alat</th>
                  <th>Nama Peralatan</th>
                  <th>Merek</th>
                  <th>Jumlah</th>
                  <th>Kondisi Alat</th>
                  <th>Tanggal Mulai Perbaikan</th>
                  <th>Foto</th>
                  <th>Keterangan<th>
                </tr>
              </thead>
             <tbody>
                <tr>
                <?php 
                  $i = 1;
                  foreach ($content->result() as $data) :
                  ?>
                  <td><?= $i ?></td>
                  <td><?= $data->kode_alat ?></td>
                  <td><?= $data->nama_alat ?></td>
                  <td><?= $data->merek ?></td>
                  <td><?= $data->jumlah_alat ?></td>
                  <td><?= $data->kondisi_alat ?></td>
                  <td><?= $data->tanggal_mulai_perbaikan ?></td>
                  <td><a href="<?php echo config_item('fotoperbaikanalat'); ?><?= $data->foto ?>"><img src="<?php echo config_item('fotoperbaikanalat'); ?><?= $data->foto ?>"  style="width: 50px; height: 50px;"></a></td>
                
                  <td><?= $data->keterangan ?></td>          
                
                 <td>
                    <a href="<?php echo config_item('base_url'); ?>perbaikanalat/update/<?= $data->id_perbaikan_alat ?>" class="btn btn-warning" style="margin-bottom: 1px;"><i class="fa fa-tag"></i></a>
                    <a href="<?php echo config_item('base_url'); ?>perbaikanalat/delete/<?= $data->id_perbaikan_alat ?>" onclick="return confirm('Apakah anda yakin?');" class="btn btn-danger"><i class="fa fa-trash"></i></a>
                  </td> 
               
                </tr>
                    <?php
                      $i++;
                    endforeach;
                  ?>
              </tbody>
        </table>
    </div>
</div>
</div>
</div>
</div>

<?php $this->load->view('include/footer'); ?>