<?php $this->load->view('include/header'); ?>
<?php $this->load->view('include/navbar'); ?>

 <div class="content-wrapper">
   <div class="container-fluid">

    <ol class="breadcrumb" style="margin-top: 10px;">
        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>">Halaman Utama</a>
        </li>
        <li class="breadcrumb-item active">Cetak Laporan</li>
      </ol>

	<div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-print"></i> Cetak Laporan</div>
        <div class="card-body">

          <div class="card-header">
          Cetak Laporan Cheklist Harian Perawatan Semua Peralatan</div>
          <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
              <thead>
                <tr>
                 
                  <th>Lokasi</th>
                  <th>Tanggal</th>
                  <th>Dinas</th>
                  <th>Opsi</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <form action="<?php echo config_item('base_url'); ?>Cetaklaporan/cetaklaporanharian" method="post">
                	
                	<td>Tower</td>
                	<td> <input class="form-control" id="tanggal" type="date" aria-describedby="nameHelp" name="tanggal" value="<?= date('d-m-Y'); ?>" required/></td>
                  <td> <select class="form-control form-control-sm" id="dinas" name="dinas" required/>
                        <option></option>
                        <option>Pagi</option>
                        <option>Malam</option>
                       </select></td>

                       <td><input class="form-control btn btn-primary" type="submit" value="Cetak" name="btnCetak" ></td>
                        </form>       
                 </tr>
            </tbody>
        </table>
    
        
        <div class="card-header">
          Cetak Laporan Checklist Bulanan Peralat</div>

        <table class="table table-bordered" width="100%" cellspacing="0">
              <thead>
                <tr>
               
                  <th>Lokasi</th>
                  <th>Kode Alat</th>
                  <th>Bulan</th>
                  <th>Opsi</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <form action="<?php echo config_item('base_url'); ?>Cetaklaporan/cetaklaporanbulanan" method="post">
                
                  <td>Tower</td>
                  <td><select class="form-control form-control-sm" id="kode_alat" name="kode_alat"  required/>
                    <option></option>
                      <option>PANELDIS</option>
                        <option>UPS</option>
                        <option>BANGUNAN DAN AC</option>
                        <option>EXHAUST FAN</option>
                        <option>CCTV</option>

                   <!--  <?php $kodealat = $this->db->query("SELECT kode_alat FROM tbl_peralatan_dalam_tower ");
                    foreach ($kodealat->result() as $data) : ?>
                             <option><?= $data->kode_alat?></option>
                           <?php endforeach; ?> ?> -->
                       </select></td>
                 <!--  <td><input class="form-control" id="tanggal" type="date" aria-describedby="nameHelp" name="tanggal" value="<?= date('m'); ?>"></td> -->
                  <td> <select class="form-control form-control-sm" id="bulan" name="bulan"  required/>
                    <option></option>
                        <option>01</option>
                        <option>02</option>
                        <option>03</option>
                        <option>04</option>
                        <option>05</option>
                        <option>06</option>
                        <option>07</option>
                        <option>08</option>
                        <option>09</option>
                        <option>10</option>
                        <option>11</option>
                        <option>12</option>

                       </select></td>
                        <td> <select class="form-control form-control-sm" id="tahun" name="tahun"  required/>

                        <?php 
                          $mulai = date('Y')-8;
                          for ($i=$mulai; $i< $mulai+100 ; $i++) { 
                            $sel=$i==date('Y')?'selected="selected"':'';
                            echo'<option value="'.$i.'"'.$sel.'>'.$i.'</option>';
                          }
                         ?>
                       </select></td>
                                

                       <td><input class="form-control btn btn-primary" type="submit" value="Cetak" name="btnCetak" ></td>
                     </form>
                 </tr>
            </tbody>
        </table>
         <div class="card-header">
          Cetak Log Book Kegiatan</div>
          <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
              <thead>
                <tr>

                  <th>Lokasi</th>
                  <th>Tanggal</th>
                  
                  <th>Opsi</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <form action="<?php echo config_item('base_url'); ?>Cetaklaporan/cetaklogbookkegiatan" method="post">
           
                  <td>Tower</td>
                  <td> <input class="form-control" id="tanggal" type="date" aria-describedby="nameHelp" name="tanggal" value="<?= date('d-m-Y'); ?>" required/></td>
                
                       <td><input class="form-control btn btn-primary" type="submit" value="Cetak" name="btnCetak" ></td>
                        </form>       
                 </tr>
            </tbody>
        </table>
      </div>
    </div>


</div>
</div>


</div>
</div>

<?php $this->load->view('include/footer'); ?>