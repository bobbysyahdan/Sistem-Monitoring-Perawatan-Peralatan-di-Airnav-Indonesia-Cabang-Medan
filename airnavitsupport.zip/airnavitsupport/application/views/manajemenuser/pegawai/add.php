<?php $this->load->view('include/header'); ?>
<?php $this->load->view('include/navbar'); ?>

  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->

      <ol class="breadcrumb" style="margin-top: 10px;">
        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>">Halaman Utama</a>
        </li>
         <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>admin/manajemenpegawai">Manajemen Pegawai</a>
        </li>
        
        <li class="breadcrumb-item active">Menambah Data Pegawai</li>
      </ol>

     <div class="pesan error" style="font-size: 16px; font-weight: bold;">
       <?php 
          echo $this->session->flashdata('pesanerror');
          echo $this->session->flashdata('pesanerror2');
          echo $this->session->flashdata('pesanerror3');
        ?> 
    </div>
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-plus"></i> Menambah Data Pegawai</div>
        <div class="card-body">
          <div class="table-responsive">
             <div class="container">

        <form action="<?php echo config_item('base_url'); ?>admin/action_menambahdatapegawai" method="post" enctype="multipart/form-data">

             <div class="form-group">
              <div class="form-row">
                  <div class="col-md-6">
                    <label for="nip">NIK</label>
                    <input class="form-control" id="nip" type="text" aria-describedby="nameHelp" name="nip" required />
                   <!--  <small class="form-text text-muted">Masukkan NIP maksimal 10 angka.</small> -->
                </div>
              
                  <div class="col-md-6">
                    <label for="nama">Nama</label>
                    <input class="form-control" id="nama" type="text" aria-describedby="nameHelp" name="nama" required />
                  </div>
                </div>
              </div>

            <div class="form-group">
              <div class="form-row">
                  <div class="col-md-6">
                    <label for="tanggal_lahir">Tanggal Lahir</label>
                    <input class="form-control" id="tanggal_lahir" type="date" aria-describedby="nameHelp" name="tanggal_lahir" required />
                  </div>

                  <div class="col-md-6">
                    <label for="alamat">Alamat</label>
                    <input class="form-control" id="alamat" type="text" aria-describedby="nameHelp" name="alamat" required />
                  </div>
                </div>
              </div>

             <div class="form-group">
              <div class="form-row">
              <div class="col-md-6">
                <label for="status">Status</label>
                  <select class="form-control form-control-sm" id="status" name="status" required />
                        <option></option>
                        <option>Pegawai</option>
                        <option>Magang</option>
                       </select>
                </div>

                  <div class="col-md-6">
                    <label for="email">Email</label>
                    <input class="form-control" id="email" type="email" aria-describedby="nameHelp" name="email" required />
                  </div>
                </div>
              </div>


               <div class="form-group">
                <div class="form-row">
                  <div class="col-md-6">
                    <label for="no_hp">No Handphone</label>
                    <input class="form-control" id="no_hp" type="number" aria-describedby="nameHelp" name="no_hp" required />
                    <small class="form-text text-muted">Masukkan nomor handphone maksimal 12 angka.</small>
                  </div>
              
                  <div class="col-md-6">
                    <label for="foto">Foto</label>
                    <input class="form-control" id="foto" type="file" aria-describedby="nameHelp" name="foto" required />
                    <small class="form-text text-muted">Masukkan foto ukuran 3x4. Masukkan foto yang memiliki ukuran maksimal 3MB.</small>
                  </div>
                </div>
              </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-2">
                <input class="form-control btn btn-primary" type="submit" value="Simpan" name="btnSimpan" >
              </div>
            </div>
          </div>
          </form>
        </div>
</div>
</div>
</div>
</div>


<?php $this->load->view('include/footer'); ?>