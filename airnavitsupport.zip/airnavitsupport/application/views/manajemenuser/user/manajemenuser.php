<?php $this->load->view('include/header'); ?>
<?php $this->load->view('include/navbar'); ?>

 <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->

      <ol class="breadcrumb" style="margin-top: 10px;">
        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>">Halaman Utama</a>
        </li>
  
        <li class="breadcrumb-item active">Manajemen User</li>
      </ol>

          <a href="<?php echo config_item('base_url'); ?>admin/menambahdatauser" class="btn btn-primary" style="margin-bottom: 10px;"><i class="fa fa-plus"> Menambah Data</a></i>

      <div class="pesan error" style="color: green; font-size: 18px; font-weight: bold;">
       <?php 
          echo $this->session->flashdata('pesanerror');
          echo $this->session->flashdata('pesanerror2');
          echo $this->session->flashdata('pesanberhasil');
          echo $this->session->flashdata('pesanberhasil2');
        ?> 
    </div>

      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> Data Tabel User</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
            
                <tr class="text-center">
                  <th>No</th>
                  <th>Username</th>
                  <th>Nama User</th>
                  <th>Password</th>
                  <th>Konfirmasi Password</th>
                  <th>Level</th>
                  <th>Tanggal Terdaftar</th>
                  <th>Opsi</th>
                </tr>
              </thead>
            <tbody  class="text-center">
                <tr>
                <?php 
                  $i = 1;
                  foreach ($content->result() as $data) : ?>
                  <td><?= $i ?></td>
                  <td><?= $data->username?> </td>
                  <td><?= $data->nama_user ?></td>
                  <td><?= password_hash($data->password,PASSWORD_DEFAULT )?></td>
                  <td><?= password_hash($data->konfirmasi_password,PASSWORD_DEFAULT )?></td>
                  <td><?= $data->level ?></td>
                  <td><?= $data->tanggal_terdaftar ?></td>
                 
                 <td> 
                    <a href="<?php echo config_item('base_url'); ?>admin/updatedatauser/<?= $data->id_user ?>" class="btn btn-warning" style="margin-bottom: 1px;"><i class="fa fa-tag"></i></a>
                    <a href="<?php echo config_item('base_url'); ?>admin/action_deletedatauser/<?= $data->id_user ?>" onclick="return confirm('Apakah anda yakin?');" class="btn btn-danger"><i class="fa fa-trash"></i></a>
                  </td> 
                </tr>
                    <?php
                      $i++;
                    endforeach;
                  ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

<?php $this->load->view('include/footer'); ?>