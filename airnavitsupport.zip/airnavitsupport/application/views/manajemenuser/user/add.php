<?php $this->load->view('include/header'); ?>
<?php $this->load->view('include/navbar'); ?>

  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->

      <ol class="breadcrumb" style="margin-top: 10px;">
        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>">Halaman Utama</a>
        </li>
         <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>admin/manajemenuser">Manajemen User</a>
        </li>
        
        <li class="breadcrumb-item active">Menambah Data User</li>
      </ol>

     <div class="pesan error" style="font-size: 16px; font-weight: bold;">
       <?php 
          echo $this->session->flashdata('pesanerror');
          echo $this->session->flashdata('pesanerror2');
          echo $this->session->flashdata('pesanerror3');
          echo $this->session->flashdata('pesanerror4');
          echo $this->session->flashdata('pesanerror5');
        ?> 
    </div>

      <!--  <?php foreach ($content->result() as $data) {
          # code...
        } ?> -->

      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-plus"></i> Menambah Data Pegawai</div>
        <div class="card-body">
          <div class="table-responsive">
             <div class="container">

        <form action="<?php echo config_item('base_url'); ?>admin/action_menambahdatauser" method="post" enctype="multipart/form-data">

            <div class="form-group">
               <div class="form-row">
                  <div class="col-md-6">
                    <label for="username">Username</label>
                    <select class="form-control" name="username">
                      <?php
                        // $username = $this->db->query("SELECT * from tbl_pegawai") or die (mysql_error());
                        
                          // echo "<option value='$data[1]'>$data[1]</option>";
                           foreach ($content->result() as $data) : ?>
                             <option><?= $data->nik?></option>
                           <?php endforeach; ?>
                 
                   </select>
                  </div>

                  <div class="col-md-6">
                    <label for="nama_user">Nama User</label>
                    <input class="form-control" id="nama_user" type="text" aria-describedby="nameHelp" name="nama_user" required />
                  </div>
                </div>
              </div>

            <div class="form-group">
              <div class="form-row">
                  <div class="col-md-6">
                    <label for="password">Password</label>
                    <input class="form-control" id="password" type="password" aria-describedby="nameHelp" name="password" required />
                    <small class="form-text text-muted">Masukkan password maksimal 16 karakter.</small>
                  </div>

                  <div class="col-md-6">
                    <label for="alamat">Konfirmasi Password</label>
                    <input class="form-control" id="konfirmasi_password" type="password" aria-describedby="nameHelp" name="konfirmasi_password" required /><small class="form-text text-muted">Masukkan konfirmasi password sesuai dengan password.</small>
                  </div>
                </div>
              </div>

             <div class="form-group">
              <div class="form-row">
              <div class="col-md-6">
                <label for="status">Level</label>
                  <select class="form-control form-control-sm" id="level" name="level" required />
                        <option></option>
                        <option>Admin</option>
                        <option>User</option>
                        <option>Jr Manager</option>
                       </select>
                </div>

                  <div class="col-md-6">
                    <label for="tanggal_terdaftar">Tanggal_terdaftar</label>
                    <input class="form-control" id="tanggal_terdaftar" type="date" aria-describedby="nameHelp" name="tanggal_terdaftar" value="<?= date('Y-m-d'); ?>" required />
                  </div>
                </div>
              </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-2">
                <input class="form-control btn btn-primary" type="submit" value="Simpan" name="btnSimpan" >
              </div>
            </div>
          </div>
          </form>
        </div>
</div>
</div>
</div>
</div>


<?php $this->load->view('include/footer'); ?>