<?php $this->load->view('include/header'); ?>
<?php $this->load->view('include/navbar'); ?>

  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->

      <ol class="breadcrumb" style="margin-top: 10px;">
        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>">Halaman Utama</a>
        </li>
         <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>admin/manajemenuser">Manajemen User</a>
        </li>
        
        <li class="breadcrumb-item active">Update Data User</li>
      </ol>

     <div class="pesan error" style="font-size: 16px; font-weight: bold;">
       <?php 
          echo $this->session->flashdata('pesanerror');
          echo $this->session->flashdata('pesanerror2');
          echo $this->session->flashdata('pesanerror3');
          echo $this->session->flashdata('pesanerror4');
          echo $this->session->flashdata('pesanerror5');
        ?> 
    </div>

     <?php foreach ($content->result() as $data) {
          # code...
        } ?>

      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-plus"></i> Update Data User</div>
        <div class="card-body">
          <div class="table-responsive">
             <div class="container">

        <form action="<?php echo config_item('base_url'); ?>admin/action_updatedatauser/<?= $data->id_user ?>" method="post" enctype="multipart/form-data">
          <input type="hidden" name="id_user" value="<?= $data->id_user?>">

            <div class="form-group">
               <div class="form-row">
                  <div class="col-md-6">
                    <label for="username">Username</label>
                   <input class="form-control" id="username" type="text" aria-describedby="nameHelp" name="username" value="<?= $data->username?>" required readonly />
                  </div>

                  <div class="col-md-6">
                    <label for="nama_user">Nama User</label>
                    <input class="form-control" id="nama_user" type="text" aria-describedby="nameHelp" name="nama_user" value="<?= $data->nama_user?>" required />
                  </div>
                </div>
              </div>

            <div class="form-group">
              <div class="form-row">
                  <div class="col-md-6">
                    <label for="password">Password</label>
                    <input class="form-control" id="password" type="password" aria-describedby="nameHelp" name="password" value="<?= $data->password?>" required />
                    <small class="form-text text-muted">Masukkan password maksimal 16 karakter.</small>
                  </div>

                  <div class="col-md-6">
                    <label for="alamat">Konfirmasi Password</label>
                    <input class="form-control" id="konfirmasi_password" type="password" aria-describedby="nameHelp" name="konfirmasi_password" value="<?= $data->konfirmasi_password?>" required />
                    <small class="form-text text-muted">Masukkan konfirmasi password sesuai dengan password.</small>
                  </div>
                </div>
              </div>

             <div class="form-group">
              <div class="form-row">
              <div class="col-md-6">
                <label for="status">Level</label>
                  <select class="form-control form-control-sm" id="level" name="level" readonly />
                        <option><?= $data->level ?></option>
                        <option>Admin</option>
                        <option>User</option>
                        <option>Jr Manager</option>
                       </select>
                </div>

                  <div class="col-md-6">
                    <label for="tanggal_terdaftar">Tanggal_terdaftar</label>
                    <input class="form-control" id="tanggal_terdaftar" type="date" aria-describedby="nameHelp" name="tanggal_terdaftar" value="<?= $data->tanggal_terdaftar ?>" required />
                  </div>
                </div>
              </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-2">
                <input class="form-control btn btn-primary" type="submit" value="Update" name="btnUpdate" >
              </div>
            </div>
          </div>
          </form>
        </div>
</div>
</div>
</div>
</div>


<?php $this->load->view('include/footer'); ?>