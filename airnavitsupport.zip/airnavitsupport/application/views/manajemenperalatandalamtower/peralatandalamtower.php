<?php $this->load->view('include/header'); ?>
<?php $this->load->view('include/navbar'); ?>


 <div class="content-wrapper">
   <div class="container-fluid">

    

    <ol class="breadcrumb" style="margin-top: 10px;">
        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>">Halaman Utama</a>
        </li>
          <?php if ($this->session->userdata('level') == "Admin") { ?>
        <li class="breadcrumb-item active">Manajemen Data Peralatan Dalam Tower</li>
          <?php } elseif ($this->session->userdata('level') == "User") { ?>
            <li class="breadcrumb-item active">Data Peralatan Dalam Tower</li>
          <?php } ?>
      </ol>

          <?php if ($this->session->userdata('level') == "Admin") { ?>
          <a href="<?php echo config_item('base_url'); ?>admin/menambahdataperalatandalamtower" class="btn btn-primary" style="margin-bottom: 10px;"><i class="fa fa-plus"> Menambah Data</a></i>
        <?php } ?>

    <div class="pesan error" style="color: green; font-size: 18px; font-weight: bold;">
       <?php 
          echo $this->session->flashdata('pesanerror');
          echo $this->session->flashdata('pesanerror2');
          echo $this->session->flashdata('pesanberhasil');
          echo $this->session->flashdata('pesanberhasil2');
        ?> 
    </div>

	   <div class="card mb-3">
      <div class="card-header">
          <i class="fa fa-table"></i> Daftar Tabel Data Peralatan Dalam Tower</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable"  width="100%" cellspacing="0">
              <thead>
                <tr class="text-center">
                  <th>No</th>
                  <th>Kode Alat</th>
                  <th>Nama Peralatan</th>
                  <th>Merek</th>
                  <th>Jumlah</th>
                  <th>Kondisi Alat</th>
                  <th>Foto</th>
                  <th>Keterangan<th>
                 
                </tr>
              </thead>
             <tbody>
                <tr>
                <?php 
                  $i = 1;
                  foreach ($content->result() as $data) :
                  ?>
                  <td><?= $i ?></td>
                  <td><?= $data->kode_alat ?></td>
                  <td><?= $data->nama_alat ?></td>
                  <td><?= $data->merek ?></td>
                  <td><?= $data->jumlah ?></td>
                  <td><?= $data->kondisi ?></td>
                  <td><a href="<?php echo config_item('fotoperalatandalamtower'); ?><?= $data->foto ?>"><img src="<?php echo config_item('fotoperalatandalamtower'); ?><?= $data->foto ?>" style="width: 50px; height: 50px;" /></a></td>
                  
                  <td><?= $data->keterangan ?></td>
                
                <?php if ($this->session->userdata('level') == "Admin") { ?>
                 <td>
                    <!-- <a href="<?php echo config_item('base_url'); ?>paneldist_teknikalpriority/read/<?= $data->id ?> ?>"><i class="fa fa-eye"></i></a> | -->
                    <a href="<?php echo config_item('base_url'); ?>admin/updatedataperalatandalamtower/<?= $data->id ?>" class="btn btn-warning" style="margin-bottom: 1px;"><i class="fa fa-tag"></i></a>
                    <a href="<?php echo config_item('base_url'); ?>admin/action_deletedataperalatandalamtower/<?= $data->id ?>" onclick="return confirm('Apakah anda yakin?');" class="btn btn-danger"><i class="fa fa-trash"></i></a>
                  </td> 
                   <?php } elseif ($this->session->userdata('level') == "Jr Manager") { ?>
                  <td>
                   
                    <a href="<?php echo config_item('base_url'); ?>jrmanager/<?= $data->kode_alat?>" class="btn btn-primary" style="margin-bottom: 1px;"><i class="fa fa-eye"></i> Show</a></td>
               <?php } elseif ($this->session->userdata('level') == "User") { ?>
                  <td>
                   
                    <a href="<?php echo config_item('base_url'); ?><?= $data->kode_alat?>" class="btn btn-primary" style="margin-bottom: 1px;"><i class="fa fa-eye"></i> Show</a>
               <?php } ?></td>
                </tr>
                    <?php
                      $i++;
                    endforeach;
                  ?>
              </tbody>
        </table>

</div>
</div>
</div>
</div>
</div>

<?php $this->load->view('include/footer'); ?>