<?php $this->load->view('include/header'); ?>
<?php $this->load->view('include/navbar'); ?>

  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->

      <ol class="breadcrumb" style="margin-top: 10px;">
        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>">Halaman Utama</a>
        </li>
         <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>peralatan_dalam_tower">Peralatan Dalam Tower</a>
        </li>
        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>BANGUNANAC">Bangunan dan AC</a>
        </li>

        <li class="breadcrumb-item active">Update Data</li>
      </ol>
      
       <div class="pesan error" style="font-size: 16px; font-weight: bold;">
       <?php 
          echo $this->session->flashdata('pesanerror');
          echo $this->session->flashdata('pesanerror2');
          echo $this->session->flashdata('pesanerror3');
        ?> 
    </div>
    
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-tag"></i> Update Data Bangunan dan AC</div>
        <div class="card-body">
          <div class="table-responsive">
             <div class="container">

        <?php foreach ($content->result() as $data) {
          # code...
        } ?>
       <form action="<?php echo config_item('base_url'); ?>BANGUNANAC/action_update/<?= $data->id ?>" method="post" enctype="multipart/form-data">
          <input type="hidden" name="id" value="<?= $data->id ?>">
          <input type="hidden" name="fotolama"  value="<?= $data->foto ?>">
           <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="kode_alat">Kode Alat</label>
                <input class="form-control" id="kode_alat" type="text" aria-describedby="nameHelp" name="kode_alat" value="<?= $data->kode_alat ?>" required readonly/>
              </div>
              
              <div class="col-md-6">
                <label for="username_pemeriksa">Username Pemeriksa</label>
                <input class="form-control" id="username_pemeriksa" type="text" aria-describedby="nameHelp" name="username_pemeriksa" value="<?= $data->username_pemeriksa ?>" required readonly />
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <label for="lokasi">Lokasi</label>
                <input class="form-control" id="lokasi" type="text" aria-describedby="nameHelp" name="lokasi" value="<?= $data->lokasi?>" required readonly/>
              </div>
              <div class="col-md-4">
                <label for="tanggal">Tanggal</label>
                <input class="form-control" id="tanggal" type="date" aria-describedby="nameHelp" name="tanggal" value="<?= $data->tanggal ?>" required readonly/>
              </div>
              <div class="col-md-4">
                <label for="dinas">Dinas</label>
                  <select class="form-control form-control-sm" id="dinas" name="dinas" required readonly/>
                        <option><?= $data->dinas ?></option>
                        <option>Pagi</option>
                        <option>Malam</option>
                       </select>
              </div>
            </div>
          </div>

            <div class="form-group">
              <div class="form-row">
                  <div class="col-md-12">
                    <label for="suhu_ruangan">Suhu Ruangan (Celcius)</label>
                    <input class="form-control" id="suhu_ruangan" type="text" aria-describedby="nameHelp" name="suhu_ruangan" value='<?= $data->suhu_ruangan ?>'>
                  </div>
                </div>
              </div>

            <div class="form-group">
              <div class="form-row">
                <div class="col-md-3">
                <label for="kebersihan_ruangan">Kebersihan Ruangan</label>
                <div class="col-sm-12 radio">
                  <?php 
                    if ($data->kebersihan_ruangan == "Bersih") { ?>
                  <label>
                    <input type="radio" name="kebersihan_ruangan" id="kebersihan_ruangan" value="Bersih" checked/>Bersih
                  </label>
                  <label style="margin-left: 30px;">
                    <input type="radio" name="kebersihan_ruangan" id="kebersihan_ruangan" value="Tidak">Tidak
                  </label>
                  <?php 
                } elseif ($data->kebersihan_ruangan == "Tidak") { ?>
                  <label>
                    <input type="radio" name="kebersihan_ruangan" id="kebersihan_ruangan" value="Bersih">Bersih
                  </label>
                  <label style="margin-left: 30px;">
                    <input type="radio" name="kebersihan_ruangan" id="kebersihan_ruangan" value="Tidak" checked/>Tidak
                  </label>
                <?php } ?>
                </div>
              </div>

               <div class="col-md-3">
                <label for="kondisi_bangunan">Kondisi Bangunan</label>
                <div class="col-sm-12 radio">

                  <?php if ($data->kondisi_bangunan == "Baik") { ?>
                  <label>
                    <input type="radio" name="kondisi_bangunan" id="kondisi_bangunan" value="Baik" checked />Baik
                  </label>
                  <label style="margin-left: 30px;">
                    <input type="radio" name="kondisi_bangunan" id="kondisi_bangunan" value="Tidak">Tidak
                  </label>
                  <?php 
                } elseif ($data->kondisi_bangunan == "Tidak") { ?>
                <label>
                    <input type="radio" name="kondisi_bangunan" id="kondisi_bangunan" value="Baik">Baik
                  </label>
                  <label style="margin-left: 30px;">
                    <input type="radio" name="kondisi_bangunan" id="kondisi_bangunan" value="Tidak" checked/>Tidak
                  </label>
                  <?php } ?>
                </div>
              </div>

              <div class="col-md-3">
                <label for="periksa_aliran_udara_evapurator">Periksa Aliran Udara Evapurator</label>
                <div class="col-sm-12 radio">
                  <?php if ($data->periksa_aliran_udara_evapurator == "Dingin") { ?>
                  <label>
                    <input type="radio" name="periksa_aliran_udara_evapurator" id="periksa_aliran_udara_evapurator" value="Dingin" checked />Dingin
                  </label>
                  <label style="margin-left: 30px;">
                    <input type="radio" name="periksa_aliran_udara_evapurator" id="periksa_aliran_udara_evapurator" value="Tidak">Tidak
                  </label>
                  <?php 
                } elseif ($data->periksa_aliran_udara_evapurator == "Tidak") { ?>
                  <label>
                    <input type="radio" name="periksa_aliran_udara_evapurator" id="periksa_aliran_udara_evapurator" value="Dingin">Dingin
                  </label>
                  <label style="margin-left: 30px;">
                    <input type="radio" name="periksa_aliran_udara_evapurator" id="periksa_aliran_udara_evapurator" value="Tidak" checked />Tidak
                  </label>
               <?php } ?>
                </div>
              </div>

               <div class="col-md-3">
                <label for="pastikan_unit_outdoor_kompresor_bekerja">Pastikan Unit Outdoor Kompresor</label>
                <div class="col-sm-12 radio">
                  <?php if ($data->pastikan_unit_outdoor_kompresor_bekerja == "Ya") { ?>
                  <label>
                    <input type="radio" name="pastikan_unit_outdoor_kompresor_bekerja" id="pastikan_unit_outdoor_kompresor_bekerja" value="Ya" checked />Ya
                  </label>
                  <label style="margin-left: 30px;">
                    <input type="radio" name="pastikan_unit_outdoor_kompresor_bekerja" id="pastikan_unit_outdoor_kompresor_bekerja" value="Tidak">Tidak
                  </label>
                  <?php 
                } elseif ($data->pastikan_unit_outdoor_kompresor_bekerja == "Tidak") { ?>
                 <label>
                    <input type="radio" name="pastikan_unit_outdoor_kompresor_bekerja" id="pastikan_unit_outdoor_kompresor_bekerja" value="Ya">Ya
                  </label>
                  <label style="margin-left: 30px;">
                    <input type="radio" name="pastikan_unit_outdoor_kompresor_bekerja" id="pastikan_unit_outdoor_kompresor_bekerja" value="Tidak" checked />Tidak
                  </label>
                  <?php } ?>
                </div>
              </div>
            </div>
          </div>

               <div class="form-group">
                <div class="form-row">
                  <div class="col-md-12">
                    <label for="foto">Foto</label>
                    <input class="form-control" id="foto" type="file" aria-describedby="nameHelp" name="foto">
                  </div>
                </div>
              </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-2">
                <input class="form-control btn btn-primary" type="submit" value="Update" name="btnUpdate" >
              </div>
            </div>
          </div>
          </form>
        </div>
</div>
</div>
</div>
</div>


<?php $this->load->view('include/footer'); ?>