<?php $this->load->view('include/header'); ?>
<?php $this->load->view('include/navbar'); ?>

  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->

       <ol class="breadcrumb" style="margin-top: 10px;">
        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>">Halaman Utama</a>
        </li>
         <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>peralatandalamtower">Peralatan Dalam Tower</a>
        </li>

        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>CCTV01">CCTV</a>
        </li>
        <li class="breadcrumb-item active">Update Data </li>
      </ol>
        <div class="pesan error" style="font-size: 16px; font-weight: bold;">
       <?php 
          echo $this->session->flashdata('pesanerror');
          echo $this->session->flashdata('pesanerror2');
          echo $this->session->flashdata('pesanerror3');
        ?> 
    </div>
      <?php foreach ($content->result() as $data) {
        # code...
      } ?>

       <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-tag"></i> Update Data CCTV</div>
        <div class="card-body">
          <div class="table-responsive">
             <div class="container">

      <form action="<?php echo config_item('base_url'); ?>CCTV01/action_update/<?= $data->id ?>" method="post" enctype="multipart/form-data">
          <input type="hidden" name="id" value="<?= $data->id ?>">
          <input type="hidden" name="fotolama"  value="<?= $data->foto ?>">
           <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="kode_alat">Kode Alat</label>
                <input class="form-control" id="kode_alat" type="text" aria-describedby="nameHelp" name="kode_alat" value="<?= $data->kode_alat ?>" required readonly/>
              </div>
              
              <div class="col-md-6">
                <label for="username_pemeriksa">Username Pemeriksa</label>
                <input class="form-control" id="username_pemeriksa" type="text" aria-describedby="nameHelp" name="username_pemeriksa" value="<?= $data->username_pemeriksa ?>" required readonly />
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <label for="lokasi">Lokasi</label>
                <input class="form-control" id="lokasi" type="text" aria-describedby="nameHelp" name="lokasi" value="<?= $data->lokasi?>" required readonly/>
              </div>
              <div class="col-md-4">
                <label for="tanggal">Tanggal</label>
                <input class="form-control" id="tanggal" type="date" aria-describedby="nameHelp" name="tanggal" value="<?= $data->tanggal ?>" required readonly/>
              </div>
              <div class="col-md-4">
                <label for="dinas">Dinas</label>
                  <select class="form-control form-control-sm" id="dinas" name="dinas" required readonly/>
                        <option><?= $data->dinas ?></option>
                        <option>Pagi</option>
                        <option>Malam</option>
                       </select>
              </div>
            </div>
          </div>

            <div class="form-group">
              <div class="form-row">
                  <div class="col-md-12">
                    <label for="suhu_ruangan_kontrol">Suhu Ruangan Kontrol(Celcius)</label>
                    <input class="form-control" id="suhu_ruangan_kontrol" type="text" aria-describedby="nameHelp" name="suhu_ruangan_kontrol" value="<?= $data->suhu_ruangan_kontrol ?>" required/>
                  </div>
                </div>
              </div>

            <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                <label for="kebersihan_ruangan_kontrol">Kebersihan Ruangan Kontrol</label>
                <div class="col-sm-12 radio">
                  <?php if ($data->kebersihan_ruangan_kontrol == "Bersih") { ?>
                  <label>
                    <input type="radio" name="kebersihan_ruangan_kontrol" id="kebersihan_ruangan_kontrol" value="Bersih" checked required />Bersih
                  </label>
                  <label style="margin-left: 30px;">
                    <input type="radio" name="kebersihan_ruangan_kontrol" id="kebersihan_ruangan_kontrol" value="Tidak" required/>Tidak
                  </label>
                  <?php } elseif ($data->kebersihan_ruangan_kontrol == "Tidak") { ?>
                  <label>
                    <input type="radio" name="kebersihan_ruangan_kontrol" id="kebersihan_ruangan_kontrol" value="Bersih" required/>Bersih
                  </label>
                  <label style="margin-left: 30px;">
                    <input type="radio" name="kebersihan_ruangan_kontrol" id="kebersihan_ruangan_kontrol" value="Tidak" checked required/>Tidak
                  </label>
                  <?php } ?>
                </div>
              </div>

               <div class="col-md-6">
                <label for="kebersihan_bagian_luar_ruangan_kontrol">Kebersihan Bagian Luar Ruangan Kontrol</label>
                <div class="col-sm-12 radio">
                  <?php if ($data->kebersihan_bagian_luar_ruangan_kontrol == "Bersih") { ?>
                  <label>
                    <input type="radio" name="kebersihan_bagian_luar_ruangan_kontrol" id="kebersihan_bagian_luar_ruangan_kontrol" value="Bersih" checked required/>Bersih
                  </label>
                  <label style="margin-left: 30px;">
                    <input type="radio" name="kebersihan_bagian_luar_ruangan_kontrol" id="kebersihan_bagian_luar_ruangan_kontrol" value="Tidak" required/>Tidak
                  </label>
                  <?php } elseif ($data->kebersihan_bagian_luar_ruangan_kontrol == "Tidak") { ?>
                  <label>
                    <input type="radio" name="kebersihan_bagian_luar_ruangan_kontrol" id="kebersihan_bagian_luar_ruangan_kontrol" value="Bersih" required/>Bersih
                  </label>
                  <label style="margin-left: 30px;">
                    <input type="radio" name="kebersihan_bagian_luar_ruangan_kontrol" id="kebersihan_bagian_luar_ruangan_kontrol" value="Tidak" checked required/>Tidak
                  </label>
                  <?php } ?>
                </div>
              </div>
            </div>

               <div class="form-group">
                <div class="form-row">
                  <div class="col-md-12">
                    <label for="foto">Foto</label>
                    <input class="form-control" id="foto" type="file" aria-describedby="nameHelp" name="foto" >
                  </div>
                </div>
              </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-2">
                <input class="form-control btn btn-primary" type="submit" value="Update" name="btnUpdate" >
              </div>
            </div>
          </div>
          </form>
        </div>
</div>
</div>
</div>
</div>


<?php $this->load->view('include/footer'); ?>