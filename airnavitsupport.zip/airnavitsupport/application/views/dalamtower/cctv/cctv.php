<?php $this->load->view('include/header'); ?>
<?php $this->load->view('include/navbar'); ?>

 <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->

    <?php if ($this->session->userdata('level') == "User") { ?>

      <ol class="breadcrumb" style="margin-top: 10px;">
        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>">Halaman Utama</a>
        </li>
         <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>peralatandalamtower">Peralatan Dalam Tower</a>
        </li>
      <?php } ?>

      <?php if ($this->session->userdata('level') == "Jr Manager") { ?>
         <ol class="breadcrumb" style="margin-top: 10px;">
        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>jrmanager">Halaman Utama</a>
        </li>
         <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>jrmanager/peralatan">Peralatan Dalam Tower</a>
        </li>
      <?php } ?>


        <li class="breadcrumb-item active">CCTV</li>
      </ol>
         <?php if ($this->session->userdata('level') == "User") { ?>
          <a href="<?php echo config_item('base_url'); ?>CCTV01/inputparameterharian" class="btn btn-primary" style="margin-bottom: 10px;"><i class="fa fa-plus"> Checklist Harian</a></i>
        <?php } ?>

      <div class="pesan error" style="color: green; font-size: 18px; font-weight: bold;">
       <?php 
          echo $this->session->flashdata('pesanberhasil');
           echo $this->session->flashdata('pesanberhasilhapus');
        ?> 
    </div>

      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> Data Tabel CCTV</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr class="text-center">
                  <th colspan="6"></th>
                  <th colspan="3">Checklist / Parameter</th>
                  <th colspan="2"></th>
                </tr>
                <tr>
                   <th>No</th>
                  <th>Kode Alat</th>
                  <th>Username Pemeriksa</th>
                  <th>Lokasi</th>
                  <th>Tanggal</th>
                  <th>Dinas</th>
                  <th>Suhu Ruangan Kontrol</th>
                  <th>Kebersihan Ruangan Kontrol</th>
                  <th>Kebersihan Bagian Luar Ruangan Kontrol</th>
                  <th>Foto</th>
                  <th>Catatan</th>
                  <?php if ($this->session->userdata('level') == "User") { ?>
                  <th>Opsi</th>
                <?php } ?>
                </tr>
              </thead>
              <tbody>
                <tr>
                <?php 
                  $i = 1;
                  foreach ($content->result() as $data) :
                  ?>
                  <td><?= $i ?></td>
                  <td><?= $data->kode_alat ?></td>
                  <td><?= $data->username_pemeriksa ?></td>
                  <td><?= $data->lokasi ?></td>
                  <td><?= $data->tanggal ?></td>
                  <td><?= $data->dinas ?></td>
                  <td><?= $data->suhu_ruangan_kontrol ?></td>
                  <td><?= $data->kebersihan_ruangan_kontrol ?></td>
                  <td><?= $data->kebersihan_bagian_luar_ruangan_kontrol ?></td>
                   <td><a href="<?php echo config_item('cctv'); ?><?= $data->foto ?>"><img src="<?php echo config_item('cctv'); ?><?= $data->foto ?>"  style="width: 50px; height: 50px;"></a></td>
                  
                    <?php if($data->catatan == "Kondisi Normal"){ ?>
                    <td style="color: blue; font-size: 20px;"><?= $data->catatan ?></td>
                      <?php } elseif ($data->catatan == "Suhu Ruangan Terlalu Panas") { ?>
                      <td style="color: red; font-size: 15px;"><?= $data->catatan ?></td>
                    <?php } ?>
                   <?php if ($this->session->userdata('level') == "User") { ?>
                 <td>
                    <!-- <a href="<?php echo config_item('base_url'); ?>paneldist_teknikalpriority/read/<?= $data->id ?> ?>"><i class="fa fa-eye"></i></a> | -->
                    <a href="<?php echo config_item('base_url'); ?>CCTV01/update/<?= $data->id ?>" class="btn btn-warning" style="margin-bottom: 1px;"><i class="fa fa-tag"></i></a>
                    <a href="<?php echo config_item('base_url'); ?>CCTV01/delete/<?= $data->id ?>" onclick="return confirm('Apakah anda yakin?');" class="btn btn-danger"><i class="fa fa-trash"></i></a>
                  </td> 
                <?php } ?>
                </tr>
                    <?php
                      $i++;
                    endforeach;
                  ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>


<?php $this->load->view('include/footer'); ?>