<?php $this->load->view('include/header'); ?>
<?php $this->load->view('include/navbar'); ?>

  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->

      <ol class="breadcrumb" style="margin-top: 10px;">
        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>">Halaman Utama</a>
        </li>
         <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>peralatan_dalam_tower">Peralatan Dalam Tower</a>
        </li>
        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>PANELDISP1">Panel Distribusi Priority 1</a>
        </li>
        <li class="breadcrumb-item active">Update Data</li>
      </ol>
      
       <div class="pesan error" style="font-size: 16px; font-weight: bold;">
       <?php 
          echo $this->session->flashdata('pesanerror');
          echo $this->session->flashdata('pesanerror2');
          echo $this->session->flashdata('pesanerror3');
        ?> 
    </div>
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-tag"></i> Update Data Panel Distribusi - Priority 1</div>
        <div class="card-body">
          <div class="table-responsive">
             <div class="container">

        <?php foreach ($content->result() as $data) {
          # code...
        } ?>
        <form action="<?php echo config_item('base_url'); ?>PANELDISP1/action_update/<?= $data->id ?>" method="post" enctype="multipart/form-data">
          <input type="hidden" name="id" value="<?= $data->id ?>">
          <input type="hidden" name="fotolama"  value="<?= $data->foto ?>">
           <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="kode_alat">Kode Alat</label>
                <input class="form-control" id="kode_alat" type="text" aria-describedby="nameHelp" name="kode_alat" value="<?= $data->kode_alat ?>" required readonly/>
              </div>
              
              <div class="col-md-6">
                <label for="username_pemeriksa">Username Pemeriksa</label>
                <input class="form-control" id="username_pemeriksa" type="text" aria-describedby="nameHelp" name="username_pemeriksa" value="<?= $data->username_pemeriksa ?>" required readonly />
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <label for="lokasi">Lokasi</label>
                <input class="form-control" id="lokasi" type="text" aria-describedby="nameHelp" name="lokasi" value="<?= $data->lokasi?>" required readonly/>
              </div>
              <div class="col-md-4">
                <label for="tanggal">Tanggal</label>
                <input class="form-control" id="tanggal" type="date" aria-describedby="nameHelp" name="tanggal" value="<?= $data->tanggal ?>" required readonly/>
              </div>
              <div class="col-md-4">
                <label for="dinas">Dinas</label>
                  <select class="form-control form-control-sm" id="dinas" name="dinas" required readonly/>
                        <option><?= $data->dinas ?></option>
                        <option>Pagi</option>
                        <option>Malam</option>
                       </select>
              </div>
            </div>
          </div>

           <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <label for="teganganr">Tegangan(Volt) R</label>
                <input class="form-control" id="teganganr" type="number" step="any" aria-describedby="nameHelp" name="teganganr" value="<?= $data->tegangan_r ?>" required />
              </div>
               <div class="col-md-4">
                <label for="teganganrs">Tegangan(Volt) R-S</label>
                <input class="form-control" id="teganganrs" type="number" step="any" aria-describedby="nameHelp" name="teganganrs" value="<?= $data->tegangan_r_s?>" required />
              </div>
               <div class="col-md-4">
                <label for="tegangans">Tegangan(Volt) S</label>
                <input class="form-control" id="tegangans" type="number" step="any" aria-describedby="nameHelp" name="tegangans" value="<?= $data->tegangan_s ?>" required />
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <label for="teganganrt">Tegangan(Volt) R-T</label>
                <input class="form-control" id="teganganrt" type="number" step="any" aria-describedby="nameHelp" name="teganganrt" value="<?= $data->tegangan_r_t ?>" required />
              </div>
               <div class="col-md-4">
                <label for="tegangant">Tegangan(Volt) T</label>
                <input class="form-control" id="tegangant" type="number" step="any" aria-describedby="nameHelp" name="tegangant" value="<?= $data->tegangan_t ?>" required />
              </div>
               <div class="col-md-4">
                <label for="tegangantts">Tegangan(Volt) T-S</label>
                <input class="form-control" id="tegangants" type="number" step="any" aria-describedby="nameHelp" name="tegangants" value="<?= $data->tegangan_t_s ?>" required />
              </div>
            </div>
          </div>

           <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <label for="arusr">Arus(Ampere) R</label>
                <input class="form-control" id="arusr" type="number" step="any" aria-describedby="nameHelp" name="arusr" value="<?= $data->arus_r ?>" required />
              </div>
               <div class="col-md-4">
                <label for="aruss">Arus(Ampere) S</label>
                <input class="form-control" id="aruss" type="number" step="any" aria-describedby="nameHelp" name="aruss" value="<?= $data->arus_s ?>" required />
              </div>
               <div class="col-md-4">
                <label for="arust">Arus(Ampere) T</label>
                <input class="form-control" id="arust" type="number" step="any" aria-describedby="nameHelp" name="arust" value="<?= $data->arus_t ?>" required />
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <label for="frekuensi">Frekuensi (Hz)</label>
                <input class="form-control" id="frekuensi" name="frekuensi" type="number" step="any" aria-describedby="nameHelp" value="<?= $data->frekuensi ?>" required />
              </div>

              <div class="col-md-4">
                <label for="mode_operasi">Mode Operasi</label>
                <div class="col-sm-8 radio">
                  
                  <?php
                  
                  if ($data->mode_operasi == "Auto") {
                    ?>
                    <label>
                    <input type="radio" name="mode_operasi" id="modeoperasi" value="Auto" checked required />Auto
                    </label>
                    <label style="margin-left: 30px;">
                    <input type="radio" name="mode_operasi" id="modeoperasi" value="Manual" required />Manual
                    </label>
                  <?php
                  
                  } elseif ($data->mode_operasi == "Manual") {
                    ?>
                  <label>
                    <input type="radio" name="mode_operasi" id="mode_operasi" value="Auto" required />Auto
                    </label>
                    <label style="margin-left: 30px;">
                    <input type="radio" name="mode_operasi" id="mode_operasi" value="Manual" checked required />Manual
                    </label>
                  <?php
                  }
                  ?>
                </div>
              </div>

              <div class="col-md-4">
                <label for="kebersihan">Kebersihan Panel</label>
                <div class="col-sm-8 radio">

                     <?php
                  
                  if ($data->kebersihan_panel == "Baik") {
                    ?>
                    <label>
                    <input type="radio" name="kebersihan_panel" id="kebersihan_panel" value="Baik" checked required />Baik
                    </label>
                    <label>
                    <input type="radio" name="kebersihan_panel" id="kebersihan_panel" value="Tidak" required />Tidak
                    </label>
                  <?php
                  
                  } elseif ($data->kebersihan_panel == "Tidak") {
                    ?>
                    <label style="margin-right: 30px;">
                    <input type="radio" name="kebersihan_panel" id="kebersihan_panel" value="Baik" required />Baik
                    </label>
                    <label>
                      <input type="radio" name="kebersihan_panel" id="kebersihan_panel" value="Tidak" checked required />Tidak
                    </label>
                  <?php
                  }
                  ?>
                </div>
            </div>
          </div>
        </div>

          <div class="form-group">
                <div class="form-row">
                  <div class="col-md-12">
                    <label for="foto">Foto</label>
                    <input class="form-control" id="foto" type="file" aria-describedby="nameHelp" name="foto"/>
                  </div>
                </div>
              </div>

          <!-- <div class="form-group">
            <div class="form-row">
              <div class="col-md-12">
                <label for="catatan">Catatan</label>
                <textarea rows="4" class="form-control" cols="50" name="catatan" placeholder="Masukkan Catatan" ><?= $data->catatan ?></textarea>
              </div>
            </div>
          </div> -->

          <input type="hidden" name="catatan" value="<?= $data->catatan ?>">
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-2">
                <input class="form-control btn btn-primary" type="submit" value="Update" name="btnUpdate" >
              </div>
            </div>
          </div>
          </form>
        </div>
</div>
</div>
</div>
</div>

<?php $this->load->view('include/footer'); ?>
