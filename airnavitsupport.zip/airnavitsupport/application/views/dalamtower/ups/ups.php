<?php $this->load->view('include/header'); ?>
<?php $this->load->view('include/navbar'); ?>


 <div class="content-wrapper">
   <div class="container-fluid">

    <ol class="breadcrumb" style="margin-top: 10px;">
        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>">Halaman Utama</a>
        </li>
         <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>index/peralatandalamtower">Peralatan Dalam Tower</a>
        </li>
        <li class="breadcrumb-item active">UPS</li>
      </ol>

	<div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> Daftar Tabel Data UPS</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Nama Tabel Data</th>
                  <th>Opsi</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                	<td>1</td>
                	<td>UPS 1</td>
                	<td><a href="<?php echo config_item('base_url'); ?>ups_1"><i class="fa fa-eye"> Show</a></i></td>
                </tr>
                 <tr>
                	<td>2</td>
                	<td>UPS 2</td>
                	<td><a href="<?php echo config_item('base_url'); ?>ups_2"><i class="fa fa-eye"> Show</a></i></td>
                </tr>

            </tbody>
        </table>
    </div>
</div>
</div>
</div>
</div>

<?php $this->load->view('include/footer'); ?>