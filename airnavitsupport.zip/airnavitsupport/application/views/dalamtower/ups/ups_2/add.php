<?php $this->load->view('include/header'); ?>
<?php $this->load->view('include/navbar'); ?>

  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->

     <ol class="breadcrumb" style="margin-top: 10px;">
        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>">Halaman Utama</a>
        </li>
         <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>peralatandalamtower">Peralatan Dalam Tower</a>
        </li>

        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>UPS1">UPS 2</a>
        </li>
        <li class="breadcrumb-item active">Checklist Harian </li>
      </ol>
        <div class="pesan error" style="font-size: 16px; font-weight: bold;">
       <?php 
          echo $this->session->flashdata('pesanerror');
          echo $this->session->flashdata('pesanerror2');
          echo $this->session->flashdata('pesanerror3');
        ?> 
    </div>
    
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-plus"></i> Menginput Parameter Harian - UPS 2</div>
        <div class="card-body">
          <div class="table-responsive">
             <div class="container">

         <form action="<?php echo config_item('base_url'); ?>UPS2/action_add" method="post" enctype="multipart/form-data">

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="kode_alat">Kode Alat</label>
                <input class="form-control" id="kode_alat" type="text" aria-describedby="nameHelp" name="kode_alat" value="UPS2" required readonly />
              </div>
              
              <div class="col-md-6">
                <label for="username_pemeriksa">Username Pemeriksa</label>
                <input class="form-control" id="username_pemeriksa" type="text" aria-describedby="nameHelp" name="username_pemeriksa" value="<?= $this->session->userdata('username');?>"  required readonly />
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <label for="lokasi">Lokasi</label>
                <input class="form-control" id="lokasi" type="text" aria-describedby="nameHelp" name="lokasi" value="Tower" required />
              </div>
              
              <div class="col-md-4">
                <label for="tanggal">Tanggal</label>
                <input class="form-control" id="tanggal" type="date" aria-describedby="nameHelp" name="tanggal" value="<?= date('Y-m-d'); ?>" required />
              </div>

              <div class="col-md-4">
                <label for="dinas">Dinas</label>
                  <select class="form-control form-control-sm" id="dinas" name="dinas" required /> 
                        <option></option>
                        <option>Pagi</option>
                        <option>Malam</option>
                       </select>
              </div>
            </div>
          </div>

           <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <label for="vmainr">V Main R (Volt)</label>
                <input class="form-control" id="vmainr" type="number" step="any" aria-describedby="nameHelp" name="vmainr" required />
              </div>
               <div class="col-md-4">
                <label for="vmains">V Main S (Volt)</label>
                <input class="form-control" id="vmains" type="number" step="any" aria-describedby="nameHelp" name="vmains" required />
              </div>
               <div class="col-md-4">
                <label for="vmaint">V Main T (Volt)</label>
                <input class="form-control" id="vmaint" type="number" step="any" aria-describedby="nameHelp" name="vmaint" required />
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <label for="voutputr">V Output R (Volt)</label>
                <input class="form-control" id="voutputr" type="number" step="any" aria-describedby="nameHelp" name="voutputr" required />
              </div>
               <div class="col-md-4">
                <label for="voutputs">V Output S (Volt)</label>
                <input class="form-control" id="voutputs" type="number" step="any" aria-describedby="nameHelp" name="voutputs" required />
              </div>
               <div class="col-md-4">
                <label for="voutputt">V Output T (Volt)</label>
                <input class="form-control" id="voutputt" type="number" step="any" aria-describedby="nameHelp" name="voutputt" required />
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <label for="arusmainr">Arus Main R (Ampere)</label>
                <input class="form-control" id="arusmainr" type="number" step="any" aria-describedby="nameHelp" name="arusmainr" required />
              </div>
               <div class="col-md-4">
                <label for="arusmains">Arus Main S (Ampere)</label>
                <input class="form-control" id="arusmains" type="number" step="any" aria-describedby="nameHelp" name="arusmains" required />
              </div>
               <div class="col-md-4">
                <label for="arusmaint">Arus Main T (Ampere)</label>
                <input class="form-control" id="arusmaint" type="number" step="any" aria-describedby="nameHelp" name="arusmaint" required />
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <label for="arusoutputr">Arus Output R (Ampere)</label>
                <input class="form-control" id="arusoutputr" type="number" step="any" aria-describedby="nameHelp" name="arusoutputr" required />
              </div>
               <div class="col-md-4">
                <label for="arusoutputs">Arus Output S (Ampere)</label>
                <input class="form-control" id="arusoutputs" type="number" step="any" aria-describedby="nameHelp" name="arusoutputs" required />
              </div>
               <div class="col-md-4">
                <label for="arusoutputt">Arus Output T (Ampere)</label>
                <input class="form-control" id="arusoutputt" type="number" step="any" aria-describedby="nameHelp" name="arusoutputt" required />
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <label for="upsldkva">UPS LD (KVA)</label>
                <input class="form-control" id="upsldkva" type="number" step="any" aria-describedby="nameHelp" name="upsldkva" required />
              </div>
               <div class="col-md-4">
                <label for="upsldkw">UPS LD (KW)</label>
                <input class="form-control" id="upsldkw" type="number" step="any" aria-describedby="nameHelp" name="upsldkw" required />
              </div>
               <div class="col-md-4">
                <label for="upsldpf">UPS LD (PF)</label>
                <input class="form-control" id="upsldpf" type="number" step="any" aria-describedby="nameHelp" name="upsldpf" required />
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <label for="totalldkva">Total LD (KVA)</label>
                <input class="form-control" id="totalldkva" type="number" step="any" aria-describedby="nameHelp" name="totalldkva" required />
              </div>
               <div class="col-md-4">
                <label for="totalldkw">Total LD (KW)</label>
                <input class="form-control" id="totalldkw" type="number" step="any" aria-describedby="nameHelp" name="totalldkw" required />
              </div>
               <div class="col-md-4">
                <label for="totalldpf">Total LD (PF)</label>
                <input class="form-control" id="totalldpf" type="number" step="any" aria-describedby="nameHelp" name="totalldpf" required />
              </div>
            </div>
          </div>

           <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="dcvoltv">DC Volt (V)</label>
                <input class="form-control" id="dcvoltv" type="number" step="any" aria-describedby="nameHelp" name="dcvoltv" required />
              </div>
               <div class="col-md-6">
                <label for="dcvolta">DC Volt (A)</label>
                <input class="form-control" id="dcvolta" type="number" step="any" aria-describedby="nameHelp" name="dcvolta" required />
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-12">
                <label for="status">Status</label>
                  <select class="form-control form-control-sm" id="status" name="status" required /> 
                        <option></option>
                        <option>Charging</option>
                        <option>Tidak Charging</option>
                       </select>
              </div>
            </div>
          </div>

              <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="operasional">Operasional</label>
                <div class="col-sm-8 radio">
                  <label>
                    <input type="radio" name="operasional" id="operasional" value="Bypass" required />Bypass
                  </label>
                  <label style="margin-left: 30px;">
                    <input type="radio" name="operasional" id="operasional" value="Normal" required />Normal
                  </label>
                </div>
              </div>

              <div class="col-md-6">
                <label for="kebersihan">Kebersihan Panel</label>
                <div class="col-sm-8 radio">
                  <label>
                    <input type="radio" name="kebersihan_ups" id="kebersihan_ups" value="Baik" required />Baik
                  </label>
                  <label style="margin-left: 30px;">
                    <input type="radio" name="kebersihan_ups" id="kebersihan_ups" value="Tidak" required />Tidak
                  </label>
                </div>
            </div>
          </div>
        </div>

         <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="ukuran_tegangan_input_bb">Ukuran Tegangan Input Breaker Baterai</label>
                <input class="form-control" id="ukuran_tegangan_input_bb" type="number" step="any" aria-describedby="nameHelp" name="ukuran_tegangan_input_bb" required />
              </div>
               <div class="col-md-6">
                <label for="ukuran_tegangan_output_bb">Ukuran Tegangan Output Breaker Baterai</label>
                <input class="form-control" id="ukuran_tegangan_output_bb" type="number" step="any" aria-describedby="nameHelp" name="ukuran_tegangan_output_bb" required />
              </div>
            </div>
          </div>
           <div class="form-group">
              <div class="form-row">
                  <div class="col-md-12">
                    <label for="suhu_ruangan">Suhu Ruangan (Celcius)</label>
                    <input class="form-control" id="suhu_ruangan" type="number" step="any" aria-describedby="nameHelp" name="suhu_ruangan" required />
                  </div>
                </div>
              </div>

              <div class="form-group">
                <div class="form-row">
                  <div class="col-md-12">
                    <label for="foto">Foto</label>
                    <input class="form-control" id="foto" type="file" aria-describedby="nameHelp" name="foto" required />
                  </div>
                </div>
              </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-2">
                <input class="form-control btn btn-primary" type="submit" value="Simpan" name="btnSimpan" >
              </div>
            </div>
          </div>
          </form>
        </div>
</div>
</div>
</div>
</div>


<?php $this->load->view('include/footer'); ?>