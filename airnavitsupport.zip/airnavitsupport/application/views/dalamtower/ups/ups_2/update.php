<?php $this->load->view('include/header'); ?>
<?php $this->load->view('include/navbar'); ?>

  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->

    <ol class="breadcrumb" style="margin-top: 10px;">
        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>">Halaman Utama</a>
        </li>
         <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>peralatandalamtower">Peralatan Dalam Tower</a>
        </li>

        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>UPS2">UPS 2</a>
        </li>
        <li class="breadcrumb-item active">Update Data</li>
      </ol>
        <div class="pesan error" style="font-size: 16px; font-weight: bold;">
       <?php 
          echo $this->session->flashdata('pesanerror');
          echo $this->session->flashdata('pesanerror2');
          echo $this->session->flashdata('pesanerror3');
        ?> 
    </div>
    
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-plus"></i> Mengupdate Data UPS 2</div>
        <div class="card-body">
          <div class="table-responsive">
             <div class="container">

        <?php foreach ($content->result() as $data) {
          # code...
        } ?>
        <form action="<?php echo config_item('base_url'); ?>UPS2/action_update/<?= $data->id ?>" method="post" enctype="multipart/form-data">

          <input type="hidden" name="id" value="<?= $data->id ?>">
          <input type="hidden" name="fotolama" value="<?= $data->foto ?>">

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="kode_alat">Kode Alat</label>
                <input class="form-control" id="kode_alat" type="text" aria-describedby="nameHelp" name="kode_alat" value="<?= $data->kode_alat ?>" required readonly />
              </div>
              
              <div class="col-md-6">
                <label for="username_pemeriksa">Username Pemeriksa</label>
                <input class="form-control" id="username_pemeriksa" type="text" aria-describedby="nameHelp" name="username_pemeriksa" value="<?= $data->username_pemeriksa ?>"  required readonly />
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <label for="lokasi">Lokasi</label>
                <input class="form-control" id="lokasi" type="text" aria-describedby="nameHelp" name="lokasi" value="<?= $data->lokasi?>" required readonly />
              </div>
              
              <div class="col-md-4">
                <label for="tanggal">Tanggal</label>
                <input class="form-control" id="tanggal" type="date" aria-describedby="nameHelp" name="tanggal" value="<?= $data->tanggal ?>" required readonly/>
              </div>

              <div class="col-md-4">
                <label for="dinas">Dinas</label>
                  <select class="form-control form-control-sm" id="dinas" name="dinas" required readonly/> 
                        <option><?= $data->dinas ?></option>
                        <option>Pagi</option>
                        <option>Malam</option>
                       </select>
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <label for="vmainr">V Main R (Volt)</label>
                <input class="form-control" id="vmainr" type="number" step="any" aria-describedby="nameHelp" name="vmainr" value="<?= $data->v_main_r ?>" required />
              </div>
               <div class="col-md-4">
                <label for="vmains">V Main S (Volt)</label>
                <input class="form-control" id="vmains" type="number" step="any" aria-describedby="nameHelp" name="vmains" value="<?= $data->v_main_s ?>"required />
              </div>
               <div class="col-md-4">
                <label for="vmaint">V Main T (Volt)</label>
                <input class="form-control" id="vmaint" type="number" step="any" aria-describedby="nameHelp" name="vmaint" value="<?= $data->v_main_t ?>" required />
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <label for="voutputr">V Output R (Volt)</label>
                <input class="form-control" id="voutputr" type="number" step="any" aria-describedby="nameHelp" name="voutputr" value="<?= $data->v_output_r ?>" required />
              </div>
               <div class="col-md-4">
                <label for="voutputs">V Output S (Volt)</label>
                <input class="form-control" id="voutputs" type="number" step="any" aria-describedby="nameHelp" name="voutputs" value="<?= $data->v_output_s ?>" required />
              </div>
               <div class="col-md-4">
                <label for="voutputt">V Output T (Volt)</label>
                <input class="form-control" id="voutputt" type="number" step="any" aria-describedby="nameHelp" name="voutputt" value="<?= $data->v_output_t ?>" required />
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <label for="arusmainr">Arus Main R (Ampere)</label>
                <input class="form-control" id="arusmainr" type="number" step="any" aria-describedby="nameHelp" name="arusmainr" value="<?= $data->arus_main_r ?>" required />
              </div>
               <div class="col-md-4">
                <label for="arusmains">Arus Main S (Ampere)</label>
                <input class="form-control" id="arusmains" type="number" step="any" aria-describedby="nameHelp" name="arusmains" value="<?= $data->arus_main_s ?>" required />
              </div>
               <div class="col-md-4">
                <label for="arusmaint">Arus Main T (Ampere)</label>
                <input class="form-control" id="arusmaint" type="number" step="any" aria-describedby="nameHelp" name="arusmaint" value="<?= $data->arus_main_t ?>" required />
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <label for="arusoutputr">Arus Output R (Ampere)</label>
                <input class="form-control" id="arusoutputr" type="number" step="any" aria-describedby="nameHelp" name="arusoutputr" value="<?= $data->arus_output_r ?>" required />
              </div>
               <div class="col-md-4">
                <label for="arusoutputs">Arus Output S (Ampere)</label>
                <input class="form-control" id="arusoutputs" type="number" step="any" aria-describedby="nameHelp" name="arusoutputs" value="<?= $data->arus_output_s ?>" required />
              </div>
               <div class="col-md-4">
                <label for="arusoutputt">Arus Output T (Ampere)</label>
                <input class="form-control" id="arusoutputt" type="number" step="any" aria-describedby="nameHelp" name="arusoutputt" value="<?= $data->arus_output_t ?>" required />
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <label for="upsldkva">UPS LD (KVA)</label>
                <input class="form-control" id="upsldkva" type="number" step="any" aria-describedby="nameHelp" name="upsldkva" value="<?= $data->ups_ld_kva ?>" required />
              </div>
               <div class="col-md-4">
                <label for="upsldkw">UPS LD (KW)</label>
                <input class="form-control" id="upsldkw" type="number" step="any" aria-describedby="nameHelp" name="upsldkw" value="<?= $data->ups_ld_kw ?>" required />
              </div>
               <div class="col-md-4">
                <label for="upsldpf">UPS LD (PF)</label>
                <input class="form-control" id="upsldpf" type="number" step="any" aria-describedby="nameHelp" name="upsldpf" value="<?= $data->ups_ld_pf ?>" required />
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <label for="totalldkva">Total LD (KVA)</label>
                <input class="form-control" id="totalldkva" type="number" step="any" aria-describedby="nameHelp" name="totalldkva" value="<?= $data->total_ld_kva ?>" required />
              </div>
               <div class="col-md-4">
                <label for="totalldkw">Total LD (KW)</label>
                <input class="form-control" id="totalldkw" type="number" step="any" aria-describedby="nameHelp" name="totalldkw" value="<?= $data->total_ld_kw ?>" required />
              </div>
               <div class="col-md-4">
                <label for="totalldpf">Total LD (PF)</label>
                <input class="form-control" id="totalldpf" type="number" step="any" aria-describedby="nameHelp" name="totalldpf" value="<?= $data->total_ld_pf ?>" required />
              </div>
            </div>
          </div>

           <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="dcvoltv">DC Volt (V)</label>
                <input class="form-control" id="dcvoltv" type="number" step="any" aria-describedby="nameHelp" name="dcvoltv" value="<?= $data->dc_volt_v ?>" required />
              </div>
               <div class="col-md-6">
                <label for="dcvolta">DC Volt (A)</label>
                <input class="form-control" id="dcvolta" type="number" step="any" aria-describedby="nameHelp" name="dcvolta" value="<?= $data->dc_volt_a ?>" required />
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-12">
                <label for="status">Status</label>
                  <select class="form-control form-control-sm" id="status" name="status" required /> 
                        <option><?= $data->status ?></option>
                        <option>Charging</option>
                        <option>Tidak Charging</option>
                       </select>
              </div>
            </div>
          </div>

              <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="operasional">Operasional</label>
                <div class="col-sm-8 radio">

                <?php if ($data->operasional == "Bypass") { ?>
                  <label>
                    <input type="radio" name="operasional" id="operasional" value="Bypass" checked required />Bypass
                  </label>
                  <label style="margin-left: 30px;">
                    <input type="radio" name="operasional" id="operasional" value="Normal" required />Normal
                  </label>
                  <?php } elseif ($data->operasional == "Normal") { ?>
                    <label>
                    <input type="radio" name="operasional" id="operasional" value="Bypass" required />Bypass
                  </label>
                  <label style="margin-left: 30px;">
                    <input type="radio" name="operasional" id="operasional" value="Normal" checked required />Normal
                  </label>
                  <?php } ?>
                </div>
              </div>

              <div class="col-md-6">
                <label for="kebersihan">Kebersihan Panel</label>
                <div class="col-sm-8 radio">
                   <?php if ($data->kebersihan_ups == "Baik") { ?>
                  <label>
                    <input type="radio" name="kebersihan_ups" id="kebersihan_ups" value="Baik" checked required />Baik
                  </label>
                  <label style="margin-left: 30px;">
                    <input type="radio" name="kebersihan_ups" id="kebersihan_ups" value="Tidak" required />Tidak
                  </label>
                <?php } elseif ($data->kebersihan_ups == "Tidak") { ?>
                   <label>
                    <input type="radio" name="kebersihan_ups" id="kebersihan_ups" value="Baik" required />Baik
                  </label>
                  <label style="margin-left: 30px;">
                    <input type="radio" name="kebersihan_ups" id="kebersihan_ups" value="Tidak" checked required />Tidak
                  </label>
                <?php } ?>
                </div>
            </div>
          </div>
        </div>

         <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="ukuran_tegangan_input_bb">Ukuran Tegangan Input Breaker Baterai</label>
                <input class="form-control" id="ukuran_tegangan_input_bb" type="number" step="any" aria-describedby="nameHelp" name="ukuran_tegangan_input_bb" value="<?= $data->ukuran_tegangan_in_breaker_baterai?>" required />
              </div>
               <div class="col-md-6">
                <label for="ukuran_tegangan_output_bb">Ukuran Tegangan Output Breaker Baterai</label>
                <input class="form-control" id="ukuran_tegangan_output_bb" type="number" step="any" aria-describedby="nameHelp" name="ukuran_tegangan_output_bb" value="<?= $data->ukuran_tegangan_out_breaker_baterai ?>" required />
              </div>
            </div>
          </div>
           <div class="form-group">
              <div class="form-row">
                  <div class="col-md-12">
                    <label for="suhu_ruangan">Suhu Ruangan (Celcius)</label>
                    <input class="form-control" id="suhu_ruangan" type="number" step="any" aria-describedby="nameHelp" name="suhu_ruangan" value="<?= $data->suhu_ruangan?>" required />
                  </div>
                </div>
              </div>

              <div class="form-group">
                <div class="form-row">
                  <div class="col-md-12">
                    <label for="foto">Foto</label>
                    <input class="form-control" id="foto" type="file" aria-describedby="nameHelp" name="foto" />
                  </div>
                </div>
              </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-2">
                <input class="form-control btn btn-primary" type="submit" value="Update" name="btnUpdate" >
              </div>
            </div>
          </div>
          </form>
        </div>
</div>
</div>
</div>
</div>


<?php $this->load->view('include/footer'); ?>