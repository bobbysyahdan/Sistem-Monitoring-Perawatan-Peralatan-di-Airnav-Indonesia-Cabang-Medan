<?php $this->load->view('include/header'); ?>
<?php $this->load->view('include/navbar'); ?>

 <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->

     <?php if ($this->session->userdata('level') == "User") { ?>

      <ol class="breadcrumb" style="margin-top: 10px;">
        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>">Halaman Utama</a>
        </li>
        
      <?php } ?>

      <?php if ($this->session->userdata('level') == "Jr Manager") { ?>
         <ol class="breadcrumb" style="margin-top: 10px;">
        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>jrmanager">Halaman Utama</a>
        </li>
       
      <?php } ?>
        <li class="breadcrumb-item active">Look Book Kegiatan</li>
      </ol>
      <?php if ($this->session->userdata('level') == "User") { ?>

          <a href="<?php echo config_item('base_url'); ?>logbookkegiatan/add" class="btn btn-primary" style="margin-bottom: 10px;"><i class="fa fa-plus"> Menambah Data</a></i>
<?php } ?>
      <div class="pesan error" style="color: green; font-size: 18px; font-weight: bold;">
       <?php 
          echo $this->session->flashdata('pesanerror');
          echo $this->session->flashdata('pesanerror2');
          echo $this->session->flashdata('pesanerror3');
          echo $this->session->flashdata('pesanberhasil');
          echo $this->session->flashdata('pesanberhasil2');
        ?> 
    </div>

      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> Data Tabel Log Book Kegiatan</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr class="text-center">
                  <th>No</th>
                  <th>Tanggal</th>
                  <th>Kegiatan</th>
                  <th>Keterangan</th>
                  <?php if ($this->session->userdata('level') == "User") { ?>
                  <th>Opsi</th>
                <?php } ?>
                </tr>
              </thead>
            <tbody  class="text-center">
                <tr>
                <?php 
                  $i = 1;
                  foreach ($content->result() as $data) : ?>
                  <td><?= $i ?></td>
                  <td><?= $data->tanggal?></td>
                  <td><?= $data->kegiatan?></td>
                  <td><?= $data->keterangan ?></td>
                 
                  <?php if ($this->session->userdata('level') == "User") { ?>
                    <td> 
                    <a href="<?php echo config_item('base_url'); ?>logbookkegiatan/update/<?= $data->id?>" class="btn btn-warning" style="margin-bottom: 1px;"><i class="fa fa-tag"></i></a>
                    <a href="<?php echo config_item('base_url'); ?>logbookkegiatan/delete/<?= $data->id ?>" onclick="return confirm('Apakah anda yakin?');" class="btn btn-danger"><i class="fa fa-trash"></i></a>
                  </td> 
                <?php } ?>
                </tr>
                    <?php
                      $i++;
                    endforeach;
                  ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

<?php $this->load->view('include/footer'); ?>