a<?php $this->load->view('include/header'); ?>
<?php $this->load->view('include/navbar'); ?>

  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->

      <ol class="breadcrumb" style="margin-top: 10px;">
        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>">Halaman Utama</a>
        </li>
         <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>logbookkegiatan">Log Book Kegiatanr</a>
        </li>
        
        <li class="breadcrumb-item active">Menambah Data</li>
      </ol>

    <div class="pesan error" style="font-size: 16px; font-weight: bold;">
       <?php 
          echo $this->session->flashdata('pesanerror');
          echo $this->session->flashdata('pesanerror2');
          echo $this->session->flashdata('pesanerror3');
          echo $this->session->flashdata('pesanerror4');
        ?> 
    </div>

       <?php foreach ($content->result() as $data) {
          # code...
        } ?>
    
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-plus"></i> Menambah Data Log Book Kegiatan</div>
        <div class="card-body">
          <div class="table-responsive">
             <div class="container">

        <form action="<?php echo config_item('base_url'); ?>logbookkegiatan/action_update/<?= $data->id?>" method="post" enctype="multipart/form-data">

          <input type="hidden" name="id" value="<?= $data->id?>">

          <div class="form-group">
                <div class="form-row">
                  <div class="col-md-12">
                    <label for="tanggal">Tanggal</label>
                    <input class="form-control" id="tanggal" type="date" aria-describedby="nameHelp" name="tanggal" value="<?= $data->tanggal ?>" required />
                  </div>
                </div>
              </div>

               <div class="form-group">
                <div class="form-row">
                  <div class="col-md-12">
                    <label for="kegiatan">Kegiatan</label>
                    <small class="form-text text-muted">Format input kegiatan : nomor + jam + (kegiatan) + (enter/baris baru)</small>
                    <textarea cols="50" rows="20" class="form-control" id="kegiatan" type=text aria-describedby="nameHelp" name="kegiatan"  required><?= $data->kegiatan?></textarea>
                  </div>
                </div>
              </div>
              
               <div class="form-group">
                <div class="form-row">
                  <div class="col-md-12">
                    <label for="keterangan">Keterangan</label>
                    <small class="form-text text-muted">Format input keterangan : nomor + (keterangan) + (enter/baris baru)</small>
                    <textarea cols="50" rows="20" class="form-control" id="keterangan" type=text aria-describedby="nameHelp" name="keterangan" required><?= $data->keterangan?></textarea>
                  </div>
                </div>
              </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-2">
                <input class="form-control btn btn-primary" type="submit" value="Update" name="btnUpdate" >
              </div>
            </div>
          </div>
          </form>
        </div>
</div>
</div>
</div>
</div>


<?php $this->load->view('include/footer'); ?>