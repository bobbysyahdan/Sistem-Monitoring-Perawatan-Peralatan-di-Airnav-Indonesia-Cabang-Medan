<?php $this->load->view('include/header'); ?>
<?php $this->load->view('include/navbar'); ?>

 <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->

      <ol class="breadcrumb" style="margin-top: 10px;">
        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>">Halaman Utama</a>
        </li>

        <li class="breadcrumb-item active">Detail Pengecekan</li>
      </ol>
        <div class="pesan error" style="color: green; font-size: 18px; font-weight: bold;">
       <?php 
          echo $this->session->flashdata('pesanberhasil');
           echo $this->session->flashdata('pesanberhasilhapus');
            echo $this->session->flashdata('pesanerror4');

          ?> 
    </div>
   <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-plus"></i> Detail Pengecekan Peralatan Harian</div>
        <div class="card-body">
          <div class="table-responsive">
             <div class="container">

        <form action="<?php echo config_item('base_url'); ?>detailpengecekan/action_add" method="post">


                <input type="hidden" name="dinas" value="<?= $this->input->post('dinas')?>">
                <input type="hidden" name="tanggal" value="<?= $this->input->post('tanggal')?>">
                <input type="hidden" name="lokasi" value="<?= $this->input->post('lokasi')?>">
                <input type="hidden" name="username_pemeriksa" value="<?= $this->input->post('username_pemeriksa')?>">


                <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <?php 
                $dinas = $this->input->post('dinas');
                $tanggal = $this->input->post('tanggal');
                $kode_alatpaneldistp = 'PANELDISTP';
                $paneldistp = $this->db->query("SELECT catatan FROM tbl_paneldis WHERE kode_alat = '$kode_alatpaneldistp' AND tanggal = '$tanggal' AND dinas = '$dinas'");
                
                if ($paneldistp->num_rows() > 0) { 
                foreach ($paneldistp->result() as $paneldistpdata) :?>
                <label for="panelditp">PANELDISTP </label>                
                <input class="form-control" id="paneldistp" type="text" aria-describedby="nameHelp" name="paneldistp" value="<?= $paneldistpdata->catatan?>" required readonly />
              </div>
      
            <?php endforeach; }else { ?>
              <label for="panelditp">PANELDISTP </label>
               
                <input class="form-control" id="paneldistp" type="text" aria-describedby="nameHelp" name="paneldistp" value="Peralatan belum dicek" required readonly />
              </div>
            <?php } ?>

              <div class="col-md-4">
                <?php 

                $kode_alatpaneldisp1 = 'PANELDISP1';
                $paneldisp1 = $this->db->query("SELECT catatan FROM tbl_paneldis WHERE kode_alat = '$kode_alatpaneldisp1' AND tanggal = '$tanggal' AND dinas = '$dinas'");
                
                if ($paneldisp1->num_rows() > 0) { 
                foreach ($paneldisp1->result() as $paneldisp1data) :?>
                <label for="panelditp">PANELDISP1 </label>                
                <input class="form-control" id="paneldistp" type="text" aria-describedby="nameHelp" name="paneldisp1" value="<?= $paneldisp1data->catatan?>" required readonly />
              </div>
      
            <?php endforeach; }else { ?>
              <label for="paneldisp1">PANELDISP1 </label>
               
                <input class="form-control" id="paneldisp1" type="text" aria-describedby="nameHelp" name="paneldisp1" value="Peralatan belum dicek" required readonly/>
              </div>
            <?php } ?>

              <div class="col-md-4">
                <?php 

                $kode_alatpaneldisp2 = 'PANELDISP2';
                $paneldisp2 = $this->db->query("SELECT catatan FROM tbl_paneldis WHERE kode_alat = '$kode_alatpaneldisp2' AND tanggal = '$tanggal' AND dinas = '$dinas'");
                
                if ($paneldisp1->num_rows() > 0) { 
                foreach ($paneldisp2->result() as $paneldisp2data) :?>
                <label for="paneldi2p">PANELDISP2 </label>                
                <input class="form-control" id="paneldisp2" type="text" aria-describedby="nameHelp" name="paneldisp2" value="<?= $paneldisp2data->catatan?>" required readonly />
              </div>
      
            <?php endforeach; }else { ?>
              <label for="paneldisp2">PANELDISP2 </label>
               
                <input class="form-control" id="paneldisp1" type="text" aria-describedby="nameHelp" name="paneldisp2" value="Peralatan belum dicek" required readonly/>
              </div>
            <?php } ?>
            </div>
          </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <?php 

                $kode_alatups1 = 'UPS1';
                $ups1 = $this->db->query("SELECT catatan FROM tbl_ups WHERE kode_alat = '$kode_alatups1' AND tanggal = '$tanggal' AND dinas = '$dinas'");
                
                if ($ups1->num_rows() > 0) { 
                foreach ($ups1->result() as $ups1data) :?>
                <label for="ups1">UPS1 </label>                
                <input class="form-control" id="ups1" type="text" aria-describedby="nameHelp" name="ups1" value="<?= $ups1data->catatan?>" required readonly/>
              </div>
      
            <?php endforeach; }else { ?>
              <label for="ups1">UPS 1 </label>
                <input class="form-control" id="ups1" type="text" aria-describedby="nameHelp" name="ups1" value="Peralatan belum dicek" required readonly/>
              </div>
            <?php } ?>

             <div class="col-md-6">
                <?php 

                $kode_alatups2 = 'UPS2';
                $ups2 = $this->db->query("SELECT catatan FROM tbl_ups WHERE kode_alat = '$kode_alatups2' AND tanggal = '$tanggal' AND dinas = '$dinas'");
                
                if ($ups2->num_rows() > 0) { 
                foreach ($ups2->result() as $ups2data) :?>
                <label for="ups2">UPS1 </label>                
                <input class="form-control" id="ups2" type="text" aria-describedby="nameHelp" name="ups2" value="<?= $ups2data->catatan?>" required readonly/>
              </div>
      
            <?php endforeach; }else { ?>
              <label for="ups2">UPS 2 </label>
                <input class="form-control" id="ups2" type="text" aria-describedby="nameHelp" name="ups2" value="Peralatan belum dicek" required readonly/>
              </div>
            <?php } ?>
            </div>
          </div>

          <div class="form-group">
            <div class="form-row">

               <div class="col-md-4">
                <?php 

                $kode_alatbangunanac = 'BANGUNANAC';
                $bangunanac = $this->db->query("SELECT catatan FROM tbl_bangunan_dan_ac WHERE kode_alat = '$kode_alatbangunanac' AND tanggal = '$tanggal' AND dinas = '$dinas'");
                
                if ($bangunanac->num_rows() > 0) { 
                foreach ($bangunanac->result() as $bangunanacdata) :?>
                <label for="bangunac">BANGUNANAC </label>                
                <input class="form-control" id="bangunac" type="text" aria-describedby="nameHelp" name="bangunac" value="<?= $bangunanacdata->catatan?>" required readonly />
              </div>
      
            <?php endforeach; }else { ?>
              <label for="bangunac">BANGUNANAC </label>
                <input class="form-control" id="bangunac" type="text" aria-describedby="nameHelp" name="bangunac" value="Peralatan belum dicek" required readonly/>
              </div>
            <?php } ?>

               <div class="col-md-4">
                <?php 

                $kode_alatehfan01 = 'EHFAN01';
                $ehfan01 = $this->db->query("SELECT catatan FROM tbl_exhaust_fan WHERE kode_alat = '$kode_alatehfan01' AND tanggal = '$tanggal' AND dinas = '$dinas'");
                
                if ($ehfan01->num_rows() > 0) { 
                foreach ($ehfan01->result() as $ehfan01data) :?>
                <label for="ehfan01">EHFAN01 </label>
                <input class="form-control" id="ehfan01" type="text" aria-describedby="nameHelp" name="ehfan01" value="<?= $ehfan01data->catatan?>" required readonly/>
              </div>
      
            <?php endforeach; }else { ?>
              <label for="ehfan01">EHFAN01 </label>
                <input class="form-control" id="ehfan01" type="text" aria-describedby="nameHelp" name="ehfan01" value="Peralatan belum dicek" required readonly/>
              </div>
            <?php } ?>


             <div class="col-md-4">
                <?php 

                $kode_alatcctv01 = 'CCTV01';
                $cctv01 = $this->db->query("SELECT catatan FROM tbl_cctv WHERE kode_alat = '$kode_alatcctv01' AND tanggal = '$tanggal' AND dinas = '$dinas'");
                
                if ($cctv01->num_rows() > 0) { 
                foreach ($cctv01->result() as $cctv01data) :?>
                <label for="cctv01">CCTV01 </label>
                <input class="form-control" id="cctv01" type="text" aria-describedby="nameHelp" name="cctv01" value="<?= $cctv01data->catatan?>" required readonly/>
              </div>
      
            <?php endforeach; }else { ?>
              <label for="cctv01">CCTV01 </label>
                <input class="form-control" id="cctv01" type="text" aria-describedby="nameHelp" name="cctv01" value="Peralatan belum dicek" required readonly/>
              </div>
            <?php } ?>

            </div>
          </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-12">
                <label for="catatan">Catatan </label>
                <textarea name="catatan" class="form-control" id="catatan" rows="5" type="text-area" cols="50" aria-describedby="nameHelp" required></textarea>
              </div>
            </div>
          </div> 

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <input class="form-control btn btn-primary" type="submit" value="Cek Detail Pengecekan Peralatan Hari ini" name="btnSimpan" >
              </div>
            </div>
          </div>

              </form>
            </div>
          </div>
        </div>
      </div>
        </div>
      </div>
    </div>
  </div>


<?php $this->load->view('include/footer'); ?>