<?php $this->load->view('include/header'); ?>
<?php $this->load->view('include/navbar'); ?>

 <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->

        <?php if ($this->session->userdata('level') == "User") { ?>

      <ol class="breadcrumb" style="margin-top: 10px;">
        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>">Halaman Utama</a>
        </li>
        
      <?php } ?>

      <?php if ($this->session->userdata('level') == "Jr Manager") { ?>
         <ol class="breadcrumb" style="margin-top: 10px;">
        <li class="breadcrumb-item">
          <a href="<?php echo config_item('base_url'); ?>jrmanager">Halaman Utama</a>
        </li>
       
      <?php } ?>

        <li class="breadcrumb-item active">Detail Pengecekan</li>
      </ol>
        <div class="pesan error" style="color: green; font-size: 18px; font-weight: bold;">
       <?php 
          echo $this->session->flashdata('pesanberhasil');
           echo $this->session->flashdata('pesanberhasilhapus');
            echo $this->session->flashdata('pesanerror3');
             echo $this->session->flashdata('pesanerror4');

          ?> 
    </div>

    <?php if ($this->session->userdata('level') == "User") { ?>
   <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-plus"></i> Detail Pengecekan Peralatan Harian</div>
        <div class="card-body">
          <div class="table-responsive">
             <div class="container">

        <form action="<?php echo config_item('base_url'); ?>detailpengecekan/add" method="post">

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="username_pemeriksa">Username Pemeriksa</label>
                <input class="form-control" id="username_pemeriksa" type="text" aria-describedby="nameHelp" name="username_pemeriksa" value="<?= $this->session->userdata('username');?>"  required readonly />
              </div>

              <div class="col-md-6">
                <label for="lokasi">Lokasi</label>
                <input class="form-control" id="lokasi" type="text" aria-describedby="nameHelp" name="lokasi" value="Tower" required />
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="form-row">
              
              <div class="col-md-6">
                <label for="tanggal">Tanggal</label>
                <input class="form-control" id="tanggal" type="date" aria-describedby="nameHelp" name="tanggal" value="<?= date('Y-m-d'); ?>" required />
              </div>

              <div class="col-md-6">
                <label for="dinas">Dinas</label>
                  <select class="form-control form-control-sm" id="dinas" name="dinas" required /> 
                        <option></option>
                        <option>Pagi</option>
                        <option>Malam</option>
                       </select>
                </div>
              </div>
            </div>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <input class="form-control btn btn-primary" type="submit" value="Cek Detail Pengecekan Peralatan Hari ini" name="btnSimpan" >
              </div>
            </div>
          </div>

              </form>
            </div>
          </div>
        </div>
      </div>

    <?php } ?>

      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> Data Tabel Detail Pengecekan</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr class="text-center">
                  <th colspan="5"></th>
                  <th colspan="6">Kondisi Peralatan</th>
                  <th colspan="2"></th>
                </tr>
                <tr>
                   <th>No</th>
                  <th>Username Pemeriksa</th>
                  <th>Lokasi</th>
                  <th>Tanggal</th>
                  <th>Dinas</th>
                  <th>PANELDISTP</th>
                  <th>PANELDISP1</th>
                  <th>PANELDISP2</th>
                  <th>UPS1</th>
                  <th>UPS2</th>
                  <th>BANGUNAC</th>
                  <th>EHFAN01</th>
                  <th>CCTV01</th>
                  <th>Catatan</th>
                  
                 <?php if ($this->session->userdata('level') == "User" || $this->session->userdata('level') == "Jr Manager"  ) { ?>
                  <th>Status</th>
                <?php } ?>
                 <?php if ($this->session->userdata('level') == "User") { ?>
                  <th>Opsi</th>
                <?php } ?>
                </tr>
              </thead>
              <tbody>
                <tr>
                <?php 
                  $i = 1;
                  foreach ($content->result() as $data) :
                  ?>
                  <td><?= $i ?></td>
                  <td><?= $data->username_pemeriksa ?></td>
                  <td><?= $data->lokasi ?></td>
                  <td><?= $data->tanggal ?></td>
                  <td><?= $data->dinas ?></td>
                  <td><?= $data->paneldistp ?></td>
                  <td><?= $data->paneldisp1 ?></td>
                  <td><?= $data->paneldisp2 ?></td>
                  <td><?= $data->ups1 ?></td>
                  <td><?= $data->ups2 ?></td>
                  <td><?= $data->bangunac ?></td>
                  <td><?= $data->ehfan01 ?></td>
                  <td><?= $data->cctv01 ?></td>
                  <td><?= $data->catatan ?></td>
                   
                 <?php if ($this->session->userdata('level') == "Jr Manager" || $this->session->userdata('level') == "User" ) { 
                  if ($data->paneldistp == "Nilai Parameter Normal" &&
                   $data->paneldisp1 == "Nilai Parameter Normal" &&
                    $data->paneldisp2 == "Nilai Parameter Normal" &&
                    $data->ups1 == "Nilai Parameter Normal" &&
                    $data->ups2 == "Nilai Parameter Normal" &&
                      $data->bangunac == "Kondisi Normal" &&
                        $data->ehfan01 == "Kondisi Hidup dengan Normal" &&
                          $data->cctv01 == "Kondisi Normal"
                     ) {?>

                    <td style="font-size: 20px;"><div class="alert alert-success alert-dismissible fade show" 
                          role="alert">Kondisi Normal</div>
                  </td> 

                 <?php } else {?> 
                
                   <td style="font-size: 20px;"><div class="alert alert-danger alert-dismissible fade show" 
                          role="alert">Perlu Perbaikan</div>
                  </td> 
                <?php }} ?>

                 <?php if ($this->session->userdata('level') == "User") { ?>
                   <td>
                    <a href="<?php echo config_item('base_url'); ?>detailpengecekan/delete/<?= $data->id_detail_pengecekan ?>" onclick="return confirm('Apakah anda yakin?');" class="btn btn-danger"><i class="fa fa-trash"></i></a>
                  </td> 
                <?php } ?>
           
                </tr>
                    <?php
                      $i++;
                    endforeach;
                  ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>


<?php $this->load->view('include/footer'); ?>