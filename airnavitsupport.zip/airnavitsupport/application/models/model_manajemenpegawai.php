<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_manajemenpegawai extends CI_Model {
	public function __construct()
	{
		parent::__construct();
		//Do your magic here
	}

	public function menambahdatapegawai($data)
	{
		$this->db->insert('tbl_pegawai', $data);
	}
	
	public function updatedatapegawai($data, $id)
	{
		$this->db->where('id', $id);
		$this->db->update('tbl_pegawai', $data);
	}

	public function deletedatapegawai($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('tbl_pegawai');
	}
}

/* End of file model_manajemenpegawai.php */
/* Location: ./application/models/model_manajemenpegawai.php */