<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_login extends CI_Model {

	public function action_login($username, $password)
		{
			$this->db->select('username,password,level');
			$this->db->from('tbl_user');
			$this->db->where('username', $username);
			$this->db->where('password', $password);
			$this->db->limit(1);

			$query = $this->db->get();
			if ($query->num_rows()==1) {
				// redirect('','refresh');
				return $query->result();
				// $this->load->view('home/home');

			} else{
				// echo "<script>alert('Username atau password anda salah!')</script>";
				// redirect('login','refresh');
				return false;
				
			}
		}

	// public function cek_login($username, $password)
	// {
	// 	$query = $this->db->get_where('tbl_user', array('username'=>$username,'password'=>$password));
	// 	$query = $query->result_array();
	// 	return $query;
	// }
}

/* End of file model_login.php */
/* Location: ./application/models/model_login.php */