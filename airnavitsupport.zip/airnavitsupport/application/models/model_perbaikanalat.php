<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_perbaikanalat extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
	}

	public function action_add($data)
	{
		$this->db->insert('tbl_perbaikan_alat', $data);
	}

	public function action_update($data, $id)
	{
		$this->db->where('id_perbaikan_alat', $id);
		$this->db->update('tbl_perbaikan_alat', $data);
	}

	public function action_delete($id)
	{
		$this->db->where('id_perbaikan_alat', $id);
		$this->db->delete('tbl_perbaikan_alat');
	}
}

/* End of file model_perbaikanalat.php */
/* Location: ./application/models/model_perbaikanalat.php */