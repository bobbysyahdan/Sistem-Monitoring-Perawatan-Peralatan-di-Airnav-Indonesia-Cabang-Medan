<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_logbookkegiatan extends CI_Model {
public function __construct()
	{
		parent::__construct();
		//Do your magic here
	}

	public function action_add($data)
	{
		$this->db->insert('tbl_logbookkegiatan', $data);
	}
	
	public function action_update($data, $id)
	{
		$this->db->where('id', $id);
		$this->db->update('tbl_logbookkegiatan', $data);
	}

	public function action_delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('tbl_logbookkegiatan');
	}
	

}

/* End of file model_logbookkegiatan.php */
/* Location: ./application/models/model_logbookkegiatan.php */