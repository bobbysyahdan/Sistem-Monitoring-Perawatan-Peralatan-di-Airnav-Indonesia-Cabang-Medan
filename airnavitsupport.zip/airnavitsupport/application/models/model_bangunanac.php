<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_bangunanac extends CI_Model {
	public function __construct()
	{
		parent::__construct();
		//Do your magic here
	}

	public function action_add1($data)
	{
		$this->db->insert('tbl_bangunan_dan_ac', $data);
	}
	public function action_add2($data)
	{
		$this->db->insert('tbl_bangunan_dan_ac', $data);
	}
	public function action_add3($data)
	{
		$this->db->insert('tbl_bangunan_dan_ac', $data);
	}
	
	public function action_update1($data, $id)
	{
		$this->db->where('id', $id);
		$this->db->update('tbl_bangunan_dan_ac', $data);
	}
	public function action_update2($data, $id)
	{
		$this->db->where('id', $id);
		$this->db->update('tbl_bangunan_dan_ac', $data);
	}
	public function action_update3($data, $id)
	{
		$this->db->where('id', $id);
		$this->db->update('tbl_bangunan_dan_ac', $data);
	}

	public function action_delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('tbl_bangunan_dan_ac');
	}
}

/* End of file model_manajemenpegawai.php */
/* Location: ./application/models/model_manajemenpegawai.php */