<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_paneldis extends CI_Model {

public function action_add1($data)
	{
		$this->db->insert('tbl_paneldis', $data);
	}
	public function action_add2($data2)
	{
		$this->db->insert('tbl_paneldis', $data2);
	}
	public function action_add3($data3)
	{
		$this->db->insert('tbl_paneldis', $data3);
	}

	public function action_update1($data1, $id)
	{
		$this->db->where('id', $id);
		$this->db->update('tbl_paneldis', $data1);
	}
	public function action_update2($data2, $id)
	{
		$this->db->where('id', $id);
		$this->db->update('tbl_paneldis', $data2);
	}
	public function action_update3($data3, $id)
	{
		$this->db->where('id', $id);
		$this->db->update('tbl_paneldis', $data3);
	}

	public function action_delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('tbl_paneldis');
	}
	

}

/* End of file model_paneldis_teknikalpriority.php */
/* Location: ./application/models/model_paneldis_teknikalpriority.php */