<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_profil extends CI_Model {

public function __construct()
	{
		parent::__construct();
		//Do your magic here
	}	

	public function updateprofil($data, $nip)
	{
		$this->db->where('nik', $nip);
		$this->db->update('tbl_pegawai', $data);
	}

	public function ubahpassword($data, $username)
	{
		$this->db->where('username', $username);
		$this->db->update('tbl_user', $data);
	}

}

/* End of file model_profil.php */
/* Location: ./application/models/model_profil.php */