<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_detailpengecekan extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
	}

	public function action_add($data)
	{
		$this->db->insert('tbl_detail_pengecekan', $data);
	}
	
	public function action_delete($id)
	{
		$this->db->where('id_detail_pengecekan', $id);
		$this->db->delete('tbl_detail_pengecekan');
	}
}

/* End of file model_detailpengecekan.php */
/* Location: ./application/models/model_detailpengecekan.php */