<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_manajemenuser extends CI_Model {
	public function __construct()
	{
		parent::__construct();
		//Do your magic here
	}

	public function menambahdatauser($data)
	{
		$this->db->insert('tbl_user', $data);
	}
	
	public function updatedatauser($data, $id_user)
	{
		$this->db->where('id_user', $id_user);
		$this->db->update('tbl_user', $data);
	}

	public function deletedatauser($id_user)
	{
		$this->db->where('id_user', $id_user);
		$this->db->delete('tbl_user');
	}
	

}

/* End of file model_manajemenuser.php */
/* Location: ./application/models/model_manajemenuser.php */