<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_manajemenperalatandalamtower extends CI_Model {
	public function __construct()
	{
		parent::__construct();
		//Do your magic here
	}
	public function menambahdataperalatandalamtower($data)
	{
		$this->db->insert('tbl_peralatan_dalam_tower', $data);
	}
	
	public function updatedataperalatandalamtower($data, $id)
	{
		$this->db->where('id', $id);
		$this->db->update('tbl_peralatan_dalam_tower', $data);
	}

	public function deletedataperalatandalamtower($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('tbl_peralatan_dalam_tower');
	}

}

/* End of file model_manajemenperalatandalamtower.php */
/* Location: ./application/models/model_manajemenperalatandalamtower.php */