<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_ehfan extends CI_Model {
	public function __construct()
	{
		parent::__construct();
		//Do your magic here
	}

	public function action_add1($data)
	{
		$this->db->insert('tbl_exhaust_fan', $data);
	}
	public function action_add2($data)
	{
		$this->db->insert('tbl_exhaust_fan', $data);
	}

	public function action_update1($data, $id)
	{
		$this->db->where('id', $id);
		$this->db->update('tbl_exhaust_fan', $data);
	}
	public function action_update2($data, $id)
	{
		$this->db->where('id', $id);
		$this->db->update('tbl_exhaust_fan', $data);
	}

	public function action_delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('tbl_exhaust_fan');
	}
}

/* End of file model_manajemenpegawai.php */
/* Location: ./application/models/model_manajemenpegawai.php */