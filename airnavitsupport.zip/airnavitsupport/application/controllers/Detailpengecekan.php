<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Detailpengecekan extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->load->library('upload');
		$this->load->model('model_detailpengecekan');
		$this->load->helper(array('form', 'url'));
	}

	public function index()
	{
		if($this->session->userdata('level') == "User"){
			
			$data['content'] = $this->db->get('tbl_detail_pengecekan');
			$this->load->view('detailpengecekan/detailpengecekan', $data);
		} elseif($this->session->userdata('level') == "Admin"){
			redirect('admin','refresh');
		} else{
			redirect('login','refresh');
		}
	}

	public function add()
	{
		if($this->session->userdata('level') == "User"){
			$this->load->view('detailpengecekan/add');
		} elseif($this->session->userdata('level') == "Admin"){
			redirect('admin','refresh');
		} else{
			redirect('login','refresh');
		}	
	}

	
	public function action_add()
	{
		$paneldistp = $this->input->post("paneldistp");
		$paneldisp1 = $this->input->post("paneldisp1");
		$paneldisp2 = $this->input->post("paneldisp2");
		$ups1 = $this->input->post("ups1");
		$ups2 = $this->input->post("ups2");
		$bangunac = $this->input->post("bangunac");
		$ehfan01 = $this->input->post("ehfan01");
		$cctv01 = $this->input->post("cctv01");
		$tanggal = $this->input->post('tanggal');
		$dinas = $this->input->post('dinas');
		$query = $this->db->query("SELECT * from tbl_detail_pengecekan where tanggal = '$tanggal' AND dinas = '$dinas'");
		
		if ($query->num_rows() > 0){
			$this->session->set_flashdata('pesanerror3', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal ditambah. Tanggal dan dinas hari ini sudah diinput!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	redirect('detailpengecekan');
		}

		if ($paneldistp == "Peralatan belum dicek") {
			$this->session->set_flashdata('pesanerror4', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal ditambah. PANELDISTP belum dicek!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	redirect('detailpengecekan/add','refresh');
		} elseif ($paneldisp1 == "Peralatan belum dicek") {
			$this->session->set_flashdata('pesanerror4', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal ditambah. PANELDISP1 belum dicek!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	redirect('detailpengecekan/add','refresh');
		}elseif ($paneldisp2 == "Peralatan belum dicek") {
			$this->session->set_flashdata('pesanerror4', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal ditambah. PANELDISP2 belum dicek!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	redirect('detailpengecekan/add','refresh');
		}elseif ($ups1 == "Peralatan belum dicek") {
			$this->session->set_flashdata('pesanerror4', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal ditambah. UPS1 belum dicek!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	redirect('detailpengecekan/add','refresh');
		}elseif ($ups2 == "Peralatan belum dicek") {
			$this->session->set_flashdata('pesanerror4', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal ditambah. UPS2 belum dicek!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	redirect('detailpengecekan/add','refresh');
		}elseif ($bangunac == "Peralatan belum dicek") {
			$this->session->set_flashdata('pesanerror4', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal ditambah. BANGUNAC belum dicek!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	redirect('detailpengecekan/add','refresh');
		}elseif ($ehfan01 == "Peralatan belum dicek") {
			$this->session->set_flashdata('pesanerror4', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal ditambah. EHFAN01 belum dicek!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	redirect('detailpengecekan/add','refresh');
		}
		elseif ($cctv01 == "Peralatan belum dicek") {
			$this->session->set_flashdata('pesanerror4', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal ditambah. CCTV01 belum dicek!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	redirect('detailpengecekan/add','refresh');
		}

		$data =array(
			
			"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
			"tanggal" => $this->input->post("tanggal"),
			"dinas" => $this->input->post("dinas"),
			"lokasi" => $this->input->post("lokasi"),
			"paneldistp" => $this->input->post("paneldistp"),
			"paneldisp1" => $this->input->post("paneldisp1"),
			"paneldisp2" => $this->input->post("paneldisp2"),
			"ups1" => $this->input->post("ups1"),
			"ups2" => $this->input->post("ups2"),
			"bangunac" => $this->input->post("bangunac"),
			"ehfan01" => $this->input->post("ehfan01"),
			"cctv01" => $this->input->post("cctv01"),
			"catatan" => $this->input->post("catatan")
		);

		$this->model_detailpengecekan->action_add($data);
		$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
											  Data Berhasil disimpan!
											  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
											    <span aria-hidden="true">&times;</span>
											  </button>
											</div>');
		redirect('detailpengecekan','refresh');
	}

	public function delete($id = NULL)
	{
		if($this->session->userdata('level') == "User"){
			$this->model_detailpengecekan->action_delete($id);
			$this->session->set_flashdata('pesanberhasilhapus', '<div class="alert alert-success alert-dismissible fade show" role="alert">
											  Data Berhasil dihapus!
											  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
											    <span aria-hidden="true">&times;</span>
											  </button>
											</div>');
			redirect('detailpengecekan','refresh');
		} elseif($this->session->userdata('level') == "Admin"){
			redirect('admin','refresh');
		} else{
			redirect('login','refresh');
		}
	}


}

/* End of file Detailpengecekan.php */
/* Location: ./application/controllers/Detailpengecekan.php */