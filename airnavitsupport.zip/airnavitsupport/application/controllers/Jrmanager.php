<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jrmanager extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->load->model('model_profil');
	}
	public function index()
	{
		if ($this->session->userdata('level') == "Jr Manager") {
			$this->load->view('home/home');
		}elseif ($this->session->userdata('level') == "Admin") {
			$this->load->view('home/home');
		} elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else {
			$this->load->view('login/login');	
		}
	}

	public function PANELDISTP()
	{
		if ($this->session->userdata('level') == "Jr Manager") {
			$data['content'] = $this->db->where('kode_alat','PANELDISTP');
			$data['content'] = $this->db->get('tbl_paneldis');
			$this->load->view('dalamtower/paneldist/paneldist_teknikalpriority/teknikalpriority', $data);
		}elseif ($this->session->userdata('level') == "Admin") {
			$this->load->view('home/home');
		} elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else {
			$this->load->view('login/login');	
		}
	}

	public function PANELDISP1()
	{
		if ($this->session->userdata('level') == "Jr Manager") {
			$data['content'] = $this->db->where('kode_alat','PANELDISP1');
			$data['content'] = $this->db->get('tbl_paneldis');
			$this->load->view('dalamtower/paneldist/paneldist_priority1/priority1', $data);
		}elseif ($this->session->userdata('level') == "Admin") {
			$this->load->view('home/home');
		} elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else {
			$this->load->view('login/login');	
		}
	}

	public function PANELDISP2()
	{
		if ($this->session->userdata('level') == "Jr Manager") {
			$data['content'] = $this->db->where('kode_alat','PANELDISP2');
			$data['content'] = $this->db->get('tbl_paneldis');
			$this->load->view('dalamtower/paneldist/paneldist_priority2/priority2', $data);
		}elseif ($this->session->userdata('level') == "Admin") {
			$this->load->view('home/home');
		} elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else {
			$this->load->view('login/login');	
		}
	}

	public function UPS1()
	{
		if ($this->session->userdata('level') == "Jr Manager") {
			$data['content'] = $this->db->where('kode_alat','UPS1');
			$data['content'] = $this->db->get('tbl_ups');
			$this->load->view('dalamtower/ups/ups_1/ups_1', $data);
		}elseif ($this->session->userdata('level') == "Admin") {
			$this->load->view('home/home');
		} elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else {
			$this->load->view('login/login');	
		}
	}
	public function UPS2()
	{
		if ($this->session->userdata('level') == "Jr Manager") {
			$data['content'] = $this->db->where('kode_alat','UPS2');
			$data['content'] = $this->db->get('tbl_ups');
			$this->load->view('dalamtower/ups/ups_2/ups_2', $data);
		}elseif ($this->session->userdata('level') == "Admin") {
			$this->load->view('home/home');
		} elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else {
			$this->load->view('login/login');	
		}
	}

	public function EHFAN01()
	{
		if ($this->session->userdata('level') == "Jr Manager") {
			$data['content'] = $this->db->where('kode_alat','EHFAN01');
			$data['content'] = $this->db->get('tbl_exhaust_fan');
			$this->load->view('dalamtower/exhaustfan/exhaustfan', $data);
		}elseif ($this->session->userdata('level') == "Admin") {
			$this->load->view('home/home');
		} elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else {
			$this->load->view('login/login');	
		}
	}

	public function CCTV01()
	{
		if ($this->session->userdata('level') == "Jr Manager") {
			$data['content'] = $this->db->where('kode_alat','CCTV01');
			$data['content'] = $this->db->get('tbl_cctv');
			$this->load->view('dalamtower/cctv/cctv', $data);
		}elseif ($this->session->userdata('level') == "Admin") {
			$this->load->view('home/home');
		} elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else {
			$this->load->view('login/login');	
		}
	}
	public function BANGUNANAC()
	{
		if ($this->session->userdata('level') == "Jr Manager") {
			$data['content'] = $this->db->where('kode_alat','BANGUNANAC');
			$data['content'] = $this->db->get('tbl_bangunan_dan_ac');
			$this->load->view('dalamtower/bangunandanac/bangunandanac', $data);
		}elseif ($this->session->userdata('level') == "Admin") {
			$this->load->view('home/home');
		} elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else {
			$this->load->view('login/login');	
		}
	}

	public function detailpengecekan()
	{
		if($this->session->userdata('level') == "Jr Manager"){
			
			$data['content'] = $this->db->get('tbl_detail_pengecekan');
			$this->load->view('detailpengecekan/detailpengecekan', $data);
		} elseif($this->session->userdata('level') == "Admin"){
			redirect('admin','refresh');
		}elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else{
			redirect('login','refresh');
		}
	}

	public function logbookkegiatan()
	{
		if($this->session->userdata('level') == "Jr Manager"){
			
			$data['content'] = $this->db->get('tbl_logbookkegiatan');
			$this->load->view('logkegiatan/logkegiatan', $data);
		} elseif($this->session->userdata('level') == "Admin"){
			redirect('admin','refresh');
		}elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else{
			redirect('login','refresh');
		}
	}

	public function pegawai()
	{
		if($this->session->userdata('level') == "Jr Manager"){
			
			$data['content'] = $this->db->get('tbl_pegawai');
			$this->load->view('manajemenuser/pegawai/manajemenpegawai', $data);
		} elseif($this->session->userdata('level') == "Admin"){
			redirect('admin','refresh');
		}elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else{
			redirect('login','refresh');
		}
	}

	public function peralatan()
	{
		if($this->session->userdata('level') == "Jr Manager"){
			
			$data['content'] = $this->db->get('tbl_peralatan_dalam_tower');
			$this->load->view('manajemenperalatandalamtower/peralatandalamtower', $data);
		} elseif($this->session->userdata('level') == "Admin"){
			redirect('admin','refresh');
		}elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else{
			redirect('login','refresh');
		}
	}

	public function ubahpassword($username = '')
	{

		if ($this->session->userdata('level') == "Jr Manager") {
		$this->db->where('username', $username);
		$data['content'] = $this->db->get('tbl_user');
		$this->load->view('profil/ubahpassword', $data);
		} else if ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else {
			$this->load->view('errors');	
		}
	}

	public function action_ubahpassword($username = '')
	{
		$passwordbaru = $this->input->post('passwordbaru');
		$konfirmasi_password = $this->input->post('konfirmasi_password');
		$passwordlama = $this->input->post('passwordlama');
		$query = $this->db->query("SELECT * from tbl_user where password = '$passwordlama'");
		
		if ($query->num_rows() == 0){
			$this->session->set_flashdata('pesanerror3', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Password gagal diubah. Password lama anda salah!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	$this->ubahpassword($username);
		}

		else if ($passwordbaru != $konfirmasi_password) {
			$this->session->set_flashdata('pesanerror4', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Password gagal diubah. Password dan konfirmasi password harus sama!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  $this->ubahpassword($username);
		} else {

		              	$data = array(
						'password' => $this->input->post('passwordbaru'),
						'konfirmasi_password' => $this->input->post('konfirmasi_password'),
						);
		            $this->db->where('username', $username);
					$this->model_profil->ubahpassword($data, $username);
					$this->session->set_flashdata('pesanberhasilpassword', '<div class="alert alert-success alert-dismissible fade show" role="alert">
													  Password Anda berhasil Diubah!
													  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													    <span aria-hidden="true">&times;</span>
													  </button>
													</div>');
				redirect('jrmanager','refresh');
		}
	}
}

/* End of file Jrmanager.php */
/* Location: ./application/controllers/Jrmanager.php */