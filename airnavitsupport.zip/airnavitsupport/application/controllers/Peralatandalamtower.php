<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Peralatandalamtower extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
	}
	public function index()
	{
		if ($this->session->userdata('level') == "User") {
			$data['content'] = $this->db->get('tbl_peralatan_dalam_tower');
			$this->load->view('manajemenperalatandalamtower/peralatandalamtower', $data);
		}elseif ($this->session->userdata('level') == "Admin") {
			redirect('admin','refresh');
		} else {
			$this->load->view('login/login');
		}
	}
}

/* End of file Peralatan_dalam_tower.php */
/* Location: ./application/controllers/Peralatan_dalam_tower.php */