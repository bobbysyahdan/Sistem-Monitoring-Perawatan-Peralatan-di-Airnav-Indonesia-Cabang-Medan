<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profil extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->load->model('model_profil');
	}

	public function index()
	{	
	}

	public function profilsaya($nip = '')
	{

		if ($this->session->userdata('level') == "User") {
			if ($nip != $this->session->userdata('username')) {
				$this->load->view('errors');	
			}
			$this->db->where('nik', $nip);
			$data['content'] = $this->db->get('tbl_pegawai');
			$this->load->view('profil/user/user', $data);
		} else if ($this->session->userdata('level') == "Admin") {
			redirect('admin','refresh');
		} else {
			$this->load->view('errors');	
		}
	
	}

	public function updateprofil($nip = '')
	{
		$nip = $this->input->post('nip');
		$namafile =str_replace(' ', '_',date("d-m-y").("_").$nip.("_").$_FILES['foto']['name']); //nama file + fungsi time
		$jenis_gambar = $_FILES['foto']['type'];
		$size_gambar = $_FILES['foto']['size'];
        $config['upload_path'] = './assets/img/fotopegawai/'; //Folder untuk menyimpan hasil upload
        $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['max_size'] = '3072'; //maksimum besar file 3M
        $config['max_width']  = '5000'; //lebar maksimum 5000 px
        $config['max_height']  = '5000'; //tinggi maksimu 5000 px
        $config['file_name'] = $namafile; //nama yang terupload nantinya

        $this->upload->initialize($config);
        
        if(!empty($_FILES['foto']['name']))
        {
        	if($jenis_gambar !="image/jpeg" && $jenis_gambar !="image/jpg" && $jenis_gambar !="image/gif" && $jenis_gambar!="image/png")
				  {
				  	$this->session->set_flashdata('pesanerror', '<div class="alert alert-danger alert-dismissible fade show" 
								  					role="alert">
												  Profil gagal diupdate. Jenis gambar yang anda kirim salah. Harus berformat .jpg .gif .png!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	$this->profilsaya($nip);

				  }else if($size_gambar > 3000000){

					$this->session->set_flashdata('pesanerror2', '<div class="alert alert-danger alert-dismissible fade show" 
												role="alert">
												 Profil gagal diupdate. Upload foto maksimal 3MB!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
					$this->profilsaya($nip);

				  } else if( $this->upload->do_upload('foto')) {    
           				$this->upload->data();
           				$config['image_library']='gd2';
		                $config['source_image']='./assets/img/fotopegawai/'.$namafile;
		                $config['create_thumb']= FALSE;
		                $config['maintain_ratio']= FALSE;
		                $config['quality']= '60%';
		                $config['width']= 300;
		                $config['height']= 400;
		                $config['new_image']= './assets/img/fotopegawai/'.$namafile;
		                 $this->load->library('image_lib', $config);   
		                $this->image_lib->resize();

           				$data = array(
						'nama' => $this->input->post('nama'),
						'tanggal_lahir' => $this->input->post('tanggal_lahir'),
						'alamat' => $this->input->post('alamat'),
						'status' => $this->input->post('status'),
						'email' => $this->input->post('email'),
						'no_hp' => $this->input->post('no_hp'),
						'foto' => $namafile
					);

					$this->model_profil->updateprofil($data, $nip);
					$this->session->set_flashdata('pesanberhasil2', '<div class="alert alert-success alert-dismissible fade show" role="alert">
													  Profil anda Berhasil diupdate!
													  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													    <span aria-hidden="true">&times;</span>
													  </button>
													</div>');
					$this->profilsaya($nip);
				        
				  }
          }  else {
          	$fotolama = $this->input->post('fotolama');
			if ($_FILES['foto']['error'] === 4) {
					$foto = $fotolama;
				} else {
					$foto = $namafile;
				}

				$data = array(
						'nama' => $this->input->post('nama'),
						'tanggal_lahir' => $this->input->post('tanggal_lahir'),
						'alamat' => $this->input->post('alamat'),
						'status' => $this->input->post('status'),
						'email' => $this->input->post('email'),
						'no_hp' => $this->input->post('no_hp'),
						'foto' => $foto
					);

					$this->model_profil->updateprofil($data, $nip);
					$this->session->set_flashdata('pesanberhasil2', '<div class="alert alert-success alert-dismissible fade show" role="alert">
													  Profil anda Berhasil diupdate!
													  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													    <span aria-hidden="true">&times;</span>
													  </button>
													</div>');
					$this->profilsaya($nip);
	         }

		

		
	}

	public function ubahpassword($nip = '')
	{

		if ($this->session->userdata('level') == "User") {
			$this->db->where('username', $nip);
			$data['content'] = $this->db->get('tbl_user');
			if ($nip != $this->session->userdata('username')) {
				$this->load->view('errors');	
			}
		
		$this->load->view('profil/ubahpassword', $data);
		} else if ($this->session->userdata('level') == "Admin") {
			redirect('admin','refresh');
		} else {
			$this->load->view('errors');	
		}
	}

	public function action_ubahpassword($username = '')
	{
		$passwordbaru = $this->input->post('passwordbaru');
		$konfirmasi_password = $this->input->post('konfirmasi_password');
		$passwordlama = $this->input->post('passwordlama');
		$query = $this->db->query("SELECT * from tbl_user where password = '$passwordlama'");
		
		if ($query->num_rows() == 0){
			$this->session->set_flashdata('pesanerror3', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Password gagal diubah. Password lama anda salah!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	$this->ubahpassword($username);
		}

		else if ($passwordbaru != $konfirmasi_password) {
			$this->session->set_flashdata('pesanerror4', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Password gagal diubah. Password dan konfirmasi password harus sama!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  $this->ubahpassword($username);
		} else {

	
		              	$data = array(
						'password' => $this->input->post('passwordbaru'),
						'konfirmasi_password' => $this->input->post('konfirmasi_password'),
						);
		            $this->db->where('username', $username);
					$this->model_profil->ubahpassword($data, $username);
					$this->session->set_flashdata('pesanberhasilpassword', '<div class="alert alert-success alert-dismissible fade show" role="alert">
													  Password Anda berhasil Diubah!
													  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													    <span aria-hidden="true">&times;</span>
													  </button>
													</div>');
				$this->profilsaya($username);
		}
	}
}

/* End of file Profil.php */
/* Location: ./application/controllers/Profil.php */