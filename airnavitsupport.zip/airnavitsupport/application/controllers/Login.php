<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		//Do your magic here 
		$this->load->helper('url');
		$this->load->helper('form');
		$this->load->model('model_login');
		$this->load->library('session');
	}
	public function index()
	{
		if ($this->session->userdata('level') == "Admin") {
			redirect('admin','refresh');
		} elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else {
			$this->load->view('login/login');
		}
	}

	public function action_login()
	{

		$username = $this->input->post("username");
		$password = $this->input->post("password");
		$ceklogin = $this->model_login->action_login($username, $password);

		if ($ceklogin) {
			// foreach ($ceklogin as $row) {
			// 	$this->session->set_userdata('username', $row->username);
			// 	$this->session->set_userdata('level', $row->level);

			// 	if ($this->session->set_userdata('level') == "Admin") {
			// 		redirect('index/admin/','refresh');
			// 	} elseif ($this->session->set_userdata('level') == "User") {
			// 		redirect('','refresh');
			// 	}
			// }

			// redirect('','refresh');
			foreach ($ceklogin as $row) {
				$this->session->set_userdata('username', $row->username);
				$this->session->set_userdata('level', $row->level);
				if ($this->session->userdata('level') == "Admin") {
					redirect('admin','refresh');
				} elseif ($this->session->userdata('level') == "User") {
					redirect('','refresh');
				}  elseif ($this->session->userdata('level') == "Jr Manager") {
					redirect('jrmanager','refresh');
				}
			}
		}
				 else {
					$this->session->set_flashdata('gagallogin', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
  Username atau password anda salah!
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>');
					$this->load->view('login/login');
				}
	}

	// public function action_login()
	// {
	// 	$username = $this->input->post("username");
	// 	$password = $this->input->post("password");

	// 	$cek = $this->model_login->cek_login($username, $password);
	// 	if (count($cek) == 1) {
	// 		$this->session->set_userdata(array(
	// 			'isLogin' => TRUE;
	// 			'username' => $username;
	// 			'level' => $level;
	// 		));
	// 		redirect('','refresh');

	// 	} else {
	// 		$this->session->set_flashdata('gagallogin', 'Username atau password anda salah!');
	// 		// $data['pesan'] = "Username atau password anda salah!";
	// 		$this->load->view("login/login");
	// 	}
	// }

}

/* End of file Login.php */
/* Location: ./application/controllers/Login.php */