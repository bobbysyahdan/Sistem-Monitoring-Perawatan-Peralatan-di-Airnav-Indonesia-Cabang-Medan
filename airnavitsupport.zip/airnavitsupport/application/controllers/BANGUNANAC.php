<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class BANGUNANAC extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->load->library('upload');
		$this->load->model('model_bangunanac');
	}

	public function index()
	{
		if($this->session->userdata('level') == "User"){
			$data['content'] = $this->db->where('kode_alat','BANGUNANAC');
			$data['content'] = $this->db->get('tbl_bangunan_dan_ac');
			$this->load->view('dalamtower/bangunandanac/bangunandanac', $data);
		} elseif($this->session->userdata('level') == "Admin"){
			redirect('admin','refresh');
		} else{
			redirect('login','refresh');
		}
	}

	public function inputparameterharian()
	{
		if($this->session->userdata('level') == "User"){
			$this->load->view('dalamtower/bangunandanac/add');
		} elseif($this->session->userdata('level') == "Admin"){
			redirect('admin','refresh');
		} else{
			redirect('login','refresh');
		}	
	}

	public function action_add()
	{
		$periksa_aliran_udara_evapurator = $this->input->post("periksa_aliran_udara_evapurator");
		$pastikan_unit_outdoor_kompresor_bekerja = $this->input->post("pastikan_unit_outdoor_kompresor_bekerja");
		$kode_alat = $this->input->post('kode_alat');
		$tanggal = $this->input->post('tanggal');
		$dinas = $this->input->post('dinas');
		$query = $this->db->query("SELECT * from tbl_bangunan_dan_ac where kode_alat = '$kode_alat' AND tanggal = '$tanggal' AND dinas = '$dinas'");
		
		if ($query->num_rows() > 0){
			$this->session->set_flashdata('pesanerror3', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal ditambah. Tanggal dan dinas hari ini sudah diinput!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	redirect('BANGUNANAC/inputparameterharian');
		}

		$namafile = str_replace(' ', '_',date("d-m-y").("_").$dinas.("_").$kode_alat.("_").$_FILES['foto']['name']); //nama file + fungsi time
		$jenis_gambar = $_FILES['foto']['type'];
		$size_gambar = $_FILES['foto']['size'];
        $config['upload_path'] = './assets/img/fotokegiatan/bangunanac/'; //Folder untuk menyimpan hasil upload
        $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['file_name'] = $namafile; //nama yang terupload nantinya

        $this->upload->initialize($config);
        
         if(!empty($_FILES['foto']['name']))
        {
        	if($jenis_gambar !="image/jpeg" && $jenis_gambar !="image/jpg" && $jenis_gambar !="image/gif" && $jenis_gambar!="image/png")
				  {
				  	$this->session->set_flashdata('pesanerror', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal ditambah. Jenis gambar yang anda kirim salah. Harus berformat .jpg .gif .png!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	redirect('BANGUNANAC/inputparameterharian');
				  }else if($size_gambar > 3000000){

					$this->session->set_flashdata('pesanerror2', '<div class="alert alert-warning alert-dismissible fade show" 
													role="alert">
													  Data gagal ditambah. Upload foto maksimal 3MB!
													  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													    <span aria-hidden="true">&times;</span>
													  </button>
													</div>');
					redirect('BANGUNANAC/inputparameterharian');

				  } elseif($this->upload->do_upload('foto')){
				  		
           				$this->upload->data();
           		
           				$config['image_library']='gd2';
		                $config['source_image']='./assets/img/fotokegiatan/bangunanac/'.$namafile;
		                $config['create_thumb']= FALSE;
		                $config['maintain_ratio']= FALSE;
		                $config['quality']= '60%';
		                $config['width']= 800;
		                $config['height']= 400;
		                $config['new_image']= './assets/img/fotokegiatan/bangunanac/'.$namafile;

		                $this->load->library('image_lib', $config);   
		                $this->image_lib->resize();

           				// $config['image_library']='gd2';
		             //    $config['source_image']='./assets/img/fotokegiatan/bangunandanac/'.$namafile;
		             //    $config['create_thumb']= FALSE;
		             //    $config['maintain_ratio']= FALSE;
		             //    $config['quality']= '60%';
		             //    $config['width']= 800;
		             //    $config['height']= 400;
		             //    $config['new_image']= './assets/img/fotokegiatan/bangunandanac/'.$namafile;

		             //    $this->load->library('image_lib', $config);   
		             //    $this->image_lib->resize();


		$data = array(
			"kode_alat" => $this->input->post("kode_alat"),
			"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
			"tanggal" => $this->input->post("tanggal"),
			"dinas" => $this->input->post("dinas"),
			"lokasi" => $this->input->post("lokasi"),
			"kebersihan_ruangan" => $this->input->post("kebersihan_ruangan"),
			"kondisi_bangunan" => $this->input->post("kondisi_bangunan"),
			"suhu_ruangan" => $this->input->post("suhu_ruangan"),
			"periksa_aliran_udara_evapurator" => $this->input->post("periksa_aliran_udara_evapurator"),
			"pastikan_unit_outdoor_kompresor_bekerja" => $this->input->post("pastikan_unit_outdoor_kompresor_bekerja"),
			"foto" => $namafile,
			"catatan" => "Kondisi Normal"
		);

		$data2 = array(
			"kode_alat" => $this->input->post("kode_alat"),
			"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
			"tanggal" => $this->input->post("tanggal"),
			"dinas" => $this->input->post("dinas"),
			"lokasi" => $this->input->post("lokasi"),
			"kebersihan_ruangan" => $this->input->post("kebersihan_ruangan"),
			"kondisi_bangunan" => $this->input->post("kondisi_bangunan"),
			"suhu_ruangan" => $this->input->post("suhu_ruangan"),
			"periksa_aliran_udara_evapurator" => $this->input->post("periksa_aliran_udara_evapurator"),
			"pastikan_unit_outdoor_kompresor_bekerja" => $this->input->post("pastikan_unit_outdoor_kompresor_bekerja"),
			"foto" => $namafile,
			"catatan" => "Bangunan dan AC Tidak Dingin"
		);

		$data3 = array(
			"kode_alat" => $this->input->post("kode_alat"),
			"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
			"tanggal" => $this->input->post("tanggal"),
			"dinas" => $this->input->post("dinas"),
			"lokasi" => $this->input->post("lokasi"),
			"kebersihan_ruangan" => $this->input->post("kebersihan_ruangan"),
			"kondisi_bangunan" => $this->input->post("kondisi_bangunan"),
			"suhu_ruangan" => $this->input->post("suhu_ruangan"),
			"periksa_aliran_udara_evapurator" => $this->input->post("periksa_aliran_udara_evapurator"),
			"pastikan_unit_outdoor_kompresor_bekerja" => $this->input->post("pastikan_unit_outdoor_kompresor_bekerja"),
			"foto" => $namafile,
			"catatan" => "Unit Outdoor Kompresor Tidak Bekerja"
		);


		if ($periksa_aliran_udara_evapurator == "Tidak") {
			$this->model_bangunanac->action_add1($data2);
				$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil ditambah!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
			redirect('BANGUNANAC','refresh');
		} elseif($pastikan_unit_outdoor_kompresor_bekerja == "Tidak"){
			$this->model_bangunanac->action_add2($data3);
				$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil ditambah!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
			redirect('BANGUNANAC','refresh');
		} else {
		$this->model_bangunanac->action_add3($data);
			$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil ditambah!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
		redirect('BANGUNANAC','refresh');
				}
			}
		}
	}

	public function update($id = NULL)
	{	
		if($this->session->userdata('level') == "User"){
			$this->db->where('id', $id);
			$data['content'] = $this->db->get('tbl_bangunan_dan_ac');
			$this->load->view('dalamtower/bangunandanac/update', $data);
		} elseif($this->session->userdata('level') == "Admin"){
			redirect('admin','refresh');
		} else{
			redirect('login','refresh');
		}
	}

	public function action_update($id = '')
	{
		$periksa_aliran_udara_evapurator = $this->input->post("periksa_aliran_udara_evapurator");
		$pastikan_unit_outdoor_kompresor_bekerja = $this->input->post("pastikan_unit_outdoor_kompresor_bekerja");
		$kode_alat = $this->input->post('kode_alat');
		$tanggal = $this->input->post('tanggal');
		$dinas = $this->input->post('dinas');
		$namafile = str_replace(' ', '_',date("d-m-y").("_").$dinas.("_").$kode_alat.("_").$_FILES['foto']['name']); //nama file + fungsi time
		$jenis_gambar = $_FILES['foto']['type'];
		$size_gambar = $_FILES['foto']['size'];
        $config['upload_path'] = './assets/img/fotokegiatan/bangunanac/'; //Folder untuk menyimpan hasil upload
        $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
  
        $config['file_name'] = $namafile; //nama yang terupload nantinya

        $this->upload->initialize($config);
        
         if(!empty($_FILES['foto']['name']))
        {
        	if($jenis_gambar !="image/jpeg" && $jenis_gambar !="image/jpg" && $jenis_gambar !="image/gif" && $jenis_gambar!="image/png")
				  {
				  	$this->session->set_flashdata('pesanerror', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal ditambah. Jenis gambar yang anda kirim salah. Harus berformat .jpg .gif .png!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	$this->update($id);
				  }else if($size_gambar > 3000000){

					$this->session->set_flashdata('pesanerror2', '<div class="alert alert-warning alert-dismissible fade show" 
													role="alert">
													  Data gagal ditambah. Upload foto maksimal 3MB!
													  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													    <span aria-hidden="true">&times;</span>
													  </button>
													</div>');
					$this->update($id);

				  } elseif($this->upload->do_upload('foto')){
				  		
           				$this->upload->data();
           				
           				$config['image_library']='gd2';
		                $config['source_image']='./assets/img/fotokegiatan/bangunanac/'.$namafile;
		                $config['create_thumb']= FALSE;
		                $config['maintain_ratio']= FALSE;
		                $config['quality']= '60%';
		                $config['width']= 800;
		                $config['height']= 400;
		                $config['new_image']= './assets/img/fotokegiatan/bangunanac/'.$namafile;

		                $this->load->library('image_lib', $config);   
		                $this->image_lib->resize();
	

		$data = array(
			"kode_alat" => $this->input->post("kode_alat"),
			"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
			"tanggal" => $this->input->post("tanggal"),
			"dinas" => $this->input->post("dinas"),
			"lokasi" => $this->input->post("lokasi"),
			"kebersihan_ruangan" => $this->input->post("kebersihan_ruangan"),
			"kondisi_bangunan" => $this->input->post("kondisi_bangunan"),
			"suhu_ruangan" => $this->input->post("suhu_ruangan"),
			"periksa_aliran_udara_evapurator" => $this->input->post("periksa_aliran_udara_evapurator"),
			"pastikan_unit_outdoor_kompresor_bekerja" => $this->input->post("pastikan_unit_outdoor_kompresor_bekerja"),
			"foto" => $namafile,
			"catatan" => "Kondisi Normal"
		);

		$data2 = array(
			"kode_alat" => $this->input->post("kode_alat"),
			"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
			"tanggal" => $this->input->post("tanggal"),
			"dinas" => $this->input->post("dinas"),
			"lokasi" => $this->input->post("lokasi"),
			"kebersihan_ruangan" => $this->input->post("kebersihan_ruangan"),
			"kondisi_bangunan" => $this->input->post("kondisi_bangunan"),
			"suhu_ruangan" => $this->input->post("suhu_ruangan"),
			"periksa_aliran_udara_evapurator" => $this->input->post("periksa_aliran_udara_evapurator"),
			"pastikan_unit_outdoor_kompresor_bekerja" => $this->input->post("pastikan_unit_outdoor_kompresor_bekerja"),
			"foto" => $namafile,
			"catatan" => "Bangunan dan AC Tidak Dingin"
		);

		$data3 = array(
			"kode_alat" => $this->input->post("kode_alat"),
			"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
			"tanggal" => $this->input->post("tanggal"),
			"dinas" => $this->input->post("dinas"),
			"lokasi" => $this->input->post("lokasi"),
			"kebersihan_ruangan" => $this->input->post("kebersihan_ruangan"),
			"kondisi_bangunan" => $this->input->post("kondisi_bangunan"),
			"suhu_ruangan" => $this->input->post("suhu_ruangan"),
			"periksa_aliran_udara_evapurator" => $this->input->post("periksa_aliran_udara_evapurator"),
			"pastikan_unit_outdoor_kompresor_bekerja" => $this->input->post("pastikan_unit_outdoor_kompresor_bekerja"),
			"foto" => $namafile,
			"catatan" => "Unit Outdoor Kompresor Tidak Bekerja"
		);


		if ($periksa_aliran_udara_evapurator == "Tidak") {
			$this->model_bangunanac->action_update1($data2, $id);
				$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil diupdate!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
			redirect('BANGUNANAC','refresh');
		} elseif($pastikan_unit_outdoor_kompresor_bekerja == "Tidak"){
			$this->model_bangunanac->action_update2($data3, $id);
				$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil diupdate!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
			redirect('BANGUNANAC','refresh');
		} else {
		$this->model_bangunanac->action_update3($data, $id);
			$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil diupdate!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
		redirect('BANGUNANAC','refresh');
				}
			}
		} else {
			$fotolama = $this->input->post('fotolama');
						if ($_FILES['foto']['error'] === 4) {
								$foto = $fotolama;
							} else {
								$foto = $namafile;
							}


		$data = array(
			"kode_alat" => $this->input->post("kode_alat"),
			"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
			"tanggal" => $this->input->post("tanggal"),
			"dinas" => $this->input->post("dinas"),
			"lokasi" => $this->input->post("lokasi"),
			"kebersihan_ruangan" => $this->input->post("kebersihan_ruangan"),
			"kondisi_bangunan" => $this->input->post("kondisi_bangunan"),
			"suhu_ruangan" => $this->input->post("suhu_ruangan"),
			"periksa_aliran_udara_evapurator" => $this->input->post("periksa_aliran_udara_evapurator"),
			"pastikan_unit_outdoor_kompresor_bekerja" => $this->input->post("pastikan_unit_outdoor_kompresor_bekerja"),
			"foto" => $foto,
			"catatan" => "Kondisi Normal"
		);

		$data2 = array(
			"kode_alat" => $this->input->post("kode_alat"),
			"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
			"tanggal" => $this->input->post("tanggal"),
			"dinas" => $this->input->post("dinas"),
			"lokasi" => $this->input->post("lokasi"),
			"kebersihan_ruangan" => $this->input->post("kebersihan_ruangan"),
			"kondisi_bangunan" => $this->input->post("kondisi_bangunan"),
			"suhu_ruangan" => $this->input->post("suhu_ruangan"),
			"periksa_aliran_udara_evapurator" => $this->input->post("periksa_aliran_udara_evapurator"),
			"pastikan_unit_outdoor_kompresor_bekerja" => $this->input->post("pastikan_unit_outdoor_kompresor_bekerja"),
			"foto" => $foto,
			"catatan" => "Bangunan dan AC Tidak Dingin"
		);

		$data3 = array(
			"kode_alat" => $this->input->post("kode_alat"),
			"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
			"tanggal" => $this->input->post("tanggal"),
			"dinas" => $this->input->post("dinas"),
			"lokasi" => $this->input->post("lokasi"),
			"kebersihan_ruangan" => $this->input->post("kebersihan_ruangan"),
			"kondisi_bangunan" => $this->input->post("kondisi_bangunan"),
			"suhu_ruangan" => $this->input->post("suhu_ruangan"),
			"periksa_aliran_udara_evapurator" => $this->input->post("periksa_aliran_udara_evapurator"),
			"pastikan_unit_outdoor_kompresor_bekerja" => $this->input->post("pastikan_unit_outdoor_kompresor_bekerja"),
			"foto" => $foto,
			"catatan" => "Unit Outdoor Kompresor Tidak Bekerja"
		);


		if ($periksa_aliran_udara_evapurator == "Tidak") {
			$this->model_bangunanac->action_update1($data2, $id);
				$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil diupdate!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
			redirect('BANGUNANAC','refresh');
		} elseif($pastikan_unit_outdoor_kompresor_bekerja == "Tidak"){
			$this->model_bangunanac->action_update2($data3, $id);
				$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil diupdate!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
			redirect('BANGUNANAC','refresh');
			
		} else {
		$this->model_bangunanac->action_update3($data, $id);
				$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil diupdate!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
		redirect('BANGUNANAC','refresh');
				}
			}
		
	}

	public function delete($id = NULL)
	{
		if($this->session->userdata('level') == "User"){
			$this->model_bangunanac->action_delete($id);
			$this->session->set_flashdata('pesanberhasilhapus', '<div class="alert alert-success alert-dismissible fade show" role="alert">
											  Data Berhasil dihapus!
											  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
											    <span aria-hidden="true">&times;</span>
											  </button>
											</div>');
			redirect('BANGUNANAC','refresh');
		} elseif($this->session->userdata('level') == "Admin"){
			redirect('admin','refresh');
		} else{
			redirect('login','refresh');
		}
	} 
}

/* End of file Bangunan_dan_ac.php */
/* Location: ./application/controllers/Bangunan_dan_ac.php */