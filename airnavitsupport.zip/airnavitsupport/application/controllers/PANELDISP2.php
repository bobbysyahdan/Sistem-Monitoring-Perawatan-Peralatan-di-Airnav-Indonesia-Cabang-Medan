<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PANELDISP2 extends CI_Controller {
public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->load->library('upload');
		$this->load->model('model_paneldis');
		$this->load->helper(array('form', 'url'));
	}

	public function index()
	{
		if($this->session->userdata('level') == "User"){
			$data['content'] = $this->db->where('kode_alat','PANELDISP2');
			$data['content'] = $this->db->get('tbl_paneldis');
			$this->load->view('dalamtower/paneldist/paneldist_priority2/priority2', $data);
		} elseif($this->session->userdata('level') == "Admin"){
			redirect('admin','refresh');
		} else{
			redirect('login','refresh');
		}
	}


	public function inputparameterharian()
	{
		if($this->session->userdata('level') == "User"){
			$this->load->view('dalamtower/paneldist/paneldist_priority2/add');
		} elseif($this->session->userdata('level') == "Admin"){
			redirect('admin','refresh');
		} else{
			redirect('login','refresh');
		}	
	}

	//Action tambah satu data
	public function action_add(){

		$kode_alat = $this->input->post('kode_alat');
		$tanggal = $this->input->post('tanggal');
		$dinas = $this->input->post('dinas');
		$query = $this->db->query("SELECT * from tbl_paneldis where kode_alat = '$kode_alat' AND tanggal = '$tanggal' AND dinas = '$dinas'");
		
		if ($query->num_rows() > 0){
			$this->session->set_flashdata('pesanerror3', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal ditambah. Tanggal dan dinas hari ini sudah diinput!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	redirect('PANELDISP2/inputparameterharian');
		}

		$tegangan_r = $this->input->post('teganganr');
		$tegangan_s = $this->input->post('tegangans');
		$tegangan_t = $this->input->post('tegangant');
		$tegangan_r_s = $this->input->post('teganganrs');
		$tegangan_r_t = $this->input->post('teganganrt');
		$tegangan_t_s = $this->input->post('tegangants');
		$frekuensi = $this->input->post('frekuensi');
		
		$namafile = str_replace(' ', '_',date("d-m-y").("_").$dinas.("_").$kode_alat.("_").$_FILES['foto']['name']); //nama file + fungsi time
		$jenis_gambar = $_FILES['foto']['type'];
		$size_gambar = $_FILES['foto']['size'];
        $config['upload_path'] = './assets/img/fotokegiatan/paneldis/'; //Folder untuk menyimpan hasil upload
        $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['file_name'] = $namafile; //nama yang terupload nantinya

        $this->upload->initialize($config);
        
         if(!empty($_FILES['foto']['name']))
        {
        	if($jenis_gambar !="image/jpeg" && $jenis_gambar !="image/jpg" && $jenis_gambar !="image/gif" && $jenis_gambar!="image/png")
				  {
				  	$this->session->set_flashdata('pesanerror', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal ditambah. Jenis gambar yang anda kirim salah. Harus berformat .jpg .gif .png!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	redirect('PANELDISP2/inputparameterharian');
				  }else if($size_gambar > 3000000){

					$this->session->set_flashdata('pesanerror2', '<div class="alert alert-warning alert-dismissible fade show" 
													role="alert">
													  Data gagal ditambah. Upload foto maksimal 3MB!
													  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													    <span aria-hidden="true">&times;</span>
													  </button>
													</div>');
					redirect('PANELDISP2/inputparameterharian');

				  } elseif($this->upload->do_upload('foto')){
				  		
           				$this->upload->data();
           				
           				$config['image_library']='gd2';
		                $config['source_image']='./assets/img/fotokegiatan/paneldis/'.$namafile;
		                $config['create_thumb']= FALSE;
		                $config['maintain_ratio']= FALSE;
		                $config['quality']= '60%';
		                $config['width']= 800;
		                $config['height']= 400;
		                $config['new_image']= './assets/img/fotokegiatan/paneldis/'.$namafile;

		                $this->load->library('image_lib', $config);   
		                $this->image_lib->resize();
	
		$data = array(
			"kode_alat" => $this->input->post("kode_alat"),
			"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
			"tanggal" => $this->input->post("tanggal"),
			"dinas" => $this->input->post("dinas"),
			"lokasi" => $this->input->post("lokasi"),
			"tegangan_r" => $this->input->post("teganganr"),
			"tegangan_r_s" => $this->input->post("teganganrs"),
			"tegangan_s" => $this->input->post("tegangans"),
			"tegangan_r_t" => $this->input->post("teganganrt"),
			"tegangan_t" => $this->input->post("tegangant"),
			"tegangan_t_s" => $this->input->post("tegangants"),
			"arus_r" => $this->input->post("arusr"),
			"arus_s" => $this->input->post("aruss"),
			"arus_t" => $this->input->post("arust"),
			"frekuensi" => $this->input->post("frekuensi"),
			"mode_operasi" => $this->input->post("mode_operasi"),
			"kebersihan_panel" => $this->input->post("kebersihan_panel"),
			"foto" => $namafile,
			"catatan" => "Nilai Parameter Normal"
		);

		$data2 = array(
			"kode_alat" => $this->input->post("kode_alat"),
			"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
			"tanggal" => $this->input->post("tanggal"),
			"dinas" => $this->input->post("dinas"),
			"lokasi" => $this->input->post("lokasi"),
			"tegangan_r" => $this->input->post("teganganr"),
			"tegangan_r_s" => $this->input->post("teganganrs"),
			"tegangan_s" => $this->input->post("tegangans"),
			"tegangan_r_t" => $this->input->post("teganganrt"),
			"tegangan_t" => $this->input->post("tegangant"),
			"tegangan_t_s" => $this->input->post("tegangants"),
			"arus_r" => $this->input->post("arusr"),
			"arus_s" => $this->input->post("aruss"),
			"arus_t" => $this->input->post("arust"),
			"frekuensi" => $this->input->post("frekuensi"),
			"mode_operasi" => $this->input->post("mode_operasi"),
			"kebersihan_panel" => $this->input->post("kebersihan_panel"),
			"foto" => $namafile,
			"catatan" => "Tegangan Tidak Normal"
		);

		$data3 = array(
			"kode_alat" => $this->input->post("kode_alat"),
			"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
			"tanggal" => $this->input->post("tanggal"),
			"dinas" => $this->input->post("dinas"),
			"lokasi" => $this->input->post("lokasi"),
			"tegangan_r" => $this->input->post("teganganr"),
			"tegangan_r_s" => $this->input->post("teganganrs"),
			"tegangan_s" => $this->input->post("tegangans"),
			"tegangan_r_t" => $this->input->post("teganganrt"),
			"tegangan_t" => $this->input->post("tegangant"),
			"tegangan_t_s" => $this->input->post("tegangants"),
			"arus_r" => $this->input->post("arusr"),
			"arus_s" => $this->input->post("aruss"),
			"arus_t" => $this->input->post("arust"),
			"frekuensi" => $this->input->post("frekuensi"),
			"mode_operasi" => $this->input->post("mode_operasi"),
			"kebersihan_panel" => $this->input->post("kebersihan_panel"),
			"foto" => $namafile,
			"catatan" => "Frekuensi Tidak Normal"
		);

		// if ($tegangan_r >= 215 && $tegangan_r <= 235 && $tegangan_s >= 215 && $tegangan_s <= 235 && $tegangan_t >= 215 && $tegangan_t <= 235) {
		// 	$this->db->insert('tbl_paneldis_teknikal_priority', $data);
		// 	redirect('paneldist_teknikalpriority','refresh');
		// }  else  {
		// 	$this->db->insert('tbl_paneldis_teknikal_priority', $data2);
		// 	redirect('paneldist_teknikalpriority','refresh');
		// }

		if ($tegangan_r < 215 || $tegangan_r > 235 
			|| $tegangan_s < 215 || $tegangan_s > 235 
			|| $tegangan_t < 215 || $tegangan_t > 235 
			|| $tegangan_r_s < 375 || $tegangan_r_s > 405
			|| $tegangan_r_t < 375 || $tegangan_r_t > 405
			|| $tegangan_t_s < 375 || $tegangan_t_s > 405) {
			$this->model_paneldis->action_add3($data2);
			// $this->db->insert('tbl_paneldis', $data2);
			$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil ditambah!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
			redirect('PANELDISP2','refresh');
		} elseif ($frekuensi < 50 || $frekuensi > 55) {
			$this->model_paneldis->action_add2($data3);
			// $this->db->insert('tbl_paneldis', $data3);
			 $this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil ditambah!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
			redirect('PANELDISP2','refresh');
		} else {
			$this->model_paneldis->action_add1($data);
			// $this->db->insert('tbl_paneldis', $data);
			 $this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil ditambah!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
			redirect('PANELDISP2','refresh');
				}
			}
		}
	}

	public function update($id = NULL){
		if($this->session->userdata('level') == "User"){
			$this->db->where('id', $id);
			$data['content'] = $this->db->get('tbl_paneldis');
			$this->load->view('dalamtower/paneldist/paneldist_priority2/update', $data);
		} elseif($this->session->userdata('level') == "Admin"){
			redirect('admin','refresh');
		} else{
			redirect('login','refresh');
		}
	}

	public function action_update($id = '')
	{
		$kode_alat = $this->input->post('kode_alat');
		$dinas = $this->input->post('dinas');
		$tegangan_r = $this->input->post('teganganr');
		$tegangan_s = $this->input->post('tegangans');
		$tegangan_t = $this->input->post('tegangant');
		$tegangan_r_s = $this->input->post('teganganrs');
		$tegangan_r_t = $this->input->post('teganganrt');
		$tegangan_t_s = $this->input->post('tegangants');
		$frekuensi = $this->input->post('frekuensi');
		$namafile = str_replace(' ', '_',date("d-m-y").("_").$dinas.("_").$kode_alat.("_").$_FILES['foto']['name']); //nama file + fungsi time
		$jenis_gambar = $_FILES['foto']['type'];
		$size_gambar = $_FILES['foto']['size'];
        $config['upload_path'] = './assets/img/fotokegiatan/paneldis/'; //Folder untuk menyimpan hasil upload
        $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['file_name'] = $namafile; //nama yang terupload nantinya

        $this->upload->initialize($config);
        
         if(!empty($_FILES['foto']['name']))
        {
        	if($jenis_gambar !="image/jpeg" && $jenis_gambar !="image/jpg" && $jenis_gambar !="image/gif" && $jenis_gambar!="image/png")
				  {
				  	$this->session->set_flashdata('pesanerror', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal diupdate. Jenis gambar yang anda kirim salah. Harus berformat .jpg .gif .png!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	$this->update($id);
				  }else if($size_gambar > 3000000){

					$this->session->set_flashdata('pesanerror2', '<div class="alert alert-warning alert-dismissible fade show" 
													role="alert">
													  Data gagal diupdate. Upload foto maksimal 3MB!
													  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													    <span aria-hidden="true">&times;</span>
													  </button>
													</div>');
					$this->update($id);

				  } elseif($this->upload->do_upload('foto')){
				  		
           				$this->upload->data();
           			
           				$config['image_library']='gd2';
		                $config['source_image']='./assets/img/fotokegiatan/paneldis/'.$namafile;
		                $config['create_thumb']= FALSE;
		                $config['maintain_ratio']= FALSE;
		                $config['quality']= '60%';
		                $config['width']= 800;
		                $config['height']= 400;
		                $config['new_image']= './assets/img/fotokegiatan/paneldis/'.$namafile;

		                $this->load->library('image_lib', $config);   
		                $this->image_lib->resize();

		$data = array(
			"kode_alat" => $this->input->post("kode_alat"),
			"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
			"tanggal" => $this->input->post("tanggal"),
			"dinas" => $this->input->post("dinas"),
			"lokasi" => $this->input->post("lokasi"),
			"tegangan_r" => $this->input->post("teganganr"),
			"tegangan_r_s" => $this->input->post("teganganrs"),
			"tegangan_s" => $this->input->post("tegangans"),
			"tegangan_r_t" => $this->input->post("teganganrt"),
			"tegangan_t" => $this->input->post("tegangant"),
			"tegangan_t_s" => $this->input->post("tegangants"),
			"arus_r" => $this->input->post("arusr"),
			"arus_s" => $this->input->post("aruss"),
			"arus_t" => $this->input->post("arust"),
			"frekuensi" => $this->input->post("frekuensi"),
			"mode_operasi" => $this->input->post("mode_operasi"),
			"kebersihan_panel" => $this->input->post("kebersihan_panel"),
			"foto" =>$namafile,
			"catatan" => "Nilai Parameter Normal"
		);

		$data2 = array(
			"kode_alat" => $this->input->post("kode_alat"),
			"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
			"tanggal" => $this->input->post("tanggal"),
			"dinas" => $this->input->post("dinas"),
			"lokasi" => $this->input->post("lokasi"),
			"tegangan_r" => $this->input->post("teganganr"),
			"tegangan_r_s" => $this->input->post("teganganrs"),
			"tegangan_s" => $this->input->post("tegangans"),
			"tegangan_r_t" => $this->input->post("teganganrt"),
			"tegangan_t" => $this->input->post("tegangant"),
			"tegangan_t_s" => $this->input->post("tegangants"),
			"arus_r" => $this->input->post("arusr"),
			"arus_s" => $this->input->post("aruss"),
			"arus_t" => $this->input->post("arust"),
			"frekuensi" => $this->input->post("frekuensi"),
			"mode_operasi" => $this->input->post("mode_operasi"),
			"kebersihan_panel" => $this->input->post("kebersihan_panel"),
			"foto" => $namafile,
			"catatan" => "Tegangan Tidak Normal"
		);

		$data3 = array(
			"kode_alat" => $this->input->post("kode_alat"),
			"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
			"tanggal" => $this->input->post("tanggal"),
			"dinas" => $this->input->post("dinas"),
			"lokasi" => $this->input->post("lokasi"),
			"tegangan_r" => $this->input->post("teganganr"),
			"tegangan_r_s" => $this->input->post("teganganrs"),
			"tegangan_s" => $this->input->post("tegangans"),
			"tegangan_r_t" => $this->input->post("teganganrt"),
			"tegangan_t" => $this->input->post("tegangant"),
			"tegangan_t_s" => $this->input->post("tegangants"),
			"arus_r" => $this->input->post("arusr"),
			"arus_s" => $this->input->post("aruss"),
			"arus_t" => $this->input->post("arust"),
			"frekuensi" => $this->input->post("frekuensi"),
			"mode_operasi" => $this->input->post("mode_operasi"),
			"kebersihan_panel" => $this->input->post("kebersihan_panel"),
			"foto" => $namafile,
			"catatan" => "Frekuensi Tidak Normal"
		);

		if ($tegangan_r < 215 || $tegangan_r > 235 
			|| $tegangan_s < 215 || $tegangan_s > 235 
			|| $tegangan_t < 215 || $tegangan_t > 235 
			|| $tegangan_r_s < 375 || $tegangan_r_s > 405
			|| $tegangan_r_t < 375 || $tegangan_r_t > 405
			|| $tegangan_t_s < 375 || $tegangan_t_s > 405) {
			$this->model_paneldis->action_update1($data2, $id);
			$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil diupdate!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
			redirect('PANELDISP2','refresh');
		} elseif ($frekuensi < 50 || $frekuensi > 55) {
			$this->model_paneldis->action_update2($data3, $id);
			$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil diupdate!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
			redirect('PANELDISP2','refresh');
		} else {
			$this->model_paneldis->action_update3($data, $id);
			$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil diupdate!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
			redirect('PANELDISP2','refresh');
				}
			}
		} else {
			$fotolama = $this->input->post('fotolama');
						if ($_FILES['foto']['error'] === 4) {
								$foto = $fotolama;
							} else {
								$foto = $namafile;
							}
			$data = array(
			"kode_alat" => $this->input->post("kode_alat"),
			"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
			"tanggal" => $this->input->post("tanggal"),
			"dinas" => $this->input->post("dinas"),
			"lokasi" => $this->input->post("lokasi"),
			"tegangan_r" => $this->input->post("teganganr"),
			"tegangan_r_s" => $this->input->post("teganganrs"),
			"tegangan_s" => $this->input->post("tegangans"),
			"tegangan_r_t" => $this->input->post("teganganrt"),
			"tegangan_t" => $this->input->post("tegangant"),
			"tegangan_t_s" => $this->input->post("tegangants"),
			"arus_r" => $this->input->post("arusr"),
			"arus_s" => $this->input->post("aruss"),
			"arus_t" => $this->input->post("arust"),
			"frekuensi" => $this->input->post("frekuensi"),
			"mode_operasi" => $this->input->post("mode_operasi"),
			"kebersihan_panel" => $this->input->post("kebersihan_panel"),
			"foto" =>$foto,
			"catatan" => "Nilai Parameter Normal"
		);

		$data2 = array(
			"kode_alat" => $this->input->post("kode_alat"),
			"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
			"tanggal" => $this->input->post("tanggal"),
			"dinas" => $this->input->post("dinas"),
			"lokasi" => $this->input->post("lokasi"),
			"tegangan_r" => $this->input->post("teganganr"),
			"tegangan_r_s" => $this->input->post("teganganrs"),
			"tegangan_s" => $this->input->post("tegangans"),
			"tegangan_r_t" => $this->input->post("teganganrt"),
			"tegangan_t" => $this->input->post("tegangant"),
			"tegangan_t_s" => $this->input->post("tegangants"),
			"arus_r" => $this->input->post("arusr"),
			"arus_s" => $this->input->post("aruss"),
			"arus_t" => $this->input->post("arust"),
			"frekuensi" => $this->input->post("frekuensi"),
			"mode_operasi" => $this->input->post("mode_operasi"),
			"kebersihan_panel" => $this->input->post("kebersihan_panel"),
			"foto" => $foto,
			"catatan" => "Tegangan Tidak Normal"
		);

		$data3 = array(
			"kode_alat" => $this->input->post("kode_alat"),
			"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
			"tanggal" => $this->input->post("tanggal"),
			"dinas" => $this->input->post("dinas"),
			"lokasi" => $this->input->post("lokasi"),
			"tegangan_r" => $this->input->post("teganganr"),
			"tegangan_r_s" => $this->input->post("teganganrs"),
			"tegangan_s" => $this->input->post("tegangans"),
			"tegangan_r_t" => $this->input->post("teganganrt"),
			"tegangan_t" => $this->input->post("tegangant"),
			"tegangan_t_s" => $this->input->post("tegangants"),
			"arus_r" => $this->input->post("arusr"),
			"arus_s" => $this->input->post("aruss"),
			"arus_t" => $this->input->post("arust"),
			"frekuensi" => $this->input->post("frekuensi"),
			"mode_operasi" => $this->input->post("mode_operasi"),
			"kebersihan_panel" => $this->input->post("kebersihan_panel"),
			"foto" => $foto,
			"catatan" => "Frekuensi Tidak Normal"
		);

		if ($tegangan_r < 215 || $tegangan_r > 235 
			|| $tegangan_s < 215 || $tegangan_s > 235 
			|| $tegangan_t < 215 || $tegangan_t > 235 
			|| $tegangan_r_s < 375 || $tegangan_r_s > 405
			|| $tegangan_r_t < 375 || $tegangan_r_t > 405
			|| $tegangan_t_s < 375 || $tegangan_t_s > 405) {
			$this->model_paneldis->action_update1($data2, $id);
			$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil diupdate!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
			redirect('PANELDISP2','refresh');
		} elseif ($frekuensi < 50 || $frekuensi > 55) {
			$this->model_paneldis->action_update2($data3, $id);
			$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil diupdate!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
			redirect('PANELDISP2','refresh');
		} else {
			$this->model_paneldis->action_update3($data, $id);
			$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil diupdate!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
			redirect('PANELDISP2','refresh');
				}
		}
	}

	public function delete($id = '')
	{
		if($this->session->userdata('level') == "User"){
			$this->model_paneldis->action_delete($id);
			$this->session->set_flashdata('pesanberhasilhapus', '<div class="alert alert-success alert-dismissible fade show" role="alert">
											  Data Berhasil dihapus!
											  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
											    <span aria-hidden="true">&times;</span>
											  </button>
											</div>');
			redirect('PANELDISP2','refresh');
		} elseif($this->session->userdata('level') == "Admin"){
			redirect('admin','refresh');
		} else{
			redirect('login','refresh');
		}
	}
		
}

/* End of file PANELDISTP.php */
/* Location: ./application/controllers/PANELDISTP.php */