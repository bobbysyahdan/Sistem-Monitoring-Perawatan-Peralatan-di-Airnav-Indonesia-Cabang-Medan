<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->load->model('model_manajemenpegawai');
		$this->load->model('model_manajemenuser');
		$this->load->model('model_manajemenperalatandalamtower');
		$this->load->model('model_profil');
		$this->load->library('upload');
	}

	public function index()
	{
		if ($this->session->userdata('level') == "Admin") {
			$this->load->view('home/home');
		} elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else {
			$this->load->view('login/login');	
		}
	}

// Pegawai
	public function manajemenpegawai()
	{
		if ($this->session->userdata('level') == "Admin") {
			$data['content'] = $this->db->get('tbl_pegawai');
			$this->load->view('manajemenuser/pegawai/manajemenpegawai', $data);
		} elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else {
			$this->load->view('errors');	
		}
	}

	public function menambahdatapegawai()
	{ 
		if ($this->session->userdata('level') == "Admin") {
			$this->load->view('manajemenuser/pegawai/add');
		} elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else {
			$this->load->view('errors');	
		}
	}

	public function action_menambahdatapegawai()
	{
		$nip = $this->input->post('nip');
		$query = $this->db->query("SELECT * from tbl_pegawai where nik = '$nip'");
		
		if ($query->num_rows() > 0){
			$this->session->set_flashdata('pesanerror3', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal ditambah. NIK yang dimasukkan sudah ada!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	redirect('admin/menambahdatapegawai');
		}

		$namafile =str_replace(' ', '_',date("d-m-y").("_").$nip.("_").$_FILES['foto']['name']); //nama file + fungsi time
		$jenis_gambar = $_FILES['foto']['type'];
		$size_gambar = $_FILES['foto']['size'];
        $config['upload_path'] = './assets/img/fotopegawai/'; //Folder untuk menyimpan hasil upload
        $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['file_name'] = $namafile; //nama yang terupload nantinya

        $this->upload->initialize($config);
        if(!empty($_FILES['foto']['name']))
        {
        	if($jenis_gambar !="image/jpeg" && $jenis_gambar !="image/jpg" && $jenis_gambar !="image/gif" && $jenis_gambar!="image/png")
				  {
				  	$this->session->set_flashdata('pesanerror', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal ditambah. Jenis gambar yang anda kirim salah. Harus berformat .jpg .gif .png!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	redirect('admin/menambahdatapegawai');
				  }else if($size_gambar > 3000000){

					$this->session->set_flashdata('pesanerror2', '<div class="alert alert-warning alert-dismissible fade show" 
													role="alert">
													  Data gagal ditambah. Upload foto maksimal 3MB!
													  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													    <span aria-hidden="true">&times;</span>
													  </button>
													</div>');
					redirect('admin/menambahdatapegawai');

				  } else {


				       if($this->upload->do_upload('foto')){
           				$this->upload->data();

		                $config['image_library']='gd2';
		                $config['source_image']='./assets/img/fotopegawai/'.$namafile;
		                $config['create_thumb']= FALSE;
		                $config['maintain_ratio']= FALSE;
		                $config['quality']= '60%';
		                $config['width']= 300;
		                $config['height']= 400;
		                $config['new_image']= './assets/img/fotopegawai/'.$namafile;

		                $this->load->library('image_lib', $config);   
		                $this->image_lib->resize();
		   
		              	$data = array(
						'nik' => $this->input->post('nip'),
						'nama' => $this->input->post('nama'),
						'tanggal_lahir' => $this->input->post('tanggal_lahir'),
						'alamat' => $this->input->post('alamat'),
						'status' => $this->input->post('status'),
						'email' => $this->input->post('email'),
						'no_hp' => $this->input->post('no_hp'),
						'foto' => $namafile
					);

					$this->model_manajemenpegawai->menambahdatapegawai($data);
					$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
													  Data Berhasil ditambah!
													  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													    <span aria-hidden="true">&times;</span>
													  </button>
													</div>');
					redirect('admin/manajemenpegawai','refresh');
		         } 
		     }
		  }
	}


	public function updatedatapegawai($id = NULL)
	{
		if ($this->session->userdata('level') == "Admin") {
			$this->db->where('id', $id);
			$data['content'] = $this->db->get('tbl_pegawai');
			$this->load->view('manajemenuser/pegawai/update', $data);
		} elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else {
			$this->load->view('errors');	
		}
	}

	public function action_updatedatapegawai($id = '')
	{
		$nip = $this->input->post('nip');
		$namafile =str_replace(' ', '_',date("d-m-y").("_").$nip.("_").$_FILES['foto']['name']); //nama file + fungsi time
		$jenis_gambar = $_FILES['foto']['type'];
		$size_gambar = $_FILES['foto']['size'];
        $config['upload_path'] = './assets/img/fotopegawai/'; //Folder untuk menyimpan hasil upload
        $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['file_name'] = $namafile; //nama yang terupload nantinya
	
        $this->upload->initialize($config);
        
        if(!empty($_FILES['foto']['name']))
        {
        	if($jenis_gambar !="image/jpeg" && $jenis_gambar !="image/jpg" && $jenis_gambar !="image/gif" && $jenis_gambar!="image/png")
				  {
				  	$this->session->set_flashdata('pesanerror', '<div class="alert alert-warning alert-dismissible fade show" 
								  					role="alert">
												  Data gagal diupdate. Jenis gambar yang anda kirim salah. Harus berformat .jpg .gif .png!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	$this->updatedatapegawai($id);
				  }else if($size_gambar > 3000000){

					$this->session->set_flashdata('pesanerror2', '<div class="alert alert-warning alert-dismissible fade show" 
												role="alert">
												  Data gagal diupdate. Upload foto maksimal 3MB!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
					$this->updatedatapegawai($id);

				  } else{ 
				  
				  if($this->upload->do_upload('foto')) {
           				$this->upload->data();
           				$config['image_library']='gd2';
		                $config['source_image']='./assets/img/fotopegawai/'.$namafile;
		                $config['create_thumb']= FALSE;
		                $config['maintain_ratio']= FALSE;
		                $config['quality']= '60%';
		                $config['width']= 300;
		                $config['height']= 400;
		                $config['new_image']= './assets/img/fotopegawai/'.$namafile;

		                $this->load->library('image_lib', $config);   
		                $this->image_lib->resize();

		$data = array(
			'nik' => $this->input->post('nip'),
			'nama' => $this->input->post('nama'),
			'tanggal_lahir' => $this->input->post('tanggal_lahir'),
			'alamat' => $this->input->post('alamat'),
			'status' => $this->input->post('status'),
			'email' => $this->input->post('email'),
			'no_hp' => $this->input->post('no_hp'),
			'foto' => $namafile
		);

		$this->model_manajemenpegawai->updatedatapegawai($data, $id);
		$this->session->set_flashdata('pesanberhasil2', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil diupdate!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
		redirect('admin/manajemenpegawai','refresh');
			} 
		}
	}
	else{
		        $fotolama = $this->input->post('fotolama');
        				if ($_FILES['foto']['error'] === 4) {
							$foto = $fotolama;
						} else {
							$foto = $namafile;
						}	
			$data = array(
			'nik' => $this->input->post('nip'),
			'nama' => $this->input->post('nama'),
			'tanggal_lahir' => $this->input->post('tanggal_lahir'),
			'alamat' => $this->input->post('alamat'),
			'status' => $this->input->post('status'),
			'email' => $this->input->post('email'),
			'no_hp' => $this->input->post('no_hp'),
			'foto' => $foto
		);

		$this->model_manajemenpegawai->updatedatapegawai($data, $id);
		$this->session->set_flashdata('pesanberhasil2', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil diupdate!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
		redirect('admin/manajemenpegawai','refresh');
	}
}

	public function action_deletedatapegawai($id = '')
	{
		if ($this->session->userdata('level') == "Admin") {
			$this->model_manajemenpegawai->deletedatapegawai($id);
			redirect('admin/manajemenpegawai','refresh');
		} elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else {
			$this->load->view('login/login');	
		}
	}

// Tutup Pegawai


// User
	public function manajemenuser()
	{
		if ($this->session->userdata('level') == "Admin") {
			$data['content'] = $this->db->get('tbl_user');
			$this->load->view('manajemenuser/user/manajemenuser', $data);
		} elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else {
			$this->load->view('errors');	
		}
	}

	public function menambahdatauser()
	{ 
		if ($this->session->userdata('level') == "Admin") {
			$data['content'] = $this->db->get('tbl_pegawai');
			$this->load->view('manajemenuser/user/add', $data);
		} elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else {
			$this->load->view('errors');	
		}
	}

	public function action_menambahdatauser()
	{
		$level = $this->input->post('level');
		$querylvl = $query = $this->db->query("SELECT * from tbl_user where level = '$level'");
		if ($query->num_rows() > 0){
			$this->session->set_flashdata('pesanerror5', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal ditambah. Akun Jr Manager Hanya boleh satu akun!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	redirect('admin/menambahdatauser');
		}

		$username = $this->input->post('username');
		$query = $this->db->query("SELECT * from tbl_user where username = '$username'");
		
		if ($query->num_rows() > 0){
			$this->session->set_flashdata('pesanerror3', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal ditambah. Username yang dimasukkan sudah ada!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	redirect('admin/menambahdatauser');
		}

		$password = $this->input->post('password');
		$konfirmasi_password = $this->input->post('konfirmasi_password');
		if ($password != $konfirmasi_password) {
			$this->session->set_flashdata('pesanerror4', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal ditambah. Password dan konfirmasi password harus sama!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	redirect('admin/menambahdatauser');
		}

	
		              	$data = array(
						'username' => $this->input->post('username'),
						'nama_user' => $this->input->post('nama_user'),
						'password' => $this->input->post('password'),
						'konfirmasi_password' => $this->input->post('konfirmasi_password'),
						'level' => $this->input->post('level'),
						'tanggal_terdaftar' => $this->input->post('tanggal_terdaftar'),
						);

					$this->model_manajemenuser->menambahdatauser($data);
					$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
													  Data Berhasil ditambah!
													  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													    <span aria-hidden="true">&times;</span>
													  </button>
													</div>');
					redirect('admin/manajemenuser','refresh');	    
	}

	public function updatedatauser($id_user = '')
	{ 
		if ($this->session->userdata('level') == "Admin") {
			$this->db->where('id_user', $id_user);
			$data['content'] = $this->db->get('tbl_user');
			$this->load->view('manajemenuser/user/update', $data);
		} elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else {
			$this->load->view('errors');	
		}
	}

	public function action_updatedatauser($id_user = '')
	{

	
		$password = $this->input->post('password');
		$konfirmasi_password = $this->input->post('konfirmasi_password');
		if ($password != $konfirmasi_password) {
			$this->session->set_flashdata('pesanerror4', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal diupdate. Password dan konfirmasi password harus sama!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
			$this->updatedatauser($id_user);
				  
		} else {

	
		              	$data = array(
						
						'nama_user' => $this->input->post('nama_user'),
						'password' => $this->input->post('password'),
						'konfirmasi_password' => $this->input->post('konfirmasi_password'),
						'level' => $this->input->post('level'),
						'tanggal_terdaftar' => $this->input->post('tanggal_terdaftar'),
						);
		            $this->db->where('id_user', $id_user);
					$this->model_manajemenuser->updatedatauser($data, $id_user);
					$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
													  Data Berhasil diupdate!
													  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													    <span aria-hidden="true">&times;</span>
													  </button>
													</div>');
					redirect('admin/manajemenuser','refresh');	   
					} 
	}

	public function action_deletedatauser($id_user = '')
	{
		if ($this->session->userdata('level') == "Admin") {
			$this->model_manajemenuser->deletedatauser($id_user);
			redirect('admin/manajemenuser','refresh');
		} elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else {
			$this->load->view('login/login');	
		}
	}



// Peralatan

	public function manajemenperalatandalamtower()
	{
		if ($this->session->userdata('level') == "Admin") {
			$data['content'] = $this->db->get('tbl_peralatan_dalam_tower');
			$this->load->view('manajemenperalatandalamtower/peralatandalamtower', $data);
		} elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else {
			$this->load->view('login/login');	
		}
	}

	public function menambahdataperalatandalamtower()
	{ 
		if ($this->session->userdata('level') == "Admin") {
			$this->load->view('manajemenperalatandalamtower/add');
		} elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else {
			$this->load->view('errors');	
		}
	}

	public function action_menambahdataperalatandalamtower()
	{
		$kode_alat = $this->input->post('kode_alat');
		$query = $this->db->query("SELECT * from tbl_peralatan_dalam_tower where kode_alat = '$kode_alat'");
		
		if ($query->num_rows() > 0){
			$this->session->set_flashdata('pesanerror3', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal ditambah. Kode Alat yang dimasukkan sudah ada!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	redirect('admin/menambahdataperalatandalamtower');
		}

		$namafile = date("d-m-y").("_").$kode_alat.("_").$_FILES['foto']['name']; //nama file + fungsi time
		$jenis_gambar = $_FILES['foto']['type'];
		$size_gambar = $_FILES['foto']['size'];
        $config['upload_path'] = './assets/img/fotoperalatandalamtower/'; //Folder untuk menyimpan hasil upload
        $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['file_name'] = $namafile; //nama yang terupload nantinya

        $this->upload->initialize($config);
        if(!empty($_FILES['foto']['name']))
        {
        	if($jenis_gambar !="image/jpeg" && $jenis_gambar !="image/jpg" && $jenis_gambar !="image/gif" && $jenis_gambar!="image/png")
				  {
				  	$this->session->set_flashdata('pesanerror', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal ditambah. Jenis gambar yang anda kirim salah. Harus berformat .jpg .gif .png!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	redirect('admin/menambahdataperalatandalamtower');
				  }else if($size_gambar > 3000000){

					$this->session->set_flashdata('pesanerror2', '<div class="alert alert-warning alert-dismissible fade show" 
													role="alert">
													  Data gagal ditambah. Upload foto maksimal 3MB!
													  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													    <span aria-hidden="true">&times;</span>
													  </button>
													</div>');
					redirect('admin/menambahdataperalatandalamtower');

				  } else {

				  		if($this->upload->do_upload('foto')){
           				$this->upload->data();

		                $config['image_library']='gd2';
		                $config['source_image']='./assets/img/fotoperalatandalamtower/'.$namafile;
		                $config['create_thumb']= FALSE;
		                $config['maintain_ratio']= FALSE;
		                $config['quality']= '80%';
		                $config['width']= 800;
		                $config['height']= 600;
		                $config['new_image']= './assets/img/fotoperalatandalamtower/'.$namafile;
		               
		                $this->load->library('image_lib', $config);   
		                $this->image_lib->resize();

		              	$data = array(
						'kode_alat' => $this->input->post('kode_alat'),
						'nama_alat' => $this->input->post('nama_alat'),
						'jumlah' => $this->input->post('jumlah'),
						'merek' => $this->input->post('merek'),
						'kondisi' => $this->input->post('kondisi'),
						'foto' => $namafile,
						'keterangan' => $this->input->post('keterangan')
						);

					$this->model_manajemenperalatandalamtower->menambahdataperalatandalamtower($data);
					$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
													  Data Berhasil ditambah!
													  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													    <span aria-hidden="true">&times;</span>
													  </button>
													</div>');
					redirect('admin/manajemenperalatandalamtower','refresh');	    
				}
			}
		}	
	}

	public function updatedataperalatandalamtower($id= '')
	{
		if ($this->session->userdata('level') == "Admin") {
			$this->db->where('id', $id);
			$data['content'] = $this->db->get('tbl_peralatan_dalam_tower');
			$this->load->view('manajemenperalatandalamtower/update', $data);
		} elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else {
			$this->load->view('errors');	
		}
	}

	public function action_updatedataperalatandalamtower($id = '')
	{
		$kode_alat = $this->input->post('kode_alat');
		$namafile = date("d-m-y").("_").$kode_alat.("_").$_FILES['foto']['name']; //nama file + fungsi time
		$jenis_gambar = $_FILES['foto']['type'];
		$size_gambar = $_FILES['foto']['size'];
        $config['upload_path'] = './assets/img/fotoperalatandalamtower/'; //Folder untuk menyimpan hasil upload
        $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['file_name'] = $namafile; //nama yang terupload nantinya


        $this->upload->initialize($config);
        if(!empty($_FILES['foto']['name']))
        {
        	if($jenis_gambar !="image/jpeg" && $jenis_gambar !="image/jpg" && $jenis_gambar !="image/gif" && $jenis_gambar!="image/png")
				  {
				  	$this->session->set_flashdata('pesanerror', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal diupdate. Jenis gambar yang anda kirim salah. Harus berformat .jpg .gif .png!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	$this->updatedataperalatandalamtower();
				  }else if($size_gambar > 3000000){

					$this->session->set_flashdata('pesanerror2', '<div class="alert alert-warning alert-dismissible fade show" 
													role="alert">
													  Data gagal diupdate. Upload foto maksimal 3MB!
													  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													    <span aria-hidden="true">&times;</span>
													  </button>
													</div>');
					$this->updatedataperalatandalamtower();

				  } else if($this->upload->do_upload('foto')){
           				$this->upload->data();
           				 $config['image_library']='gd2';
		                $config['source_image']='./assets/img/fotoperalatandalamtower/'.$namafile;
		                $config['create_thumb']= FALSE;
		                $config['maintain_ratio']= FALSE;
		                $config['quality']= '60%';
		                $config['width']= 800;
		                $config['height']= 600;
		                $config['new_image']= './assets/img/fotoperalatandalamtower/'.$namafile;
		               
		                $this->load->library('image_lib', $config);   
		                $this->image_lib->resize();

           				$data = array(
						'kode_alat' => $this->input->post('kode_alat'),
						'nama_alat' => $this->input->post('nama_alat'),
						'jumlah' => $this->input->post('jumlah'),
						'merek' => $this->input->post('merek'),
						'kondisi' => $this->input->post('kondisi'),
						'foto' => $namafile,
						'keterangan' => $this->input->post('keterangan')
						);

					$this->model_manajemenperalatandalamtower->updatedataperalatandalamtower($data, $id);
					$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
													  Data Berhasil diupdate!
													  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													    <span aria-hidden="true">&times;</span>
													  </button>
													</div>');
					redirect('admin/manajemenperalatandalamtower','refresh');	    

           			}
           		} else {

		                $fotolama = $this->input->post('fotolama');
						if ($_FILES['foto']['error'] === 4) {
								$foto = $fotolama;
							} else {
								$foto = $namafile;
							}
							$data = array(
						'kode_alat' => $this->input->post('kode_alat'),
						'nama_alat' => $this->input->post('nama_alat'),
						'jumlah' => $this->input->post('jumlah'),
						'merek' => $this->input->post('merek'),
						'kondisi' => $this->input->post('kondisi'),
						'foto' => $foto,
						'keterangan' => $this->input->post('keterangan')
						);

					$this->model_manajemenperalatandalamtower->updatedataperalatandalamtower($data, $id);
					$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
													  Data Berhasil diupdate!
													  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													    <span aria-hidden="true">&times;</span>
													  </button>
													</div>');
					redirect('admin/manajemenperalatandalamtower','refresh');	    
           		}

		              
		}	


	public function action_deletedataperalatandalamtower($id = '')
	{
		if ($this->session->userdata('level') == "Admin") {
			$this->model_manajemenperalatandalamtower->deletedataperalatandalamtower($id);
			redirect('admin/manajemenperalatandalamtower','refresh');
		} elseif ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else {
			$this->load->view('login/login');	
		}
	}

	public function ubahpassword($username = '')
	{

		if ($this->session->userdata('level') == "Admin") {
		$this->db->where('username', $username);
		$data['content'] = $this->db->get('tbl_user');
		$this->load->view('profil/admin/ubahpassword', $data);
		} else if ($this->session->userdata('level') == "User") {
			redirect('','refresh');
		} else {
			$this->load->view('errors');	
		}
	}

	public function action_ubahpassword($username = '')
	{
		$passwordbaru = $this->input->post('passwordbaru');
		$konfirmasi_password = $this->input->post('konfirmasi_password');
		$passwordlama = $this->input->post('passwordlama');
		$query = $this->db->query("SELECT * from tbl_user where password = '$passwordlama'");
		
		if ($query->num_rows() == 0){
			$this->session->set_flashdata('pesanerror3', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Password gagal diubah. Password lama anda salah!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	$this->ubahpassword($username);
		}

		else if ($passwordbaru != $konfirmasi_password) {
			$this->session->set_flashdata('pesanerror4', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Password gagal diubah. Password dan konfirmasi password harus sama!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  $this->ubahpassword($username);
		} else {

	
		              	$data = array(
						'password' => $this->input->post('passwordbaru'),
						'konfirmasi_password' => $this->input->post('konfirmasi_password'),
						);
		            $this->db->where('username', $username);
					$this->model_profil->ubahpassword($data, $username);
					$this->session->set_flashdata('pesanberhasilpassword', '<div class="alert alert-success alert-dismissible fade show" role="alert">
													  Password Anda berhasil Diubah!
													  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													    <span aria-hidden="true">&times;</span>
													  </button>
													</div>');
				redirect('admin','refresh');
		}
	}
}


/* End of file Admin.php */
/* Location: ./application/controllers/Admin.php */