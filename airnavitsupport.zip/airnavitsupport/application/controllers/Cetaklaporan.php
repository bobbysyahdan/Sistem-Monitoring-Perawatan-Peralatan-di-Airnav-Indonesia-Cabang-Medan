<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cetaklaporan extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        //Do your magic here
        
    }
	public function index()
	{
        if($this->session->userdata('level') == "User"){
            
           $this->load->view('laporan/cetaklaporan');
        } elseif($this->session->userdata('level') == "Admin"){
            redirect('admin','refresh');
        } else{
            redirect('login','refresh');
        }
	}

	public function cetaklaporanharian()
	{
         if($this->session->userdata('level') == "User"){
	 //load mpdf libray
    $this->load->library('Mpdf');

    $mpdf = $this->mpdf->load([
        'mode' => 'utf-8',
        'format' => 'A3-L'
    ]);
    
    $dinas = $this->input->post('dinas');
    $tanggal = $this->input->post('tanggal');
    $tanggal2 = date('d-m-y',strtotime($tanggal));
    $hari = date('D',strtotime($tanggal));

    switch($hari){
        case 'Sun':
            $hari_ini = "Minggu";
        break;
 
        case 'Mon':         
            $hari_ini = "Senin";
        break;
 
        case 'Tue':
            $hari_ini = "Selasa";
        break;
 
        case 'Wed':
            $hari_ini = "Rabu";
        break;
 
        case 'Thu':
            $hari_ini = "Kamis";
        break;
 
        case 'Fri':
            $hari_ini = "Jumat";
        break;
 
        case 'Sat':
            $hari_ini = "Sabtu";
        break;
        
        default:
            $hari_ini = "Tidak di ketahui";     
        break;
    }
    $tanggalhari = $hari_ini.("/").$tanggal2;

    $paneldistp = $this->db->query("SELECT * FROM tbl_paneldis WHERE kode_alat = 'PANELDISTP' AND tanggal = '$tanggal' AND dinas = '$dinas'");
    $paneldisp1 = $this->db->query("SELECT * FROM tbl_paneldis WHERE kode_alat = 'PANELDISP1' AND tanggal = '$tanggal' AND dinas = '$dinas'");
    $paneldisp2 = $this->db->query("SELECT * FROM tbl_paneldis WHERE kode_alat = 'PANELDISP2' AND tanggal = '$tanggal' AND dinas = '$dinas'");
     $ups1 = $this->db->query("SELECT * FROM tbl_ups WHERE kode_alat = 'UPS1' AND tanggal = '$tanggal' AND dinas = '$dinas'");
     $ups2 = $this->db->query("SELECT * FROM tbl_ups WHERE kode_alat = 'UPS2' AND tanggal = '$tanggal' AND dinas = '$dinas'");
     $bangunanac = $this->db->query("SELECT * FROM tbl_bangunan_dan_ac WHERE kode_alat = 'BANGUNANAC' AND tanggal = '$tanggal' AND dinas = '$dinas'");
     $ehfan = $this->db->query("SELECT * FROM tbl_exhaust_fan WHERE kode_alat = 'EHFAN01' AND tanggal = '$tanggal' AND dinas = '$dinas'");
     $cctv = $this->db->query("SELECT * FROM tbl_cctv WHERE kode_alat = 'CCTV01' AND tanggal = '$tanggal' AND dinas = '$dinas'");
     $nik = $this->db->query("SELECT * FROM tbl_detail_pengecekan WHERE tanggal = '$tanggal' AND dinas = '$dinas'");
     $nikuser = $this->db->query("SELECT username_pemeriksa FROM tbl_detail_pengecekan WHERE tanggal = '$tanggal' AND dinas = '$dinas'");
      $nikuser = $this->db->query("SELECT username_pemeriksa FROM tbl_detail_pengecekan WHERE tanggal = '$tanggal' AND dinas = '$dinas'");


    $html = '<!DOCTYPE html>
            <html>
            <head>
              <title>Cetak Dokumen</title>
              <style>
                  .p{
                    font-size: 10pt;
                  }

                  .o{
                    font-size: 10pt;
                    text-align:left;
                  }
                  .judul{
                    font-size: 11pt;
                    text-align:center;
                    font-style: bold;
                  }
                  .judulfield{
                    background-color: #ddd;
                  }
                  td{
                    text-align:center;
                    font-size: 8pt;
                  }

                  .catatan {
                    text-align:left;
                    border:0;
                  }
    
              </style>
            </head>
            <body>
     
                <p class="p">PERUM LPPNPI</p>
                <p class="p">AIRNAV INDONESIA CABANG MADYA MEDAN - DELI SERDANG</p>
                <p class="p">ENGINEERING SUPPORT SYSTEM</p>

                <p class="judul"><b>CHECKLIST HARIAN FASILITAS LISTRIK, MEKANIKAL DAN BANGUNAN</b></p>
                <table>
                <tr>
                <td class="o">Lokasi</td>
                <td class="o">:</td>
                <td class="o">Tower</td>
                </tr>

                <tr>
                <td class="o">Tanggal</td>
                <td class="o">:</td>
                <td class="o">'.$tanggalhari.'</td>
                </tr>
                <tr>
                <td class="o">Dinas</td>
                <td class="o">:</td>
                <td class="o">'.$dinas.'</td>
                </tr>
                </table>
                <br></br>

                 <table border="1" cellpadding="10" cellspacing="0">
                   <tr>
                    <td rowspan="2">Parameter</td>
                    <th colspan="9" class="judulfield">LVDP/PANEL DISTRIBUSI/PANEL ACOS</th>
                    <td rowspan="2">Parameter</td>
                    <th colspan="14" class="judulfield">UNINTERRUPTABLE POWER SUPPLY (UPS)</th>
                </tr>
                <tr>
                  <th  colspan="3">TEKNIKAL PRIORITY</th>
                  <th colspan="3">PRIORITY 1</th>
                  <th colspan="3">PRIORITY 2</th>
                  <th colspan="2">UPS 1</th>
                  <th colspan="2">UPS 2</th>
                  <th colspan="1"></th>
                  <th colspan="2">UPS 1</th>
                  <th colspan="2">UPS 2</th>
                  <th colspan="2"></th>
                  <th colspan="1">UPS 1</th>
                  <th colspan="1">UPS 2</th>
                  <th colspan="1"></th>

                    
                </tr>
                <tr>
                ////////////
                    <td rowspan="4">Tegangan</td>

                 ';

                 foreach ($paneldistp->result() as $paneldistpdata) :
                 
                 $html .= '   
                    <td>R/R-S</td>
                    <td>'.$paneldistpdata->tegangan_r.'/'.$paneldistpdata->tegangan_r_s.'</td>
                    <td>V</td>

                ';

                    endforeach;
                    /////


                    foreach ($paneldisp1->result() as $paneldisp1data) :
                 
                 $html .= '   
                    <td>R/R-S</td>
                    <td>'.$paneldisp1data->tegangan_r.'/'.$paneldisp1data->tegangan_r_s.'</td>
                    <td>V</td>

                ';
                    endforeach;
                    /////


                    foreach ($paneldisp2->result() as $paneldisp2data) :
                 $html .= '   
                    <td>R/R-S</td>
                    <td>'.$paneldisp2data->tegangan_r.'/'.$paneldisp2data->tegangan_r_s.'</td>
                    <td>V</td>
                ';
                    endforeach;
                    ///


                 $html .= '  
                    // UPS vmain
                    <td rowspan="4">V Main</td>
                    <td>R</td>
                     ';

                 foreach ($ups1->result() as $ups1data) :
                 
                 $html .= '   
                    <td>'.$ups1data->v_main_r.'</td>
                ';

                    endforeach;
                    /////


                   foreach ($ups2->result() as $ups2data) :
                 
                 $html .= '   
                   <td>'.$ups2data->v_main_r.'</td>
                    <td>V</td>

                ';
                    endforeach;
                    /////

                 $html .= '  

                    // Arus Main
                     <td rowspan="4">ARUS Main</td>
                     <td>R</td>
                     ';

                 foreach ($ups1->result() as $ups1data) :
                 
                 $html .= '   
                    <td>'.$ups1data->arus_main_r.'</td>
                ';

                    endforeach;
                    /////


                   foreach ($ups2->result() as $ups2data) :
                 
                 $html .= '   
                   <td>'.$ups2data->arus_main_r.'</td>
                    <td>A</td>

                ';
                    endforeach;
                    /////

                 $html .= '  

                      // UPS LD
                     <td rowspan="4" colspan="2">UPS LD</td>
                     ';

                 foreach ($ups1->result() as $ups1data) :
                 
                 $html .= '   
                    <td>'.$ups1data->ups_ld_kva.'</td>
                ';

                    endforeach;
                    /////


                   foreach ($ups2->result() as $ups2data) :
                 
                 $html .= '   
                   <td>'.$ups2data->ups_ld_kva.'</td>
                    <td>KVA</td>

                ';
                    endforeach;
                    /////

                 $html .= '  
                </tr>
                <tr>

                //////////
                // Tegangan
                <tr>
                    ';

                     foreach ($paneldistp->result() as $paneldistpdata) :
                 $html .= '   
                    <td>S/R-T</td>
                    <td>'.$paneldistpdata->tegangan_s.'/'.$paneldistpdata->tegangan_r_t.'</td>
                    <td>V</td>
                ';
                    endforeach;
                    ///
                      foreach ($paneldisp1->result() as $paneldisp1data) :
                 $html .= '   
                    <td>S/R-T</td>
                    <td>'.$paneldisp1data->tegangan_s.'/'.$paneldisp1data->tegangan_r_t.'</td>
                    <td>V</td>
                ';
                    endforeach;
                    ///
                     foreach ($paneldisp2->result() as $paneldisp2data) :
                 $html .= '   
                    <td>S/R-T</td>
                    <td>'.$paneldisp2data->tegangan_s.'/'.$paneldisp2data->tegangan_r_t.'</td>
                    <td>V</td>
                ';
                    endforeach;
                    ///
                     $html .= '  

                    // UPS vmain 1
                    <td>S</td>
                    ';

                 foreach ($ups1->result() as $ups1data) :
                 
                 $html .= '   
                    <td>'.$ups1data->v_main_s.'</td>
                ';

                    endforeach;
                    /////


                   foreach ($ups2->result() as $ups2data) :
                 
                 $html .= '   
                   <td>'.$ups2data->v_main_s.'</td>
                    <td>V</td>

                ';
                    endforeach;
                    /////

                 $html .= '  

                    // Arus Main
                    <td>S</td>
                    ';

                 foreach ($ups1->result() as $ups1data) :
                 
                 $html .= '   
                    <td>'.$ups1data->arus_main_s.'</td>
                ';

                    endforeach;
                    /////


                   foreach ($ups2->result() as $ups2data) :
                 
                 $html .= '   
                   <td>'.$ups2data->arus_main_s.'</td>
                    <td>A</td>

                ';
                    endforeach;
                    /////

                 $html .= '  

                     // UPS LD
                     ';

                 foreach ($ups1->result() as $ups1data) :
                 
                 $html .= '   
                    <td>'.$ups1data->ups_ld_kw.'</td>
                ';

                    endforeach;
                    /////


                   foreach ($ups2->result() as $ups2data) :
                 
                 $html .= '   
                   <td>'.$ups2data->ups_ld_kw.'</td>
                    <td>KW</td>

                ';
                    endforeach;
                    /////

                 $html .= '  
                </tr>
                //////////////////
                // Tegangan
                <tr>
                     ';

                     foreach ($paneldistp->result() as $paneldistpdata) :
                 $html .= '   
                    <td>T/T-S</td>
                    <td>'.$paneldistpdata->tegangan_t.'/'.$paneldistpdata->tegangan_t_s.'</td>
                    <td>V</td>
                ';
                    endforeach;
                    ///
                      foreach ($paneldisp1->result() as $paneldisp1data) :
                 $html .= '   
                    <td>T/T-S</td>
                    <td>'.$paneldisp1data->tegangan_t.'/'.$paneldisp1data->tegangan_t_s.'</td>
                    <td>V</td>
                ';
                    endforeach;
                    ///
                     foreach ($paneldisp2->result() as $paneldisp2data) :
                 $html .= '   
                    <td>T/T-S</td>
                    <td>'.$paneldisp2data->tegangan_t.'/'.$paneldisp2data->tegangan_t_s.'</td>
                    <td>V</td>
                ';
                    endforeach;
                    ///
                     $html .= '  
                    // UPS vmain 1
                    <td>T</td>
                    ';

                 foreach ($ups1->result() as $ups1data) :
                 
                 $html .= '   
                    <td>'.$ups1data->v_main_t.'</td>
                ';

                    endforeach;
                    /////


                   foreach ($ups2->result() as $ups2data) :
                 
                 $html .= '   
                   <td>'.$ups2data->v_main_t.'</td>
                    <td>V</td>

                ';
                    endforeach;
                    /////

                 $html .= '  

                     // Arus Main
                    <td>T</td>
                    ';

                 foreach ($ups1->result() as $ups1data) :
                 
                 $html .= '   
                    <td>'.$ups1data->arus_main_t.'</td>
                ';

                    endforeach;
                    /////


                   foreach ($ups2->result() as $ups2data) :
                 
                 $html .= '   
                   <td>'.$ups2data->arus_main_t.'</td>
                    <td>A</td>

                ';
                    endforeach;
                    /////

                 $html .= '  

                    // UPS LD
                     ';

                 foreach ($ups1->result() as $ups1data) :
                 
                 $html .= '   
                    <td>'.$ups1data->ups_ld_pf.'</td>
                ';

                    endforeach;
                    /////


                   foreach ($ups2->result() as $ups2data) :
                 
                 $html .= '   
                   <td>'.$ups2data->ups_ld_pf.'</td>
                    <td>PF</td>

                ';
                    endforeach;
                    /////

                 $html .= '  
                </tr>

// ////////////////////////////////////////////////////////////////////
                <tr>
                 <td rowspan="3">ARUS</td>
                 ';

                     foreach ($paneldistp->result() as $paneldistpdata) :
                 $html .= '   
                    <td>R</td>
                    <td>'.$paneldistpdata->arus_r.'</td>
                    <td>A</td>
                ';
                    endforeach;
                    ///
                      foreach ($paneldisp1->result() as $paneldisp1data) :
                 $html .= '   
                    <td>R</td>
                    <td>'.$paneldisp1data->arus_r.'</td>
                    <td>A</td>
                ';
                    endforeach;
                    ///
                     foreach ($paneldisp2->result() as $paneldisp2data) :
                 $html .= '   
                    <td>R</td>
                    <td>'.$paneldisp2data->arus_r.'</td>
                    <td>A</td>
                ';
                    endforeach;
                    ///
                     $html .= ' 

                 // Voutput

                 <td rowspan="3">V Output</td>
                 <td>R</td>
                 ';

                 foreach ($ups1->result() as $ups1data) :
                 
                 $html .= '   
                    <td>'.$ups1data->v_output_r.'</td>
                ';

                    endforeach;
                    /////


                   foreach ($ups2->result() as $ups2data) :
                 
                 $html .= '   
                   <td>'.$ups2data->v_output_r.'</td>
                    <td>A</td>

                ';
                    endforeach;
                    /////

                 $html .= '  


                 // Arus output
                 
                 <td rowspan="3">ARUS Output</td>
                 <td>R</td>
                 ';

                 foreach ($ups1->result() as $ups1data) :
                 
                 $html .= '   
                    <td>'.$ups1data->arus_output_r.'</td>
                ';

                    endforeach;
                    /////


                   foreach ($ups2->result() as $ups2data) :
                 
                 $html .= '   
                   <td>'.$ups2data->arus_output_r.'</td>
                    <td>A</td>

                ';
                    endforeach;
                    /////

                 $html .= '  

                 // TOTAL LD
                  <td rowspan="3" colspan="2">TOTAL LD</td>
                 ';

                 foreach ($ups1->result() as $ups1data) :
                 
                 $html .= '   
                    <td>'.$ups1data->total_ld_kva.'</td>
                ';

                    endforeach;
                    /////


                   foreach ($ups2->result() as $ups2data) :
                 
                 $html .= '   
                   <td>'.$ups2data->total_ld_kva.'</td>
                    <td>KVA</td>

                ';
                    endforeach;
                    /////

                 $html .= '  

                </tr>
               

                
                ///////////
                 // ARUS
                <tr>
                ';

                     foreach ($paneldistp->result() as $paneldistpdata) :
                 $html .= '   
                    <td>S</td>
                    <td>'.$paneldistpdata->arus_s.'</td>
                    <td>A</td>
                ';
                    endforeach;
                    ///
                      foreach ($paneldisp1->result() as $paneldisp1data) :
                 $html .= '   
                    <td>S</td>
                    <td>'.$paneldisp1data->arus_s.'</td>
                    <td>A</td>
                ';
                    endforeach;
                    ///
                     foreach ($paneldisp2->result() as $paneldisp2data) :
                 $html .= '   
                    <td>S</td>
                    <td>'.$paneldisp2data->arus_s.'</td>
                    <td>A</td>
                ';
                    endforeach;
                    ///
                     $html .= ' 


                 // Voutput

                 <td>S</td>
                 ';

                 foreach ($ups1->result() as $ups1data) :
                 
                 $html .= '   
                    <td>'.$ups1data->v_output_s.'</td>
                ';

                    endforeach;
                    /////


                   foreach ($ups2->result() as $ups2data) :
                 
                 $html .= '   
                   <td>'.$ups2data->v_output_s.'</td>
                    <td>A</td>

                ';
                    endforeach;
                    /////

                 $html .= '  


                  // Arus output
                 
                 <td>S</td>
                  ';

                 foreach ($ups1->result() as $ups1data) :
                 
                 $html .= '   
                    <td>'.$ups1data->arus_output_s.'</td>
                ';

                    endforeach;
                    /////


                   foreach ($ups2->result() as $ups2data) :
                 
                 $html .= '   
                   <td>'.$ups2data->arus_output_s.'</td>
                    <td>A</td>

                ';
                    endforeach;
                    /////

                 $html .= '  

                 // TOTAL LD
                 ';

                 foreach ($ups1->result() as $ups1data) :
                 
                 $html .= '   
                    <td>'.$ups1data->total_ld_kw.'</td>
                ';

                    endforeach;
                    /////


                   foreach ($ups2->result() as $ups2data) :
                 
                 $html .= '   
                   <td>'.$ups2data->total_ld_kw.'</td>
                    <td>KW</td>

                ';
                    endforeach;
                    /////

                 $html .= '  


                 ///////////
                 // ARUS
                 <tr>
                 ';

                     foreach ($paneldistp->result() as $paneldistpdata) :
                 $html .= '   
                    <td>T</td>
                    <td>'.$paneldistpdata->arus_t.'</td>
                    <td>A</td>
                ';
                    endforeach;
                    ///
                      foreach ($paneldisp1->result() as $paneldisp1data) :
                 $html .= '   
                    <td>T</td>
                    <td>'.$paneldisp1data->arus_t.'</td>
                    <td>A</td>
                ';
                    endforeach;
                    ///
                     foreach ($paneldisp2->result() as $paneldisp2data) :
                 $html .= '   
                    <td>T</td>
                    <td>'.$paneldisp2data->arus_t.'</td>
                    <td>A</td>
                ';
                    endforeach;
                    ///
                     $html .= ' 


                 // Voutput

                 <td>T</td>
                 ';

                 foreach ($ups1->result() as $ups1data) :
                 
                 $html .= '   
                    <td>'.$ups1data->v_output_t.'</td>
                ';

                    endforeach;
                    /////


                   foreach ($ups2->result() as $ups2data) :
                 
                 $html .= '   
                   <td>'.$ups2data->v_output_t.'</td>
                    <td>A</td>

                ';
                    endforeach;
                    /////

                 $html .= '  

                  // Arus output
                 
                 <td>T</td>
                 ';

                 foreach ($ups1->result() as $ups1data) :
                 
                 $html .= '   
                    <td>'.$ups1data->arus_output_t.'</td>
                ';

                    endforeach;
                    /////


                   foreach ($ups2->result() as $ups2data) :
                 
                 $html .= '   
                   <td>'.$ups2data->arus_output_t.'</td>
                    <td>A</td>

                ';
                    endforeach;
                    /////

                 $html .= '  

                 // TOTAL LD
                 ';

                 foreach ($ups1->result() as $ups1data) :
                 
                 $html .= '   
                    <td>'.$ups1data->total_ld_pf.'</td>
                ';

                    endforeach;
                    /////


                   foreach ($ups2->result() as $ups2data) :
                 
                 $html .= '   
                   <td>'.$ups2data->total_ld_pf.'</td>
                    <td>PF</td>

                ';
                    endforeach;
                    /////

                 $html .= '  
                 
                 </tr>


///////////////////////////////////////////
                 <tr>
                 // Frekuensi
                    <td>Frekuensi</td>
                    ';

                     foreach ($paneldistp->result() as $paneldistpdata) :
                 $html .= '   
                     <td>(Hz)</td>
                    <td>'.$paneldistpdata->frekuensi.'</td>
                    <td>Hz</td>
                ';
                    endforeach;
                    ///
                      foreach ($paneldisp1->result() as $paneldisp1data) :
                 $html .= '   
                     <td>(Hz)</td>
                    <td>'.$paneldisp1data->frekuensi.'</td>
                    <td>Hz</td>
                ';
                    endforeach;
                    ///
                     foreach ($paneldisp2->result() as $paneldisp2data) :
                 $html .= '   
                     <td>(Hz)</td>
                    <td>'.$paneldisp2data->frekuensi.'</td>
                    <td>Hz</td>
                ';
                    endforeach;
                    ///
                     $html .= ' 
                    // Operasional
                    <td>Operasional</td>    
                     ';

                 foreach ($ups1->result() as $ups1data) :
                 
                 $html .= '   
                    <td colspan="9">'.$ups1data->operasional.'</td>
                ';

                    endforeach;
                    /////
                 $html .= ' 

                    //DC Volt
                    <td rowspan="2" colspan="2">DC Volt</td>    
                    ';

                 foreach ($ups1->result() as $ups1data) :
                 
                 $html .= '   
                    <td>'.$ups1data->dc_volt_v.'</td>
                ';

                    endforeach;
                    /////


                   foreach ($ups2->result() as $ups2data) :
                 
                 $html .= '   
                   <td>'.$ups2data->dc_volt_v.'</td>
                    <td>V</td>

                ';
                    endforeach;
                    /////

                 $html .= '  
                 </tr>



////////////////////////////////////////////////
                 <tr>
                 // Mode Operasi
                    <td>Mode Operasi</td>
                    ';

                     foreach ($paneldistp->result() as $paneldistpdata) :
                 $html .= '   
                    <td colspan="3">'.$paneldistpdata->mode_operasi.'</td>
                   
                ';
                    endforeach;
                    ///
                      foreach ($paneldisp1->result() as $paneldisp1data) :
                 $html .= '   
                    <td colspan="3">'.$paneldisp1data->mode_operasi.'</td>
                    
                ';
                    endforeach;
                    ///
                     foreach ($paneldisp2->result() as $paneldisp2data) :
                 $html .= '   
                    <td colspan="3">'.$paneldisp2data->mode_operasi.'</td>
                   
                ';
                    endforeach;
                    ///
                     $html .= ' 

                // Kebersihan UPS
                     <td>Kebersihan UPS</td>    
                    ';

                 foreach ($ups1->result() as $ups1data) :
                 
                 $html .= '   
                    <td colspan="9">'.$ups1data->kebersihan_ups.'</td>
                ';

                    endforeach;
                    /////
                 $html .= ' 

                // DC Volt
                    ';

                 foreach ($ups1->result() as $ups1data) :
                 
                 $html .= '   
                    <td>'.$ups1data->dc_volt_a.'</td>
                ';

                    endforeach;
                    /////


                   foreach ($ups2->result() as $ups2data) :
                 
                 $html .= '   
                   <td>'.$ups2data->dc_volt_a.'</td>
                    <td>A</td>

                ';
                    endforeach;
                    /////

                 $html .= '     

                 </tr>


/////////////////////////////////////////////////
                 <tr>
                 // Kebersihan Panel
                    <td rowspan="2">Kebersihan Panel</td>
                     ';

                     foreach ($paneldistp->result() as $paneldistpdata) :
                 $html .= '   
                    <td colspan="3" rowspan="2">'.$paneldistpdata->kebersihan_panel.'</td>
                   
                ';
                    endforeach;
                    ///
                      foreach ($paneldisp1->result() as $paneldisp1data) :
                 $html .= '   
                    <td colspan="3" rowspan="2">'.$paneldisp1data->kebersihan_panel.'</td>
                    
                ';
                    endforeach;
                    ///
                     foreach ($paneldisp2->result() as $paneldisp2data) :
                 $html .= '   
                    <td colspan="3" rowspan="2">'.$paneldisp2data->kebersihan_panel.'</td>
                   
                ';
                    endforeach;
                    ///
                     $html .= ' 

                // Ukuran tegangan breker baterai(V)
                     <td rowspan="2">Ukuran tegangan breker baterai</td>
                     <td>Input</td>
                     ';

                 foreach ($ups1->result() as $ups1data) :
                 
                 $html .= '   
                    <td>'.$ups1data->ukuran_tegangan_in_breaker_baterai.'</td>
                ';

                    endforeach;
                    /////


                   foreach ($ups2->result() as $ups2data) :
                 
                 $html .= '   
                   <td>'.$ups2data->ukuran_tegangan_in_breaker_baterai.'</td>
                    <td>V</td>

                ';
                    endforeach;
                    /////

                 $html .= '  

                // Suhu ruangan 
                     <td rowspan="2">Suhu Ruangan</td>

                       ';

                 foreach ($ups1->result() as $ups1data) :
                 
                 $html .= '  
                   
                     <td colspan="3" rowspan="2">'.$ups1data->suhu_ruangan.'</td>
                       <td rowspan="2">C</td>
                                
                                ';
                    endforeach;
                    /////

                 $html .= '  
                // Status
                     <td rowspan="2" colspan="2">Status</td>
                        ';

                 foreach ($ups2->result() as $ups2data) :
                 
                 $html .= '  
                     <td colspan="3" rowspan="2">'.$ups2data->status.'</td>
                                
                                ';
                    endforeach;
                    /////

                 $html .= '  
     
                </tr>

                // Ukuran tegangan breker baterai(V)
                 <tr>
                    <td>Output</td>
                    ';

                 foreach ($ups1->result() as $ups1data) :
                 
                 $html .= '   
                    <td>'.$ups1data->ukuran_tegangan_out_breaker_baterai.'</td>
                ';

                    endforeach;
                    /////


                   foreach ($ups2->result() as $ups2data) :
                 
                 $html .= '   
                   <td>'.$ups2data->ukuran_tegangan_out_breaker_baterai.'</td>
                    <td>V</td>

                ';
                    endforeach;
                    /////

                 $html .= '  
                 </tr>


////////////////////////////////////////////////
                 <tr>
                    <td></td>
                    <th colspan="3" class="judulfield">BANGUNAN DAN AC</th>
                    <th colspan="3" class="judulfield">EXHAUST FAN</th>
                    <th colspan="3" class="judulfield">CCTV</th>
                    <td colspan="10" class="catatan"><p>Catatan :</p></td>
                    <td colspan="5" class="judulfield">Teknisi</td>
                 </tr>


/////////////////////////////////////////////////////////////
                 <tr>
                // BANGUNAN dan ac
                 // Kebersihan ruangan

                     <td>Kebersihan Ruangan</td>
                      ';

                 foreach ($bangunanac->result() as $bangunanacdata) :
                 
                 $html .= '  
                   
                     <td colspan="3">'.$bangunanacdata->kebersihan_ruangan.'</td>
                                
                                ';
                    endforeach;
                    /////

                 $html .= '  




                // EXHAUST FAN
                // status

                     <td rowspan="3">Status</td>
                      ';

                 foreach ($ehfan->result() as $ehfandata) :
                 
                 $html .= '  
                   
                     <td colspan="2" rowspan="3">'.$ehfandata->status.'</td>
                                
                                ';
                    endforeach;
                    /////

                 $html .= '  

                 </tr>


                 // CCTV
                // Kebersihan ruangan Kontrol

                     <td rowspan="2">Kebersihan ruangan Kontrol</td>
                    ';

                 foreach ($cctv->result() as $cctvdata) :
                 
                 $html .= '  
                   
                     <td colspan="2" rowspan="2">'.$cctvdata->kebersihan_ruangan_kontrol.'</td>
                                ';
                    endforeach;
                    /////

                 $html .= ' 


                     // catatan
                    

                      ';

                     foreach ($nik->result() as $nikdata) :
                 $html .= '   
        
                    <td colspan="10" rowspan="5"><p>PANELDISTP : '.$nikdata->paneldistp.' | PANELDISP1 : '.$nikdata->paneldisp1.'</p><p>PANELDISP2 : '.$nikdata->paneldisp2.' | UPS1 : '.$nikdata->ups1.' | UPS2 : '.$nikdata->ups2.' | BANGUNAN DAN AC : '.$nikdata->bangunac.' | EXHAUST FAN : '.$nikdata->ehfan01.'  | CCTV : '.$nikdata->cctv01.' | catatan : '.$nikdata->catatan.'</td>
                ';
                    endforeach;
                    ///
                     
                 $html .= ' 


                     // Teknisi
                     <td colspan="2" rowspan="2">NIK</td>
                    ';

                     foreach ($nik->result() as $nikdata) :
                 $html .= '   
        
                    <td colspan="3" rowspan="2">'.$nikdata->username_pemeriksa.'</td>
                ';
                    endforeach;
                    ///
                     
                 $html .= ' 

                 </tr>

                 </tr>
 /////////////////////////////////////////////////////////////
                 <tr>
                // BANGUNAN dan ac
                 // kondisi BANGUNAN

                     <td>kondisi Bangunan</td>
                      ';

                 foreach ($bangunanac->result() as $bangunanacdata) :
                 
                 $html .= '  
                   
                     <td colspan="3">'.$bangunanacdata->kondisi_bangunan.'</td>
                                
                                ';
                    endforeach;
                    /////

                 $html .= '  

                 </tr>

/////////////////////////////////////////////////////////////
                 <tr>
                // BANGUNAN dan ac
                 // suhu ruangan

                     <td>Suhu Ruangan</td>
                      ';

                 foreach ($bangunanac->result() as $bangunanacdata) :
                 
                 $html .= '  
                   
                     <td colspan="2">'.$bangunanacdata->suhu_ruangan.'</td>
                                <td colspan="1">C</td>
                                ';
                    endforeach;
                    /////

                 $html .= '  
                     

                 // CCTV
                // suhu ruangan kontrol

                     <td>Suhu Ruangan Kontrol</td>
                     ';

                 foreach ($cctv->result() as $cctvdata) :
                 
                 $html .= '  
                   
                     <td >'.$cctvdata->suhu_ruangan_kontrol.'</td>
                     <td>C</td>
                                ';
                    endforeach;
                    /////

                 $html .= ' 


                      // Teknisi
                     <td colspan="2" rowspan="2">Nama</td>
                    <td colspan="3" rowspan="2"></td>
                 </tr>

/////////////////////////////////////////////////////////////
                 <tr>
                // BANGUNAN dan ac
                 // Periksa Aliran Udara Evapurator

                     <td>Periksa Aliran Udara Evapurator</td>
                      ';

                 foreach ($bangunanac->result() as $bangunanacdata) :
                 
                 $html .= '  
                   
                     <td colspan="3">'.$bangunanacdata->periksa_aliran_udara_evapurator.'</td>
                                ';
                    endforeach;
                    /////

                 $html .= '  
                     

                // EXHAUST FAN
                // status

                     <td rowspan="2">Kondisi</td>
                       ';

                 foreach ($ehfan->result() as $ehfandata) :
                 
                 $html .= '  
                   
                     <td colspan="2" rowspan="2">'.$ehfandata->kondisi.'</td>
                                
                                ';
                    endforeach;
                    /////

                 $html .= '  
                     

                // CCTV
                 // Kebersihan luar ruangan Kontrol   
                     <td rowspan="2">Kebersihan luar ruangan Kontrol</td>
                     ';

                 foreach ($cctv->result() as $cctvdata) :
                 
                 $html .= '  
                   
                     <td colspan="2" rowspan="2">'.$cctvdata->kebersihan_bagian_luar_ruangan_kontrol.'</td>
                                ';
                    endforeach;
                    /////

                 $html .= '  

                 </tr>

/////////////////////////////////////////////////////////////
                 <tr>
                // BANGUNAN dan ac
                 // Pastikan Unit Outdoor/Kompresor Bekerja

                     <td>Pastikan Unit Outdoor/Kompresor Bekerja</td>
                      ';

                 foreach ($bangunanac->result() as $bangunanacdata) :
                 
                 $html .= '  
                   
                     <td colspan="3">'.$bangunanacdata->pastikan_unit_outdoor_kompresor_bekerja.'</td>
                                ';
                    endforeach;
                    /////

                 $html .= '  

                      // Teknisi
                     <td colspan="2">TTD</td>
                     <td colspan="3"></td>
                </tr>
              </thead>
            </table>
            <div class="mengetahui" >
                <p style="text-align:center;font-size:10px;">Mengetahui,</p>
                <p style="text-align:center;font-size:10px;">JR. MANAGER TEKNIK FASILITAS MENUNJANG</p>
            </div>
            
        </body>
    </html>';


     $mpdf->WriteHTML($html);

     $mpdf->Output();
      } elseif($this->session->userdata('level') == "Admin"){
            redirect('admin','refresh');
        } else{
            redirect('login','refresh');
        }
    }


    public function cetaklaporanbulanan()
    {
    if($this->session->userdata('level') == "User"){
     //load mpdf libray
    $this->load->library('Mpdf');

    $mpdf = $this->mpdf->load([
        'mode' => 'utf-8',
        'format' => 'A3-L'
    ]);



    $lokasi = "Tower";
    $bulan = $this->input->post('bulan');
    $tahun = $this->input->post('tahun');
    $querypaneldis = $this->db->query("SELECT * FROM tbl_paneldis WHERE  month(tanggal) ='$bulan' AND year(tanggal)='$tahun'");
    $queryups= $this->db->query("SELECT * FROM tbl_ups WHERE  month(tanggal) ='$bulan' AND year(tanggal)='$tahun'");
    $querybangunanac = $this->db->query("SELECT * FROM tbl_bangunan_dan_ac WHERE  month(tanggal) ='$bulan' AND year(tanggal)='$tahun'");
    $queryehfan = $this->db->query("SELECT * FROM tbl_exhaust_fan WHERE  month(tanggal) ='$bulan' AND year(tanggal)='$tahun'");
    $querycctv = $this->db->query("SELECT * FROM tbl_cctv WHERE  month(tanggal) ='$bulan' AND year(tanggal)='$tahun'");

    $kode_alat = $this->input->post('kode_alat');


    switch($bulan){
        case '01':
            $bulann = "Januari";
        break;
        case '02':
            $bulann = "Februari";
        break;
        case '03':
            $bulann = "Maret";
        break;
        case '04':
            $bulann = "April";
        break;
        case '05':
            $bulann = "Mei";
        break;
        case '06':
            $bulann = "Juni";
        break;
        case '07':
            $bulann = "Juli";
        break;
        case '08':
            $bulann = "Agustus";
        break;
        case '09':
            $bulann = "September";
        break;
 
        case '10':         
            $bulann = "Oktober";
        break;
 
        case '11':
            $bulann = "November";
        break;
 
        case '12':
            $bulann = "Desember";
        break;
 
       
        default:
            $bulann = "Tidak di ketahui";     
        break;
    }
    $nama_bulan = $bulann;
    $paneldis = '<!DOCTYPE html>
            <html>
            <head>
            <style>
                  .p{
                    font-size: 10pt;
                  }

                  .o{
                    font-size: 10pt;
                    text-align:left;
                  }
                  .judul{
                    font-size: 11pt;
                    text-align:center;
                    font-style: bold;
                  }
                  .judulfield{
                    background-color: #ddd;
                  }
                  td{
                    text-align:center;
                    font-size: 8pt;
                  }

                  .catatan {
                    text-align:left;
                    border:0;
                  }
              </style>
            </head>
            <body>

                <p class="p">PERUM LPPNPI</p>
                <p class="p">AIRNAV INDONESIA CABANG MADYA MEDAN - DELI SERDANG</p>
                <p class="p">ENGINEERING SUPPORT SYSTEM</p>

                <p class="judul"><b>CHECKLIST BULANAN PERAWATAN PANEL DISTRIBUSI</b></p>
                <table>
                <tr>
                <td class="o">Lokasi</td>
                <td class="o">:</td>
                <td class="o">Tower</td>
                </tr>
                <tr>
                <td class="o">Bulan</td>
                <td class="o">:</td>
                <td class="o">'.$nama_bulan.' '.$tahun.'</td>
                <td class="o"></td>
                </tr>
                
                </table>
                <br>
                <table border="1" cellpadding="10" cellspacing="0" align="center">
                    <tr>
                    <th rowspan="2">No</th>
                    <th rowspan="2">Kode Alat</th>
                    <th rowspan="2">Tanggal</th>
                    <th rowspan="2">Dinas</th>
                    <th colspan="6">Tegangan (Volt)</th>
                    <th colspan="3">Arus (Ampere)</th>
                    <th rowspan="2">Frekuensi</th>
                    <th rowspan="2">Mode Operasi</th>
                    <th rowspan="2">Kebersihan Panel</th>
                    <th rowspan="2">Catatan</th>
                    </tr>
                <tr>
                  <th>R</th>
                  <th>R-S</th>
                  <th>S</th>
                  <th>R-T</th>
                  <th>T</th>
                  <th>T-S</th>
                  <th>R</th>
                  <th>S</th>
                  <th>T</th>
                </tr>
                
                 ';
                  $i = 1;
                      foreach ($querypaneldis->result() as $datapaneldis) :
                        
                  $paneldis .='
                  <tr>

                    <td>'.$i.'</td>
                    <td>'.$datapaneldis->kode_alat.'</td>
                    <td>'.$datapaneldis->tanggal.'</td>
                    <td>'.$datapaneldis->dinas.'</td>
                    <td>'.$datapaneldis->tegangan_r.'</td>
                    <td>'.$datapaneldis->tegangan_r_s.'</td>
                    <td>'.$datapaneldis->tegangan_s.'</td>
                    <td>'.$datapaneldis->tegangan_r_t.'</td>
                    <td>'.$datapaneldis->tegangan_t.'</td>
                    <td>'.$datapaneldis->tegangan_t_s.'</td>  
                    <td>'.$datapaneldis->arus_r.'</td>
                    <td>'.$datapaneldis->arus_s.'</td>
                    <td>'.$datapaneldis->arus_t.'</td>
                    <td>'.$datapaneldis->frekuensi.'</td>
                    <td>'.$datapaneldis->mode_operasi.'</td>
                    <td>'.$datapaneldis->kebersihan_panel.'</td>
                    <td>'.$datapaneldis->catatan.'</td>
                </tr>
               
                    '; 
                $i++;
                endforeach;
                $paneldis .='

               
                </table> 
                <br>
                <div class="mengetahui" >
                <p style="text-align:center;font-size:10px;">Mengetahui,</p>
                <p style="text-align:center;font-size:10px;">JR. MANAGER TEKNIK FASILITAS MENUNJANG</p>
            </div>
            </body>
            </html>';


        $ups = '<!DOCTYPE html>
            <html>
            <head>
            <style>
                  .p{
                    font-size: 10pt;
                  }

                  .o{
                    font-size: 10pt;
                    text-align:left;
                  }
                  .judul{
                    font-size: 11pt;
                    text-align:center;
                    font-style: bold;
                  }
                  .judulfield{
                    background-color: #ddd;
                  }
                  td{
                    text-align:center;
                    font-size: 8pt;
                  }

                  .catatan {
                    text-align:left;
                    border:0;
                  }
              </style>
            </head>
            <body>

                <p class="p">PERUM LPPNPI</p>
                <p class="p">AIRNAV INDONESIA CABANG MADYA MEDAN - DELI SERDANG</p>
                <p class="p">ENGINEERING SUPPORT SYSTEM</p>

                <p class="judul"><b>CHECKLIST BULANAN PERAWATAN UNINTERRUPTABLE POWER SUPPLY (UPS)</b></p>
                <table>
                <tr>
                <td class="o">Lokasi</td>
                <td class="o">:</td>
                <td class="o">Tower</td>
                </tr>
                <tr>
                <td class="o">Bulan</td>
                <td class="o">:</td>
                <td class="o">'.$nama_bulan.' '.$tahun.'</td>
                <td class="o"></td>
                </tr>
                
                </table>
                <br>

                 <table border="1" cellpadding="10" cellspacing="0">
                   <tr>

                <th rowspan="2">No</th>
                  <th rowspan="2">Kode Alat</th>
                  <th rowspan="2">Tanggal</th>
                  <th rowspan="2">Dinas</th>
                  <th colspan="3">V Main</th>
                  <th colspan="3">V Output</th>
                  <th colspan="3">Arus Main</th>
                  <th colspan="3">Arus Output</th>
                  <th colspan="3">UPS LD</th>
                  <th colspan="3">TOTAL LD</th>
                  <th colspan="2">DC Volt</th>
                  <th colspan="2">Ukuran Tegangan Breaker Baterai</th>
                    <th rowspan="2">Status</th>
                  <th rowspan="2">Operasional</th>
                  <th rowspan="2">Kebersihan UPS</th>
                  <th rowspan="2">Suhu Ruangan</th>
                  <th rowspan="2">Catatan</th>
                </tr>
                <tr>

                  <th>R</th>
                  <th>S</th>
                  <th>T</th>
                  <th>R</th>
                  <th>S</th>
                  <th>T</th>
                  <th>R</th>
                  <th>S</th>
                  <th>T</th>
                  <th>R</th>
                  <th>S</th>
                  <th>T</th>
                  <th>KVA</th>
                  <th>KW</th>
                  <th>PF</th>
                  <th>KVA</th>
                  <th>KW</th>
                  <th>PF</th>
                  <th>V</th>
                  <th>A</th>
                  <th>Input</th>
                  <th>Output</th>
                </tr>
                
                   ';
                  $i = 1;
                      foreach ($queryups->result() as $dataups) :
                        
                  $ups .='
                  <tr>
                <td>'.$i.'</td>
                    <td>'.$dataups->kode_alat.'</td>
                    <td>'.$dataups->tanggal.'</td>
                    <td>'.$dataups->dinas.'</td>
                    <td>'.$dataups->v_main_r.'</td>
                    <td>'.$dataups->v_main_s.'</td>
                    <td>'.$dataups->v_main_t.'</td>
                    <td>'.$dataups->v_output_r.'</td>
                    <td>'.$dataups->v_output_s.'</td>
                    <td>'.$dataups->v_output_t.'</td>
                    <td>'.$dataups->arus_main_r.'</td>
                    <td>'.$dataups->arus_main_s.'</td>
                    <td>'.$dataups->arus_main_t.'</td>
                    <td>'.$dataups->arus_output_r.'</td>
                    <td>'.$dataups->arus_output_s.'</td>
                    <td>'.$dataups->arus_output_t.'</td>
                    <td>'.$dataups->ups_ld_kva.'</td>
                    <td>'.$dataups->ups_ld_kw.'</td>
                    <td>'.$dataups->ups_ld_pf.'</td>
                    <td>'.$dataups->total_ld_kva.'</td>
                    <td>'.$dataups->ups_ld_kw.'</td>
                    <td>'.$dataups->ups_ld_pf.'</td>
                    <td>'.$dataups->dc_volt_v.'</td>
                    <td>'.$dataups->dc_volt_a.'</td>
                    <td>'.$dataups->ukuran_tegangan_in_breaker_baterai.'</td>
                    <td>'.$dataups->ukuran_tegangan_out_breaker_baterai.'</td>
                    <td>'.$dataups->status.'</td>
                    <td>'.$dataups->operasional.'</td>
                    <td>'.$dataups->kebersihan_ups.'</td>
                    <td>'.$dataups->suhu_ruangan.'</td>
                    <td>'.$datapaneldis->catatan.'</td>
                </tr>

                    '; 
                $i++;
                endforeach;
                $ups .='

                 </table>
               
                <br>
                <div class="mengetahui" >
                <p style="text-align:center;font-size:10px;">Mengetahui,</p>
                <p style="text-align:center;font-size:10px;">JR. MANAGER TEKNIK FASILITAS MENUNJANG</p>
            </div>
            </body>
            </html>';

            $bangunanac = '<!DOCTYPE html>
            <html>
            <head>
            <style>
                  .p{
                    font-size: 10pt;
                  }

                  .o{
                    font-size: 10pt;
                    text-align:left;
                  }
                  .judul{
                    font-size: 11pt;
                    text-align:center;
                    font-style: bold;
                  }
                  .judulfield{
                    background-color: #ddd;
                  }
                  td{
                    text-align:center;
                    font-size: 8pt;
                  }

                  .catatan {
                    text-align:left;
                    border:0;
                  }
              </style>
            </head>
            <body>

                <p class="p">PERUM LPPNPI</p>
                <p class="p">AIRNAV INDONESIA CABANG MADYA MEDAN - DELI SERDANG</p>
                <p class="p">ENGINEERING SUPPORT SYSTEM</p>

                <p class="judul"><b>CHECKLIST BULANAN PERAWATAN BANGUNAN DAN AC</b></p>
                <table>
                <tr>
                <td class="o">Lokasi</td>
                <td class="o">:</td>
                <td class="o">Tower</td>
                </tr>
                <tr>
                <td class="o">Bulan</td>
                <td class="o">:</td>
                <td class="o">'.$nama_bulan.' '.$tahun.'</td>
                <td class="o"></td>
                </tr>
                
                </table>
                <br>

                  <table border="1" cellpadding="10" cellspacing="0">
                  <tr>
                   <th rowspan="2">No</th>
                  <th rowspan="2">Kode Alat</th>
                  <th rowspan="2">Tanggal</th>
                  <th rowspan="2">Dinas</th>
                  <th colspan="5">Checklist / Parameter</th>
                  <th rowspan="2">catatan</th>
                </tr>
                <tr>
                  <th>Kebersihan Ruangan</th>
                  <th>Kondisi Bangunan</th>
                  <th>Suhu Ruangan (Celcius)</th>
                  <th>Periksa Aliran Udara Evapurator</th>
                  <th>Pastikan Unit Outdoor/Kompresor Bekerja</th>
                  
                </tr>
                    ';
                  $i = 1;
                      foreach ($querybangunanac->result() as $databangunac) :
                  $bangunanac .='
                <tr>
                    <td>'.$i.'</td>
                    <td>'.$databangunac->kode_alat.'</td>
                    <td>'.$databangunac->tanggal.'</td>
                    <td>'.$databangunac->dinas.'</td>
                    <td>'.$databangunac->kebersihan_ruangan.'</td>
                    <td>'.$databangunac->kondisi_bangunan.'</td>
                    <td>'.$databangunac->suhu_ruangan.'</td>
                    <td>'.$databangunac->periksa_aliran_udara_evapurator.'</td>
                    <td>'.$databangunac->pastikan_unit_outdoor_kompresor_bekerja.'</td>
                     <td>'.$databangunac->catatan.'</td>

          
                </tr>
                '; 
                $i++;
                endforeach;
                $bangunanac .='
                </table>
               
                <br>
                <div class="mengetahui" >
                <p style="text-align:center;font-size:10px;">Mengetahui,</p>
                <p style="text-align:center;font-size:10px;">JR. MANAGER TEKNIK FASILITAS MENUNJANG</p>
            </div>
            </body>
            </html>';

            $ehfan ='<!DOCTYPE html>
            <html>
            <head>
            <style>
                  .p{
                    font-size: 10pt;
                  }

                  .o{
                    font-size: 10pt;
                    text-align:left;
                  }
                  .judul{
                    font-size: 11pt;
                    text-align:center;
                    font-style: bold;
                  }
                  .judulfield{
                    background-color: #ddd;
                  }
                  td{
                    text-align:center;
                    font-size: 8pt;
                  }

                  .catatan {
                    text-align:left;
                    border:0;
                  }
              </style>
            </head>
            <body>
            
                <p class="p">PERUM LPPNPI</p>
                <p class="p">AIRNAV INDONESIA CABANG MADYA MEDAN - DELI SERDANG</p>
                <p class="p">ENGINEERING SUPPORT SYSTEM</p>

                <p class="judul"><b>CHECKLIST BULANAN PERAWATAN EXHAUST FAN</b></p>
                <table>
                <tr>
                <td class="o">Lokasi</td>
                <td class="o">:</td>
                <td class="o">Tower</td>
                </tr>
                <tr>
                <td class="o">Bulan</td>
                <td class="o">:</td>
                <td class="o">'.$nama_bulan.' '.$tahun.'</td>
                <td class="o"></td>
                </tr>
                
                </table>
            <br>
               <table border="1" cellpadding="10" cellspacing="0" style="text-align:center" align="center">
                <tr>
                  <th rowspan="2">No</th>
                  <th rowspan="2">Kode Alat</th>
                  <th rowspan="2">Tanggal</th>
                  <th rowspan="2">Dinas</th>
                  <th colspan="2">Checklist</th>
                   <th rowspan="2">Catatan</th>
                </tr>
                <tr>
                  <th>Status</th>
                  <th>Kondisi</th>
                </tr>

                 ';
                  $i = 1;
                      foreach ($queryehfan->result() as $dataehfan) :
                  $ehfan .='
                <tr>
                    <td>'.$i.'</td>
                    <td>'.$dataehfan->kode_alat.'</td>
                    <td>'.$dataehfan->tanggal.'</td>
                    <td>'.$dataehfan->dinas.'</td>
                    <td>'.$dataehfan->status.'</td>
                    <td>'.$dataehfan->kondisi.'</td>

                     <td>'.$databangunac->catatan.'</td>

          
                </tr>
                '; 
                $i++;
                endforeach;
                $ehfan .='
                </table>
                <br>
                <div class="mengetahui" >
                <p style="text-align:center;font-size:10px;">Mengetahui,</p>
                <p style="text-align:center;font-size:10px;">JR. MANAGER TEKNIK FASILITAS MENUNJANG</p>
            </div>
            </body>
            </html>';

            $cctv = '<!DOCTYPE html>
            <html>
            <head>
            <style>
                  .p{
                    font-size: 10pt;
                  }

                  .o{
                    font-size: 10pt;
                    text-align:left;
                  }
                  .judul{
                    font-size: 11pt;
                    text-align:center;
                    font-style: bold;
                  }
                  .judulfield{
                    background-color: #ddd;
                  }
                  td{
                    text-align:center;
                    font-size: 8pt;
                  }

                  .catatan {
                    text-align:left;
                    border:0;
                  }
              </style>
            </head>
            <body>
            
                <p class="p">PERUM LPPNPI</p>
                <p class="p">AIRNAV INDONESIA CABANG MADYA MEDAN - DELI SERDANG</p>
                <p class="p">ENGINEERING SUPPORT SYSTEM</p>

                <p class="judul"><b>CHECKLIST BULANAN PERAWATAN CCTV</b></p>
                <table>
                <tr>
                <td class="o">Lokasi</td>
                <td class="o">:</td>
                <td class="o">Tower</td>
                </tr>
                <tr>
                <td class="o">Bulan</td>
                <td class="o">:</td>
                <td class="o">'.$nama_bulan.' '.$tahun.'</td>
                <td class="o"></td>
                </tr>
                </table>
                <br>
               <table border="1" cellpadding="10" cellspacing="0" style="text-align:center" align="center">
                <tr class="text-center">
                  <th rowspan="2">No</th>
                  <th rowspan="2">Kode Alat</th>
                  <th rowspan="2">Tanggal</th>
                  <th rowspan="2">Dinas</th>
                  <th colspan="3">Checklist / Parameter</th>
                   <th rowspan="2">Catatan</th>
                </tr>
                <tr>    
                  <th>Suhu Ruangan Kontrol</th>
                  <th>Kebersihan Ruangan Kontrol</th>
                  <th>Kebersihan Bagian Luar Ruangan Kontrol</th>
                 
                </tr>

                 ';
                  $i = 1;
                      foreach ($querycctv->result() as $datacctv) :
                  $cctv .='
                <tr>
                    <td>'.$i.'</td>
                    <td>'.$datacctv->kode_alat.'</td>
                    <td>'.$datacctv->tanggal.'</td>
                    <td>'.$datacctv->dinas.'</td>
                    <td>'.$datacctv->suhu_ruangan_kontrol.'</td>
                    <td>'.$datacctv->kebersihan_ruangan_kontrol.'</td>
                    <td>'.$datacctv->kebersihan_bagian_luar_ruangan_kontrol.'</td>
                     <td>'.$datacctv->catatan.'</td>

          
                </tr>
                '; 
                $i++;
                endforeach;
                $cctv .='
                </table>  
                <br>
                <div class="mengetahui" >
                <p style="text-align:center;font-size:10px;">Mengetahui,</p>
                <p style="text-align:center;font-size:10px;">JR. MANAGER TEKNIK FASILITAS MENUNJANG</p>
            </div>
            </body>
            </html>';

    if ($kode_alat == "PANELDIS") {
        $mpdf->WriteHTML($paneldis);
    } else if ($kode_alat == "UPS") {
        $mpdf->WriteHTML($ups);
    } else if ($kode_alat == "BANGUNAN DAN AC") {
        $mpdf->WriteHTML($bangunanac);
    } else if ($kode_alat == "EXHAUST FAN") {
        $mpdf->WriteHTML($ehfan);
    } else if ($kode_alat == "CCTV") {
        $mpdf->WriteHTML($cctv);
    }

     $mpdf->Output();
      } elseif($this->session->userdata('level') == "Admin"){
            redirect('admin','refresh');
        } else{
            redirect('login','refresh');
        }
    }

    public function cetaklogbookkegiatan()
    {
         if($this->session->userdata('level') == "User"){
     //load mpdf libray
    $this->load->library('Mpdf');

    $mpdf = $this->mpdf->load([
        'mode' => 'utf-8',
        'format' => 'A3-L'
    ]);

    $tanggal = $this->input->post('tanggal');
    $tanggal2 = date('d-m-y',strtotime($tanggal));
    $hari = date('D',strtotime($tanggal));
     $querylogkegiatan = $this->db->query("SELECT * FROM tbl_logbookkegiatan WHERE tanggal = '$tanggal'");
    switch($hari){
        case 'Sun':
            $hari_ini = "Minggu";
        break;
 
        case 'Mon':         
            $hari_ini = "Senin";
        break;
 
        case 'Tue':
            $hari_ini = "Selasa";
        break;
 
        case 'Wed':
            $hari_ini = "Rabu";
        break;
 
        case 'Thu':
            $hari_ini = "Kamis";
        break;
 
        case 'Fri':
            $hari_ini = "Jumat";
        break;
 
        case 'Sat':
            $hari_ini = "Sabtu";
        break;
        
        default:
            $hari_ini = "Tidak di ketahui";     
        break;
    }
    $tanggalhari = $hari_ini.("/").$tanggal2;
  

    $html = '<!DOCTYPE html>
            <html>
            <head>
            <style>
                  .p{
                    font-size: 10pt;
                  }

                  .o{
                    font-size: 10pt;
                    text-align:left;
                  }
                  .judul{
                    font-size: 11pt;
                    text-align:center;
                    font-style: bold;
                  }
                  .judulfield{
                    background-color: #ddd;
                  }
                  td{
                    text-align:center;
                    font-size: 8pt;
                  }

                  .catatan {
                    text-align:left;
                    border:0;
                  }
              </style>
            </head>
             <body>
                <p class="p">PERUM LPPNPI</p>
                <p class="p">AIRNAV INDONESIA CABANG MADYA MEDAN - DELI SERDANG</p>
                <p class="p">ENGINEERING SUPPORT SYSTEM</p>

                <p class="judul"><b>LOG BOOK KEGIATAN</b></p>
                <table>
                <tr>
                <td class="o">Lokasi</td>
                <td class="o">:</td>
                <td class="o">Tower</td>
                </tr>
                <tr>
                <td class="o">Tanggal</td>
                <td class="o">:</td>
                <td class="o">'.$tanggalhari.'</td>
                </tr>
            
                </table>
                <br>
                
                 <table border="1" cellpadding="10" cellspacing="0" style="text-align:center" align="center">
              
                <tr>    
                  <th>No</th>
                  <th>kegiatan</th>
                  <th>keterangan</th>
                 
                </tr>

                 ';
                  $i = 1;
                      foreach ($querylogkegiatan->result() as $datalog) :
                  $html .='
                <tr>
                    <td>'.$i.'</td>
                    <td><p>'.str_replace("\n",' | ' ,$datalog->kegiatan).'</p></td>
                    <td>'.$datalog->keterangan.'</td>
          
                </tr>
                '; 
                $i++;
                endforeach;
                $html .='
                </table>  

                <br>
                <div class="mengetahui" >
                <p style="text-align:center;font-size:10px;">Mengetahui,</p>
                <p style="text-align:center;font-size:10px;">JR. MANAGER TEKNIK FASILITAS MENUNJANG</p>
            </div>
            </body>
            </html>';

     $mpdf->WriteHTML($html);
    
     $mpdf->Output();
      } elseif($this->session->userdata('level') == "Admin"){
            redirect('admin','refresh');
        } else{
            redirect('login','refresh');
        }
    }
}

/* End of file Cetaklaporan.php */
/* Location: ./application/controllers/Cetaklaporan.php */