<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UPS2 extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->load->library('upload');
		$this->load->model('model_ups');
	}

	public function index()
	{
		if($this->session->userdata('level') == "User"){
			$data['content'] = $this->db->where('kode_alat','UPS2');
			$data['content'] = $this->db->get('tbl_ups');
			$this->load->view('dalamtower/ups/ups_2/ups_2', $data);
		} elseif($this->session->userdata('level') == "Admin"){
			redirect('admin','refresh');
		} else{
			redirect('login','refresh');
		}
	}

	public function inputparameterharian()
	{
		if($this->session->userdata('level') == "User"){
			$this->load->view("dalamtower/ups/ups_2/add");
		} elseif($this->session->userdata('level') == "Admin"){
			redirect('admin','refresh');
		} else{
			redirect('login','refresh');
		}
	}

	public function action_add()
	{
		$v_main_r = $this->input->post("vmainr");
		$v_main_s = $this->input->post("vmains");
		$v_main_t = $this->input->post("vmaint");
		$v_output_r = $this->input->post("voutputr");
		$v_output_s = $this->input->post("voutputs");
		$v_output_t = $this->input->post("voutputt");
		$dc_volt_v = $this->input->post("dcvoltv");

		$kode_alat = $this->input->post('kode_alat');
		$tanggal = $this->input->post('tanggal');
		$dinas = $this->input->post('dinas');
		$query = $this->db->query("SELECT * from tbl_ups where kode_alat = '$kode_alat' AND tanggal = '$tanggal' AND dinas = '$dinas'");
		
		if ($query->num_rows() > 0){
			$this->session->set_flashdata('pesanerror3', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal ditambah. Tanggal dan dinas hari ini sudah diinput!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	redirect('UPS2/inputparameterharian');
		}

		$namafile = str_replace(' ', '_',date("d-m-y").("_").$dinas.("_").$kode_alat.("_").$_FILES['foto']['name']); //nama file + fungsi time
		$jenis_gambar = $_FILES['foto']['type'];
		$size_gambar = $_FILES['foto']['size'];
        $config['upload_path'] = './assets/img/fotokegiatan/ups/'; //Folder untuk menyimpan hasil upload
        $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['file_name'] = $namafile; //nama yang terupload nantinya

        $this->upload->initialize($config);

		 if(!empty($_FILES['foto']['name']))
        {
        	if($jenis_gambar !="image/jpeg" && $jenis_gambar !="image/jpg" && $jenis_gambar !="image/gif" && $jenis_gambar!="image/png")
				  {
				  	$this->session->set_flashdata('pesanerror', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal ditambah. Jenis gambar yang anda kirim salah. Harus berformat .jpg .gif .png!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	redirect('UPS2/inputparameterharian');
				  }else if($size_gambar > 3000000){

					$this->session->set_flashdata('pesanerror2', '<div class="alert alert-warning alert-dismissible fade show" 
													role="alert">
													  Data gagal ditambah. Upload foto maksimal 3MB!
													  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													    <span aria-hidden="true">&times;</span>
													  </button>
													</div>');
					redirect('UPS2/inputparameterharian');

				  } elseif($this->upload->do_upload('foto')){
				  		
           				$this->upload->data();
           				$config['image_library']='gd2';
		                $config['source_image']='./assets/img/fotokegiatan/ups/'.$namafile;
		                $config['create_thumb']= FALSE;
		                $config['maintain_ratio']= FALSE;
		                $config['quality']= '60%';
		                $config['width']= 800;
		                $config['height']= 400;
		                $config['new_image']= './assets/img/fotokegiatan/ups/'.$namafile;

		                $this->load->library('image_lib', $config);   
		                $this->image_lib->resize();
	

				$data = array(
					"kode_alat" => $this->input->post("kode_alat"),
					"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
					"tanggal" => $this->input->post("tanggal"),
					"dinas" => $this->input->post("dinas"),
					"lokasi" => $this->input->post("lokasi"),
					"v_main_r" => $this->input->post("vmainr"),
					"v_main_s" => $this->input->post("vmains"),
					"v_main_t" => $this->input->post("vmaint"),
					"v_output_r" => $this->input->post("voutputr"),
					"v_output_s" => $this->input->post("voutputs"),
					"v_output_t" => $this->input->post("voutputt"),
					"arus_main_r" => $this->input->post("arusmainr"),
					"arus_main_s" => $this->input->post("arusmains"),
					"arus_main_t" => $this->input->post("arusmaint"),
					"arus_output_r" => $this->input->post("arusoutputr"),
					"arus_output_s" => $this->input->post("arusoutputs"),
					"arus_output_t" => $this->input->post("arusoutputt"),
					"ups_ld_kva" => $this->input->post("upsldkva"),
					"ups_ld_kw" => $this->input->post("upsldkw"),
					"ups_ld_pf" => $this->input->post("upsldpf"),
					"total_ld_kva" => $this->input->post("totalldkva"),
					"total_ld_kw" => $this->input->post("totalldkw"),
					"total_ld_pf" => $this->input->post("totalldpf"),
					"dc_volt_a" => $this->input->post("dcvolta"),
					"dc_volt_v" => $this->input->post("dcvoltv"),
					"status" => $this->input->post("status"),
					"operasional" => $this->input->post("operasional"),
					"kebersihan_ups" => $this->input->post("kebersihan_ups"),
					"ukuran_tegangan_in_breaker_baterai" => $this->input->post("ukuran_tegangan_input_bb"),
					"ukuran_tegangan_out_breaker_baterai" => $this->input->post("ukuran_tegangan_output_bb"),
					"suhu_ruangan" => $this->input->post("suhu_ruangan"),
					"foto" => $namafile,
					"catatan" => "Nilai Parameter Normal"
				);

				$data3 = array(
					"kode_alat" => $this->input->post("kode_alat"),
					"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
					"tanggal" => $this->input->post("tanggal"),
					"dinas" => $this->input->post("dinas"),
					"lokasi" => $this->input->post("lokasi"),
					"v_main_r" => $this->input->post("vmainr"),
					"v_main_s" => $this->input->post("vmains"),
					"v_main_t" => $this->input->post("vmaint"),
					"v_output_r" => $this->input->post("voutputr"),
					"v_output_s" => $this->input->post("voutputs"),
					"v_output_t" => $this->input->post("voutputt"),
					"arus_main_r" => $this->input->post("arusmainr"),
					"arus_main_s" => $this->input->post("arusmains"),
					"arus_main_t" => $this->input->post("arusmaint"),
					"arus_output_r" => $this->input->post("arusoutputr"),
					"arus_output_s" => $this->input->post("arusoutputs"),
					"arus_output_t" => $this->input->post("arusoutputt"),
					"ups_ld_kva" => $this->input->post("upsldkva"),
					"ups_ld_kw" => $this->input->post("upsldkw"),
					"ups_ld_pf" => $this->input->post("upsldpf"),
					"total_ld_kva" => $this->input->post("totalldkva"),
					"total_ld_kw" => $this->input->post("totalldkw"),
					"total_ld_pf" => $this->input->post("totalldpf"),
					"dc_volt_a" => $this->input->post("dcvolta"),
					"dc_volt_v" => $this->input->post("dcvoltv"),
					"status" => $this->input->post("status"),
					"operasional" => $this->input->post("operasional"),
					"kebersihan_ups" => $this->input->post("kebersihan_ups"),
					"ukuran_tegangan_in_breaker_baterai" => $this->input->post("ukuran_tegangan_input_bb"),
					"ukuran_tegangan_out_breaker_baterai" => $this->input->post("ukuran_tegangan_output_bb"),
					"suhu_ruangan" => $this->input->post("suhu_ruangan"),
					"foto" => $namafile,
					"catatan" => "DC Volt Tidak Normal"
				);

				$data2 = array(
					"kode_alat" => $this->input->post("kode_alat"),
					"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
					"tanggal" => $this->input->post("tanggal"),
					"dinas" => $this->input->post("dinas"),
					"lokasi" => $this->input->post("lokasi"),
					"v_main_r" => $this->input->post("vmainr"),
					"v_main_s" => $this->input->post("vmains"),
					"v_main_t" => $this->input->post("vmaint"),
					"v_output_r" => $this->input->post("voutputr"),
					"v_output_s" => $this->input->post("voutputs"),
					"v_output_t" => $this->input->post("voutputt"),
					"arus_main_r" => $this->input->post("arusmainr"),
					"arus_main_s" => $this->input->post("arusmains"),
					"arus_main_t" => $this->input->post("arusmaint"),
					"arus_output_r" => $this->input->post("arusoutputr"),
					"arus_output_s" => $this->input->post("arusoutputs"),
					"arus_output_t" => $this->input->post("arusoutputt"),
					"ups_ld_kva" => $this->input->post("upsldkva"),
					"ups_ld_kw" => $this->input->post("upsldkw"),
					"ups_ld_pf" => $this->input->post("upsldpf"),
					"total_ld_kva" => $this->input->post("totalldkva"),
					"total_ld_kw" => $this->input->post("totalldkw"),
					"total_ld_pf" => $this->input->post("totalldpf"),
					"dc_volt_a" => $this->input->post("dcvolta"),
					"dc_volt_v" => $this->input->post("dcvoltv"),
					"status" => $this->input->post("status"),
					"operasional" => $this->input->post("operasional"),
					"kebersihan_ups" => $this->input->post("kebersihan_ups"),
					"ukuran_tegangan_in_breaker_baterai" => $this->input->post("ukuran_tegangan_input_bb"),
					"ukuran_tegangan_out_breaker_baterai" => $this->input->post("ukuran_tegangan_output_bb"),
					"suhu_ruangan" => $this->input->post("suhu_ruangan"),
					"foto" => $namafile,
					"catatan" => "Tegangan Tidak Normal"
				);

		if ($v_output_r < 215 || $v_output_r > 235 
			|| $v_output_s < 215 || $v_output_s > 235 
			|| $v_output_t < 215 || $v_output_t > 235 
			|| $v_main_r < 375 || $v_main_r > 405
			|| $v_main_s < 375 || $v_main_s > 405
			|| $v_main_t < 375 || $v_main_t > 405) {
			$this->model_ups->action_add3($data2);
			// $this->db->insert('tbl_paneldis', $data2);
			$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil ditambah!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
			redirect('UPS2','refresh');
		} elseif ($dc_volt_v < 375 || $dc_volt_v > 405) {
			$this->model_ups->action_add2($data3);
			// $this->db->insert('tbl_paneldis', $data3);
			 $this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil ditambah!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
			redirect('UPS2','refresh');
		} else {
			$this->model_ups->action_add1($data);
			// $this->db->insert('tbl_paneldis', $data);
			 $this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil ditambah!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
			redirect('UPS2','refresh');
				}
			}
		}
	}

	public function update($id = NULL)
	{	
		if($this->session->userdata('level') == "User"){
			$this->db->where('id', $id);
			$data['content'] = $this->db->get('tbl_ups');
			$this->load->view('dalamtower/ups/ups_2/update', $data);
		} elseif($this->session->userdata('level') == "Admin"){
			redirect('admin','refresh');
		} else{
			redirect('login','refresh');
		}
	}

	public function action_update($id = '')
	{
		$v_main_r = $this->input->post("vmainr");
		$v_main_s = $this->input->post("vmains");
		$v_main_t = $this->input->post("vmaint");
		$v_output_r = $this->input->post("voutputr");
		$v_output_s = $this->input->post("voutputs");
		$v_output_t = $this->input->post("voutputt");
		$dc_volt_v = $this->input->post("dcvoltv");
		$kode_alat = $this->input->post('kode_alat');
		$dinas = $this->input->post('dinas');

		$namafile = date("d-m-y").("_").$dinas.("_").$kode_alat.("_").$_FILES['foto']['name']; //nama file + fungsi time
		$jenis_gambar = $_FILES['foto']['type'];
		$size_gambar = $_FILES['foto']['size'];
        $config['upload_path'] = './assets/img/fotokegiatan/ups/'; //Folder untuk menyimpan hasil upload
        $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['file_name'] = $namafile; //nama yang terupload nantinya

        $this->upload->initialize($config);

		 if(!empty($_FILES['foto']['name']))
        {
        	if($jenis_gambar !="image/jpeg" && $jenis_gambar !="image/jpg" && $jenis_gambar !="image/gif" && $jenis_gambar!="image/png")
				  {
				  	$this->session->set_flashdata('pesanerror', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal diupdate. Jenis gambar yang anda kirim salah. Harus berformat .jpg .gif .png!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	$this->update($id);
				  }else if($size_gambar > 3000000){

					$this->session->set_flashdata('pesanerror2', '<div class="alert alert-warning alert-dismissible fade show" 
													role="alert">
													  Data gagal diupdate. Upload foto maksimal 3MB!
													  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
													    <span aria-hidden="true">&times;</span>
													  </button>
													</div>');
					$this->update($id);

				  } elseif($this->upload->do_upload('foto')){
				  		
           				$this->upload->data();
           				$config['image_library']='gd2';
		                $config['source_image']='./assets/img/fotokegiatan/ups/'.$namafile;
		                $config['create_thumb']= FALSE;
		                $config['maintain_ratio']= FALSE;
		                $config['quality']= '60%';
		                $config['width']= 800;
		                $config['height']= 400;
		                $config['new_image']= './assets/img/fotokegiatan/ups/'.$namafile;

		                $this->load->library('image_lib', $config);   
		                $this->image_lib->resize();
	

				$data = array(
					"kode_alat" => $this->input->post("kode_alat"),
					"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
					"tanggal" => $this->input->post("tanggal"),
					"dinas" => $this->input->post("dinas"),
					"lokasi" => $this->input->post("lokasi"),
					"v_main_r" => $this->input->post("vmainr"),
					"v_main_s" => $this->input->post("vmains"),
					"v_main_t" => $this->input->post("vmaint"),
					"v_output_r" => $this->input->post("voutputr"),
					"v_output_s" => $this->input->post("voutputs"),
					"v_output_t" => $this->input->post("voutputt"),
					"arus_main_r" => $this->input->post("arusmainr"),
					"arus_main_s" => $this->input->post("arusmains"),
					"arus_main_t" => $this->input->post("arusmaint"),
					"arus_output_r" => $this->input->post("arusoutputr"),
					"arus_output_s" => $this->input->post("arusoutputs"),
					"arus_output_t" => $this->input->post("arusoutputt"),
					"ups_ld_kva" => $this->input->post("upsldkva"),
					"ups_ld_kw" => $this->input->post("upsldkw"),
					"ups_ld_pf" => $this->input->post("upsldpf"),
					"total_ld_kva" => $this->input->post("totalldkva"),
					"total_ld_kw" => $this->input->post("totalldkw"),
					"total_ld_pf" => $this->input->post("totalldpf"),
					"dc_volt_a" => $this->input->post("dcvolta"),
					"dc_volt_v" => $this->input->post("dcvoltv"),
					"status" => $this->input->post("status"),
					"operasional" => $this->input->post("operasional"),
					"kebersihan_ups" => $this->input->post("kebersihan_ups"),
					"ukuran_tegangan_in_breaker_baterai" => $this->input->post("ukuran_tegangan_input_bb"),
					"ukuran_tegangan_out_breaker_baterai" => $this->input->post("ukuran_tegangan_output_bb"),
					"suhu_ruangan" => $this->input->post("suhu_ruangan"),
					"foto" => $namafile,
					"catatan" => "Nilai Parameter Normal"
				);

				$data3 = array(
					"kode_alat" => $this->input->post("kode_alat"),
					"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
					"tanggal" => $this->input->post("tanggal"),
					"dinas" => $this->input->post("dinas"),
					"lokasi" => $this->input->post("lokasi"),
					"v_main_r" => $this->input->post("vmainr"),
					"v_main_s" => $this->input->post("vmains"),
					"v_main_t" => $this->input->post("vmaint"),
					"v_output_r" => $this->input->post("voutputr"),
					"v_output_s" => $this->input->post("voutputs"),
					"v_output_t" => $this->input->post("voutputt"),
					"arus_main_r" => $this->input->post("arusmainr"),
					"arus_main_s" => $this->input->post("arusmains"),
					"arus_main_t" => $this->input->post("arusmaint"),
					"arus_output_r" => $this->input->post("arusoutputr"),
					"arus_output_s" => $this->input->post("arusoutputs"),
					"arus_output_t" => $this->input->post("arusoutputt"),
					"ups_ld_kva" => $this->input->post("upsldkva"),
					"ups_ld_kw" => $this->input->post("upsldkw"),
					"ups_ld_pf" => $this->input->post("upsldpf"),
					"total_ld_kva" => $this->input->post("totalldkva"),
					"total_ld_kw" => $this->input->post("totalldkw"),
					"total_ld_pf" => $this->input->post("totalldpf"),
					"dc_volt_a" => $this->input->post("dcvolta"),
					"dc_volt_v" => $this->input->post("dcvoltv"),
					"status" => $this->input->post("status"),
					"operasional" => $this->input->post("operasional"),
					"kebersihan_ups" => $this->input->post("kebersihan_ups"),
					"ukuran_tegangan_in_breaker_baterai" => $this->input->post("ukuran_tegangan_input_bb"),
					"ukuran_tegangan_out_breaker_baterai" => $this->input->post("ukuran_tegangan_output_bb"),
					"suhu_ruangan" => $this->input->post("suhu_ruangan"),
					"foto" => $namafile,
					"catatan" => "DC Volt Tidak Normal"
				);

				$data2 = array(
					"kode_alat" => $this->input->post("kode_alat"),
					"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
					"tanggal" => $this->input->post("tanggal"),
					"dinas" => $this->input->post("dinas"),
					"lokasi" => $this->input->post("lokasi"),
					"v_main_r" => $this->input->post("vmainr"),
					"v_main_s" => $this->input->post("vmains"),
					"v_main_t" => $this->input->post("vmaint"),
					"v_output_r" => $this->input->post("voutputr"),
					"v_output_s" => $this->input->post("voutputs"),
					"v_output_t" => $this->input->post("voutputt"),
					"arus_main_r" => $this->input->post("arusmainr"),
					"arus_main_s" => $this->input->post("arusmains"),
					"arus_main_t" => $this->input->post("arusmaint"),
					"arus_output_r" => $this->input->post("arusoutputr"),
					"arus_output_s" => $this->input->post("arusoutputs"),
					"arus_output_t" => $this->input->post("arusoutputt"),
					"ups_ld_kva" => $this->input->post("upsldkva"),
					"ups_ld_kw" => $this->input->post("upsldkw"),
					"ups_ld_pf" => $this->input->post("upsldpf"),
					"total_ld_kva" => $this->input->post("totalldkva"),
					"total_ld_kw" => $this->input->post("totalldkw"),
					"total_ld_pf" => $this->input->post("totalldpf"),
					"dc_volt_a" => $this->input->post("dcvolta"),
					"dc_volt_v" => $this->input->post("dcvoltv"),
					"status" => $this->input->post("status"),
					"operasional" => $this->input->post("operasional"),
					"kebersihan_ups" => $this->input->post("kebersihan_ups"),
					"ukuran_tegangan_in_breaker_baterai" => $this->input->post("ukuran_tegangan_input_bb"),
					"ukuran_tegangan_out_breaker_baterai" => $this->input->post("ukuran_tegangan_output_bb"),
					"suhu_ruangan" => $this->input->post("suhu_ruangan"),
					"foto" => $namafile,
					"catatan" => "Tegangan Tidak Normal"
				);

		if ($v_output_r < 215 || $v_output_r > 235 
			|| $v_output_s < 215 || $v_output_s > 235 
			|| $v_output_t < 215 || $v_output_t > 235 
			|| $v_main_r < 375 || $v_main_r > 405
			|| $v_main_s < 375 || $v_main_s > 405
			|| $v_main_t < 375 || $v_main_t > 405) {
			$this->model_ups->action_update3($data2, $id);
			// $this->db->insert('tbl_paneldis', $data2);
			$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil diupdate!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
			redirect('UPS2','refresh');
		} elseif ($dc_volt_v < 375 || $dc_volt_v > 405) {
			$this->model_ups->action_update2($data3, $id);
			// $this->db->insert('tbl_paneldis', $data3);
			 $this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil diupdate!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
			redirect('UPS2','refresh');
		} else {
			$this->model_ups->action_update1($data, $id);
			// $this->db->insert('tbl_paneldis', $data);
			 $this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil diupdate!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
			redirect('UPS2','refresh');
					}
				}
			} else {
				$fotolama = $this->input->post('fotolama');
						if ($_FILES['foto']['error'] === 4) {
								$foto = $fotolama;
							} else {
								$foto = $namafile;
							}

				$data = array(
					"kode_alat" => $this->input->post("kode_alat"),
					"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
					"tanggal" => $this->input->post("tanggal"),
					"dinas" => $this->input->post("dinas"),
					"lokasi" => $this->input->post("lokasi"),
					"v_main_r" => $this->input->post("vmainr"),
					"v_main_s" => $this->input->post("vmains"),
					"v_main_t" => $this->input->post("vmaint"),
					"v_output_r" => $this->input->post("voutputr"),
					"v_output_s" => $this->input->post("voutputs"),
					"v_output_t" => $this->input->post("voutputt"),
					"arus_main_r" => $this->input->post("arusmainr"),
					"arus_main_s" => $this->input->post("arusmains"),
					"arus_main_t" => $this->input->post("arusmaint"),
					"arus_output_r" => $this->input->post("arusoutputr"),
					"arus_output_s" => $this->input->post("arusoutputs"),
					"arus_output_t" => $this->input->post("arusoutputt"),
					"ups_ld_kva" => $this->input->post("upsldkva"),
					"ups_ld_kw" => $this->input->post("upsldkw"),
					"ups_ld_pf" => $this->input->post("upsldpf"),
					"total_ld_kva" => $this->input->post("totalldkva"),
					"total_ld_kw" => $this->input->post("totalldkw"),
					"total_ld_pf" => $this->input->post("totalldpf"),
					"dc_volt_a" => $this->input->post("dcvolta"),
					"dc_volt_v" => $this->input->post("dcvoltv"),
					"status" => $this->input->post("status"),
					"operasional" => $this->input->post("operasional"),
					"kebersihan_ups" => $this->input->post("kebersihan_ups"),
					"ukuran_tegangan_in_breaker_baterai" => $this->input->post("ukuran_tegangan_input_bb"),
					"ukuran_tegangan_out_breaker_baterai" => $this->input->post("ukuran_tegangan_output_bb"),
					"suhu_ruangan" => $this->input->post("suhu_ruangan"),
					"foto" => $foto,
					"catatan" => "Nilai Parameter Normal"
				);

				$data3 = array(
					"kode_alat" => $this->input->post("kode_alat"),
					"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
					"tanggal" => $this->input->post("tanggal"),
					"dinas" => $this->input->post("dinas"),
					"lokasi" => $this->input->post("lokasi"),
					"v_main_r" => $this->input->post("vmainr"),
					"v_main_s" => $this->input->post("vmains"),
					"v_main_t" => $this->input->post("vmaint"),
					"v_output_r" => $this->input->post("voutputr"),
					"v_output_s" => $this->input->post("voutputs"),
					"v_output_t" => $this->input->post("voutputt"),
					"arus_main_r" => $this->input->post("arusmainr"),
					"arus_main_s" => $this->input->post("arusmains"),
					"arus_main_t" => $this->input->post("arusmaint"),
					"arus_output_r" => $this->input->post("arusoutputr"),
					"arus_output_s" => $this->input->post("arusoutputs"),
					"arus_output_t" => $this->input->post("arusoutputt"),
					"ups_ld_kva" => $this->input->post("upsldkva"),
					"ups_ld_kw" => $this->input->post("upsldkw"),
					"ups_ld_pf" => $this->input->post("upsldpf"),
					"total_ld_kva" => $this->input->post("totalldkva"),
					"total_ld_kw" => $this->input->post("totalldkw"),
					"total_ld_pf" => $this->input->post("totalldpf"),
					"dc_volt_a" => $this->input->post("dcvolta"),
					"dc_volt_v" => $this->input->post("dcvoltv"),
					"status" => $this->input->post("status"),
					"operasional" => $this->input->post("operasional"),
					"kebersihan_ups" => $this->input->post("kebersihan_ups"),
					"ukuran_tegangan_in_breaker_baterai" => $this->input->post("ukuran_tegangan_input_bb"),
					"ukuran_tegangan_out_breaker_baterai" => $this->input->post("ukuran_tegangan_output_bb"),
					"suhu_ruangan" => $this->input->post("suhu_ruangan"),
					"foto" => $foto,
					"catatan" => "DC Volt Tidak Normal"
				);

				$data2 = array(
					"kode_alat" => $this->input->post("kode_alat"),
					"username_pemeriksa" =>$this->input->post("username_pemeriksa"),
					"tanggal" => $this->input->post("tanggal"),
					"dinas" => $this->input->post("dinas"),
					"lokasi" => $this->input->post("lokasi"),
					"v_main_r" => $this->input->post("vmainr"),
					"v_main_s" => $this->input->post("vmains"),
					"v_main_t" => $this->input->post("vmaint"),
					"v_output_r" => $this->input->post("voutputr"),
					"v_output_s" => $this->input->post("voutputs"),
					"v_output_t" => $this->input->post("voutputt"),
					"arus_main_r" => $this->input->post("arusmainr"),
					"arus_main_s" => $this->input->post("arusmains"),
					"arus_main_t" => $this->input->post("arusmaint"),
					"arus_output_r" => $this->input->post("arusoutputr"),
					"arus_output_s" => $this->input->post("arusoutputs"),
					"arus_output_t" => $this->input->post("arusoutputt"),
					"ups_ld_kva" => $this->input->post("upsldkva"),
					"ups_ld_kw" => $this->input->post("upsldkw"),
					"ups_ld_pf" => $this->input->post("upsldpf"),
					"total_ld_kva" => $this->input->post("totalldkva"),
					"total_ld_kw" => $this->input->post("totalldkw"),
					"total_ld_pf" => $this->input->post("totalldpf"),
					"dc_volt_a" => $this->input->post("dcvolta"),
					"dc_volt_v" => $this->input->post("dcvoltv"),
					"status" => $this->input->post("status"),
					"operasional" => $this->input->post("operasional"),
					"kebersihan_ups" => $this->input->post("kebersihan_ups"),
					"ukuran_tegangan_in_breaker_baterai" => $this->input->post("ukuran_tegangan_input_bb"),
					"ukuran_tegangan_out_breaker_baterai" => $this->input->post("ukuran_tegangan_output_bb"),
					"suhu_ruangan" => $this->input->post("suhu_ruangan"),
					"foto" => $foto,
					"catatan" => "Tegangan Tidak Normal"
				);

		if ($v_output_r < 215 || $v_output_r > 235 
			|| $v_output_s < 215 || $v_output_s > 235 
			|| $v_output_t < 215 || $v_output_t > 235 
			|| $v_main_r < 375 || $v_main_r > 405
			|| $v_main_s < 375 || $v_main_s > 405
			|| $v_main_t < 375 || $v_main_t > 405) {
			$this->model_ups->action_update3($data, $id);
			// $this->db->insert('tbl_paneldis', $data2);
			$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil diupdate!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
			redirect('UPS2','refresh');
		} elseif ($dc_volt_v < 375 || $dc_volt_v > 405) {
			$this->model_ups->action_update2($data3, $id);
			// $this->db->insert('tbl_paneldis', $data3);
			 $this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil diupdate!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
			redirect('UPS2','refresh');
		} else {
			$this->model_ups->action_update1($data, $id);
			// $this->db->insert('tbl_paneldis', $data);
			 $this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
										  Data Berhasil diupdate!
										  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
										    <span aria-hidden="true">&times;</span>
										  </button>
										</div>');
			redirect('UPS2','refresh');
			}
		}
	}

	public function delete($id)
	{
		if($this->session->userdata('level') == "User"){
			$this->model_ups->action_delete($id);
			$this->session->set_flashdata('pesanberhasilhapus', '<div class="alert alert-success alert-dismissible fade show" role="alert">
											  Data Berhasil dihapus!
											  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
											    <span aria-hidden="true">&times;</span>
											  </button>
											</div>');
			redirect('UPS2','refresh');
		} elseif($this->session->userdata('level') == "Admin"){
			redirect('admin','refresh');
		} else{
			redirect('login','refresh');
		}
	}
}

/* End of file Ups_1.php */
/* Location: ./application/controllers/Ups_1.php */
