<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Logbookkegiatan extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		//Do your magic here
		$this->load->model('model_logbookkegiatan');
	}

	public function index()
	{
		if($this->session->userdata('level') == "User"){
			$data['content'] = $this->db->get('tbl_logbookkegiatan');
			$this->load->view('logkegiatan/logkegiatan', $data);
		} elseif($this->session->userdata('level') == "Admin"){
			redirect('admin','refresh');
		} else{
			redirect('login','refresh');
		}
	}

	public function add()
	{
		if($this->session->userdata('level') == "User"){
			$this->load->view('logkegiatan/add');
		} elseif($this->session->userdata('level') == "Admin"){
			redirect('admin','refresh');
		} else{
			redirect('login','refresh');
		}	
	}

	public function action_add()
	{
		$tanggal = $this->input->post('tanggal');
		$query = $this->db->query("SELECT * from tbl_logbookkegiatan where tanggal = '$tanggal'");
		if ($query->num_rows() > 0) {
			$this->session->set_flashdata('pesanerror3', '<div class="alert alert-warning alert-dismissible fade show" 
				  								role="alert">
												  Data gagal ditambah. Tanggal hari ini sudah diinput!
												  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
												    <span aria-hidden="true">&times;</span>
												  </button>
												</div>');
				  	redirect('logbookkegiatan');
		}
			$data =array(

			"tanggal" => $this->input->post("tanggal"),
			"kegiatan" => $this->input->post("kegiatan"),
			"keterangan" => $this->input->post("keterangan"),
		);

		$this->model_logbookkegiatan->action_add($data);
		$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
											  Data Berhasil disimpan!
											  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
											    <span aria-hidden="true">&times;</span>
											  </button>
											</div>');
		redirect('logbookkegiatan','refresh');
	
	}

		public function update($id = NULL)
	{	
		if ($this->session->userdata('level') == "User") {
			$this->db->where('id', $id);
			$data['content'] = $this->db->get('tbl_logbookkegiatan');
			$this->load->view('logkegiatan/update', $data);
		} elseif($this->session->userdata('level') == "Admin"){
			redirect('admin','refresh');
		} else{
			redirect('login','refresh');
		}		
	}

	public function action_update($id= '')
	{
		$data =array(

			"tanggal" => $this->input->post("tanggal"),
			"kegiatan" => $this->input->post("kegiatan"),
			"keterangan" => $this->input->post("keterangan"),
		);

		$this->model_logbookkegiatan->action_update($data, $id);
		$this->session->set_flashdata('pesanberhasil', '<div class="alert alert-success alert-dismissible fade show" role="alert">
											  Data Berhasil diupdate!
											  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
											    <span aria-hidden="true">&times;</span>
											  </button>
											</div>');
		redirect('logbookkegiatan','refresh');
	}

		public function delete($id = NULL)
	{
		if($this->session->userdata('level') == "User"){
			$this->model_logbookkegiatan->action_delete($id);
			$this->session->set_flashdata('pesanberhasilhapus', '<div class="alert alert-success alert-dismissible fade show" role="alert">
											  Data Berhasil dihapus!
											  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
											    <span aria-hidden="true">&times;</span>
											  </button>
											</div>');
			redirect('logbookkegiatan','refresh');
		} elseif($this->session->userdata('level') == "Admin"){
			redirect('admin','refresh');
		} else{
			redirect('login','refresh');
		}
	} 

}

/* End of file Logbookkegiatan.php */
/* Location: ./application/controllers/Logbookkegiatan.php */